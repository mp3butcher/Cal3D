//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CalMaxExporter.rc
//
#define IDD_ANIMATION_EXPORT            101
#define IDB_CAL3D                       103
#define IDC_DISPLACEMENT                1000
#define IDC_BONE_TREE                   1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

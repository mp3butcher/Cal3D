//----------------------------------------------------------------------------//
// SkeletonExport.cpp                                                         //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "SkeletonExport.h"
#include "Helper.h"
#include "Model.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

const char *SkeletonExport::PLUGIN_CAPTION = "Cal3D Skeleton Exporter";

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

SkeletonExport::SkeletonExport()
{
	m_pExportInterface = 0;
	m_pInterface = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

SkeletonExport::~SkeletonExport()
{
}

//----------------------------------------------------------------------------//
// Recursively export all bones                                               //
//----------------------------------------------------------------------------//

bool SkeletonExport::ExportBone(std::ofstream& file, int boneId)
{
	// update progress bar
	int boneCount;
	boneCount = theModel.getBoneCount();
	if(boneCount > 0) m_pInterface->ProgressUpdate(75 + 25 * (boneId + 1) / boneCount);

	// get the bone for the given bone id
	Model::Bone *pBone;
	pBone = theModel.getBone(boneId);
	if(pBone == 0) return false;

	// get the translation out of the transformation matrix
	Point3 p;
	p = pBone->tmRelative.GetTrans();

	// convert transformation matrix rotation to a Cal3D quaternion
	Point3 euler;
	QuatToEuler(Quat(pBone->tmRelative), euler);

	Quat q;
	Helper::ConvertEulerToQuaternion(euler, q);

	// write bone name
	int len;
	len = pBone->strName.size() + 1;
	file.write((char *)&len, 4);
	file.write(pBone->strName.c_str(), len);

	// write bone translation
	file.write((char *)&p.x, 4);
	file.write((char *)&p.y, 4);
	file.write((char *)&p.z, 4);

	// write bone rotation
	file.write((char *)&q.x, 4);
	file.write((char *)&q.y, 4);
	file.write((char *)&q.z, 4);
	file.write((char *)&q.w, 4);

	// write parent bone id
	file.write((char *)&pBone->parentId, 4);

	// write bone children count
	int childrenCount;
	childrenCount = pBone->listChildrenId.size();
	file.write((char *)&childrenCount, 4);

	// write all children ids of this bone node
	std::list<int>::iterator iteratorChildrenId;
	for(iteratorChildrenId = pBone->listChildrenId.begin(); iteratorChildrenId != pBone->listChildrenId.end(); ++iteratorChildrenId)
	{
		// write child bone id
		int childId;
		childId = *iteratorChildrenId;
		file.write((char *)&childId, 4);
	}

	return true;
}

//----------------------------------------------------------------------------//
// Export the skeleton                                                        //
//----------------------------------------------------------------------------//

bool SkeletonExport::ExportSkeleton()
{
	// build the current animation state
	if(!theModel.buildCurrentState()) return false;

	// create the skeleton file
	std::ofstream file;
	file.open(m_strFilename, std::ios::out | std::ios::trunc | std::ios::binary);
	if(!file)
	{
        ::MessageBox (NULL, "Unable to create skeleton-file!", PLUGIN_CAPTION, MB_OK | MB_ICONWARNING);
		return false;
	}

	// write magic identifier
	file.write(&Helper::SKELETON_FILE_MAGIC[0], 4);

	// write bone count
	int boneCount;
	boneCount = theModel.getBoneCount();
	file.write((char *)&boneCount, 4);
	
	// export all bones
	int boneId;
	for(boneId = 0; boneId < boneCount; boneId++)
	{
		if(!ExportBone(file, boneId))
		{
			file.close();
			return false;
		}
	}

	// close the skeleton file
	file.close();

	return true;
}

//----------------------------------------------------------------------------//
// Progress callback function                                                 //
//----------------------------------------------------------------------------//

DWORD WINAPI SkeletonExport::ProgressFunction(LPVOID arg)
{
	return 0;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *SkeletonExport::AuthorName()
{
	return _T("Bruno 'Beosil' Heidelberger");
}

const TCHAR *SkeletonExport::CopyrightMessage()
{
	return _T("Copyright (C) 2001 Bruno 'Beosil' Heidelberger");
}

int SkeletonExport::DoExport(const TCHAR *name, ExpInterface *ei, Interface *i, BOOL suppressPrompts, DWORD options)
{
	m_strFilename = name;
	m_pExportInterface = ei;
	m_pInterface = i;

	// todo: show option dialog box
	// todo: export only selected nodes if options flag is set

	// export the skeleton
	m_pInterface->ProgressStart(_T("Exporting Cal3D Skeleton File..."), TRUE, ProgressFunction, 0);
	if(!theModel.create(m_pInterface)) return 0;
	if(!ExportSkeleton()) return 0;
	m_pInterface->ProgressEnd();

	return 1;
}

const TCHAR *SkeletonExport::Ext(int i)
{
	switch(i)
	{
	case 0:
		return _T("csf");
	default:
		return _T("");
	}
}

int SkeletonExport::ExtCount()
{
	return 1;
}

const TCHAR *SkeletonExport::LongDesc()
{
	return _T("Cal3D Skeleton File");
}

const TCHAR *SkeletonExport::OtherMessage1()
{
	return _T("");
}

const TCHAR *SkeletonExport::OtherMessage2()
{
	return _T("");
}

const TCHAR *SkeletonExport::ShortDesc()
{
	return _T("Cal3D Skeleton File");
}

void SkeletonExport::ShowAbout(HWND hWnd)
{
}

unsigned int SkeletonExport::Version()
{
	return 10;
}

//----------------------------------------------------------------------------//

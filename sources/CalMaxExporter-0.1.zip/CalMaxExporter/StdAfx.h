//----------------------------------------------------------------------------//
// StdAfx.h                                                                   //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef STDAFX_H
#define STDAFX_H

//----------------------------------------------------------------------------//
// Defines                                                                    //
//----------------------------------------------------------------------------//

#define WIN32_LEAN_AND_MEAN

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include <fstream>
#include <string>
#include <list>
#include <vector>
#include <stack>
#include "max.h"
#include "maxscrpt/maxscrpt.h"
#include "Bipexp.h"
#include "Phyexp.h"
#include "resource.h"

//----------------------------------------------------------------------------//
// MSVC++ stuff                                                               //
//----------------------------------------------------------------------------//

//{{AFX_INSERT_LOCATION}}

#endif

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// AnimationExportDesc.cpp                                                    //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "AnimationExportDesc.h"
#include "AnimationExport.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

AnimationExportDesc theAnimationExportDesc;

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

AnimationExportDesc::AnimationExportDesc()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

AnimationExportDesc::~AnimationExportDesc()
{
}

//----------------------------------------------------------------------------//
// Set the DLL instance handle of this plugin                                 //
//----------------------------------------------------------------------------//

void AnimationExportDesc::SetInstance(HINSTANCE hInstance)
{
	m_hInstance = hInstance;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *AnimationExportDesc::Category()
{
	return _T("Game Utilities");
}

Class_ID AnimationExportDesc::ClassID()
{
	return ANIMATION_EXPORT_ID;
}

const TCHAR *AnimationExportDesc::ClassName()
{
	return _T("Cal3D Animation Export");
}

void *AnimationExportDesc::Create(BOOL loading)
{
	return new AnimationExport();
}

HINSTANCE AnimationExportDesc::HInstance()
{
	return m_hInstance;
}

const TCHAR *AnimationExportDesc::InternalName()
{
	return _T("Cal3D_Animation_Export");
} 

int AnimationExportDesc::IsPublic()
{
	return 1;
}

SClass_ID AnimationExportDesc::SuperClassID()
{
	return SCENE_EXPORT_CLASS_ID;
}

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// CalMaxExporter.cpp                                                         //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "SkeletonExportDesc.h"
#include "AnimationExportDesc.h"
#include "MeshExportDesc.h"

//----------------------------------------------------------------------------//
// Dll entry point                                                            //
//----------------------------------------------------------------------------//

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, LPVOID lpReserved)
{
	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(hInstance);
		InitCustomControls(hInstance);
		theSkeletonExportDesc.SetInstance(hInstance);
		theAnimationExportDesc.SetInstance(hInstance);
		theMeshExportDesc.SetInstance(hInstance);
		break;
	case DLL_PROCESS_DETACH:
		break;
	}

	return TRUE;
}

//----------------------------------------------------------------------------//
// Exported functions                                                         //
//----------------------------------------------------------------------------//

__declspec(dllexport) ClassDesc *LibClassDesc(int i)
{
	switch(i)
	{
		case 0:
			return &theSkeletonExportDesc;
		case 1:
			return &theAnimationExportDesc;
		case 2:
			return &theMeshExportDesc;
		default:
			return 0;
	}
}

__declspec(dllexport) const TCHAR *LibDescription()
{
	return "Cal3D Exporter";
}

__declspec(dllexport) int LibNumberClasses()
{
	return 3;
}

__declspec(dllexport) ULONG LibVersion()
{
	return VERSION_3DSMAX;
}

//----------------------------------------------------------------------------//

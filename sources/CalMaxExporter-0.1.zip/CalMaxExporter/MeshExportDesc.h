//----------------------------------------------------------------------------//
// MeshExportDesc.h                                                           //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef MESH_EXPORT_DESC_H
#define MESH_EXPORT_DESC_H

//----------------------------------------------------------------------------//
// Defines                                                                    //
//----------------------------------------------------------------------------//

#define MESH_EXPORT_ID Class_ID(0x61514f07, 0x50533a16)

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class MeshExportDesc : public ClassDesc2
{
// member variables
protected:
	HINSTANCE m_hInstance;

// constructors/destructor
public:
	MeshExportDesc();
	virtual ~MeshExportDesc();

// member functions	
public:
	void SetInstance(HINSTANCE hInstance);

// interface functions	
public:
	const TCHAR *Category();
	Class_ID ClassID();
	const TCHAR *ClassName();
	void *Create(BOOL loading = FALSE);
	HINSTANCE HInstance();
	const TCHAR *InternalName(); 
	int IsPublic();
	SClass_ID SuperClassID();
};

//----------------------------------------------------------------------------//
// The one and only MeshExportDesc instance                              //
//----------------------------------------------------------------------------//

extern MeshExportDesc theMeshExportDesc;

#endif

//----------------------------------------------------------------------------//

o-----------------------------------------------------------------------------o
|                                                                             |
|                   cal3d - 3d studio max exporter plugin                     |
|                                                                             |
|                                Version 0.1                                  |
|                              (8. May. 2001)                                 |
|                                                                             |
|               Copyright (C) 2001 Bruno 'Beosil' Heidelberger                |
|                                                                             |
o-----------------------------------------------------------------------------o

o-----------------------------------------------------------------------------o
| Table of Contents                                                           |
o-----------------------------------------------------------------------------o

  1 License

  2 Introduction
      2.1 What is this?
      2.2 Features
      2.3 Website
      2.4 Author

  3 Compilation and Installation
      3.1 Compilation
      3.2 Installation

  4 Usage
      4.1 Important remarks
      4.2 Export of a skeleton
      4.3 Export of an animation
      4.4 Export of a mesh

o-----------------------------------------------------------------------------o
| 1 License                                                                   |
o-----------------------------------------------------------------------------o

  This program is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by the Free
  Software Foundation; either version 2 of the License, or (at your option)
  any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation Inc., 59
  Temple Place, Suite 330, Boston, MA 02111-1307 USA

o-----------------------------------------------------------------------------o
| 2 Introduction                                                              |
o-----------------------------------------------------------------------------o

  2.1 What is this?

      This is an exporter plugin for 3d studio max r3 that outputs skeleton-,
      animation- and mesh-data for the cal3d character animation library.

  2.2 Features

      - export of biped information from character studio
      - selective export of bone animation keyframes
      - export of physique modified meshes (one or more bone influences)
      - export of materials and mapping channels

  2.3 Website

      The official website of Cal3D is at: http://cal3d.sourceforge.net

  2.4 Author

      This plugin was developed by Bruno Heidelberger (beosil@swileys.com).

o-----------------------------------------------------------------------------o
| 3 Compilation and Installation                                              |
o-----------------------------------------------------------------------------o

  3.1 Compilation

      You need MS Visual C++ 6 and the 3d studio max SDK to successfully
      compile this exporter plugin.

  3.2 Installation

      Just copy the compiled CalMaxExporter.dle file into your 3d studio max
      plugin directory. It will get loaded next time you start 3d studio max.

o-----------------------------------------------------------------------------o
| 4 Usage                                                                     |
o-----------------------------------------------------------------------------o

  4.1 Important remarks

      This exporter plugin is still in a very early development state. This
      means it contains a lot of bugs and errors. There is a big chance that
      it will crash and take 3d studio max down. Make sure you always save
      your work before you export it with this plugin. Furthermore this
      plugin is by no means user-friendly yet, it was just hacked together to
      have the raw functionality. This will improve with every new release
      though, so stay tuned =)

  4.2 Export of a skeleton

      You can export the skeleton information of a biped by choosing the
      File->Export menu item and selecting the ".csf" file extension.

  4.3 Export of an animation

      You can export the animation information of a biped by choosing the
      File->Export menu item and selecting the ".caf" file extension. In the
      following dialog-box you can adjust the keyframe displacement and
      select the bones which will be taken into account for the export.

  4.4 Export of a mesh

      You can export a mesh by selecting it and choosing the File->Export
      item and selecting the ".cmf" file extension.
      
o-----------------------------------------------------------------------------o

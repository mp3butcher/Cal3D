//----------------------------------------------------------------------------//
// Model.h                                                                    //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef MODEL_H
#define MODEL_H

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class Model
{
// misc
public:
	typedef struct
	{
		TimeValue time;
		Matrix3 tm;
		Matrix3 tmRelative;
	} Keyframe;

	typedef struct
	{
		int id;
		INode *pNode;
		std::string strName;
		int parentId;
		std::list<int> listChildrenId;
		Matrix3 tm;
		Matrix3 tmRelative;
		std::list<Keyframe *> listKeyframe;
		HTREEITEM hTreeItem;
		float vertexWeight;
		bool bSelected;
	} Bone;

	typedef struct
	{
		float u, v;
	} TextureCoordinate;

	typedef struct
	{
		int vertexId;
		std::list<TextureCoordinate> listTextureCoordinate;
		unsigned char red, green, blue, alpha;
	} MaterialVertex;

	typedef struct
	{
		int v[3];
	} MaterialFace;

	typedef struct
	{
		std::string strName;
		int channel;
		Matrix3 uvMatrix;
	} MaterialMap;

	typedef struct
	{
		std::string strName;
		Color ambientColor;
		Color diffuseColor;
		Color specularColor;
		float shininess;
		std::list<MaterialMap *> listMaterialMap;
		std::list<MaterialFace *> listMaterialFace;
		int colorCount;
		std::list<MaterialVertex *> listMaterialVertex;
	} Material;

// member variables
protected:
	Interface *m_pInterface;
	std::vector<Bone *> m_vectorBone;
	std::list<int> m_listRootBoneId;
	std::vector<Material *> m_vectorMaterial;

// constructors/destructor
public:
	Model();
	virtual ~Model();

// member functions
public:
	void addMaterial(Mtl *pMtl);
	bool buildCurrentState();
	bool buildKeyframes(TimeValue start, TimeValue end, TimeValue step, TimeValue displacement);
	bool buildMaterials(INode *pNode, Mesh *pMesh);
	void clear();
	void clearKeyframes(int boneId);
	bool create(Interface *pInterface);
	Bone *getBone(int boneId);
	int getBoneId(INode *pNode);
	int getBoneCount();
	std::list<int>& getListRootBoneId();
	int getSelectedBoneCount();
	std::vector<Bone *>& getVectorBone();
	std::vector<Material *>& getVectorMaterial();
	void setUniform(bool bUniform);
};

#endif

//----------------------------------------------------------------------------//
// The one and only Model instance                                            //
//----------------------------------------------------------------------------//

extern Model theModel;

//----------------------------------------------------------------------------//

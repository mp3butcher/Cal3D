//----------------------------------------------------------------------------//
// AnimationExport.cpp                                                        //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "AnimationExport.h"
#include "AnimationExportDesc.h"
#include "Helper.h"
#include "Model.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

const char *AnimationExport::PLUGIN_CAPTION = "Cal3D Animation Exporter";

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

AnimationExport::AnimationExport()
{
	m_pExportInterface = 0;
	m_pInterface = 0;
	m_displacement = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

AnimationExport::~AnimationExport()
{
}

//----------------------------------------------------------------------------//
// Build the bone hierarchy tree control                                      //
//----------------------------------------------------------------------------//

void AnimationExport::BuildBoneTreeControl(HWND hTreeCtrl, int boneId, HTREEITEM hParentItem)
{
	std::vector<Model::Bone *>& vectorBone = theModel.getVectorBone();

	// get the bone
	Model::Bone *pBone;
	pBone = vectorBone[boneId];
	if(pBone == 0) return;

	// insert bone item to the tree control
	TVINSERTSTRUCT tvInsertStruct;
	tvInsertStruct.hParent = hParentItem;
	tvInsertStruct.hInsertAfter = TVI_LAST;
	tvInsertStruct.item.mask = TVIF_TEXT | TVIF_PARAM | TVIF_STATE;
	tvInsertStruct.item.pszText = (char *)pBone->strName.c_str();
	tvInsertStruct.item.state = TVIS_EXPANDED | INDEXTOSTATEIMAGEMASK(2);
	tvInsertStruct.item.stateMask = TVIS_EXPANDED | TVIS_STATEIMAGEMASK;
	tvInsertStruct.item.lParam = (LPARAM)pBone->id;

	pBone->hTreeItem = TreeView_InsertItem(hTreeCtrl, &tvInsertStruct);

	// process all children of this bone
	std::list<int>::iterator iteratorChildrenId;
	for(iteratorChildrenId = pBone->listChildrenId.begin(); iteratorChildrenId != pBone->listChildrenId.end(); ++iteratorChildrenId)
	{
		BuildBoneTreeControl(hTreeCtrl, *iteratorChildrenId, pBone->hTreeItem);
	}
}

void AnimationExport::BuildBoneTreeControl(HWND hTreeCtrl)
{
	// check for valid window handle
	if(hTreeCtrl == 0) return;

	std::list<int>& listRootBoneId = theModel.getListRootBoneId();

	std::list<int>::iterator iteratorRootBoneId;
	for(iteratorRootBoneId = listRootBoneId.begin(); iteratorRootBoneId != listRootBoneId.end(); ++iteratorRootBoneId)
	{
		BuildBoneTreeControl(hTreeCtrl, *iteratorRootBoneId, TVI_ROOT);
	}
}

//----------------------------------------------------------------------------//
// Dialog callback function                                                   //
//----------------------------------------------------------------------------//

BOOL CALLBACK AnimationExport::DialogCallback(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static AnimationExport *pAnimationExport = 0;

	// handle window message
	switch(msg)
	{
	case WM_INITDIALOG:
		pAnimationExport = (AnimationExport *)lParam;
		pAnimationExport->BuildBoneTreeControl(GetDlgItem(hWnd, IDC_BONE_TREE));
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			pAnimationExport->GetDialogValues(hWnd);
			EndDialog(hWnd, 1);
			break;
		case IDCANCEL:
			EndDialog(hWnd, 0);
			break;
		}
		break;
	default:
		return FALSE;
	}

	return TRUE;
}

//----------------------------------------------------------------------------//
// Export the animation                                                       //
//----------------------------------------------------------------------------//

bool AnimationExport::ExportAnimation()
{
	// build the current animation state
	if(!theModel.buildCurrentState()) return false;
	if(!theModel.buildKeyframes(m_pInterface->GetAnimRange().Start(), m_pInterface->GetAnimRange().End(), GetTicksPerFrame(), m_displacement * GetTicksPerFrame())) return false;

	// create the aniamtion file
	std::ofstream file;
	file.open(m_strFilename, std::ios::out | std::ios::trunc | std::ios::binary);
	if(!file)
	{
        ::MessageBox (NULL, "Unable to create animation-file!", PLUGIN_CAPTION, MB_OK | MB_ICONWARNING);
		return false;
	}

	// write magic identifier
	file.write(&Helper::ANIMATION_FILE_MAGIC[0], 4);

	// write animation duration
	float duration;
	duration = Helper::TicksToSeconds(m_pInterface->GetAnimRange().End() - m_pInterface->GetAnimRange().Start() + GetTicksPerFrame());
	file.write((char *)&duration, 4);

	// write track count
	int boneCount;
	boneCount = theModel.getSelectedBoneCount();
	file.write((char *)&boneCount, 4);
	
	// export all tracks
	int boneId;
	for(boneId = 0; boneId < theModel.getBoneCount(); boneId++)
	{
		if(!ExportTrack(file, boneId))
		{
			file.close();
			return false;
		}
	}

	// close the animation file
	file.close();

	return true;
}

//----------------------------------------------------------------------------//
// Recursively export all tracks                                              //
//----------------------------------------------------------------------------//

bool AnimationExport::ExportTrack(std::ofstream& file, int boneId)
{
	// update progress bar
	int boneCount;
	boneCount = theModel.getBoneCount();
	if(boneCount > 0) m_pInterface->ProgressUpdate(75 + 25 * (boneId + 1) / boneCount);

	// get the bone for the given bone id
	Model::Bone *pBone;
	pBone = theModel.getBone(boneId);
	if(pBone == 0) return false;

	// only export track if bone was selected
	if(!pBone->bSelected) return true;

	// write the bone id
	file.write((char *)&boneId, 4);

	// write the number of keyframes
	int keyframeCount;
	keyframeCount = pBone->listKeyframe.size();
	file.write((char *)&keyframeCount, 4);

	// export all keyframes
	std::list<Model::Keyframe *>::iterator iteratorKeyframe;
	for(iteratorKeyframe = pBone->listKeyframe.begin(); iteratorKeyframe != pBone->listKeyframe.end(); ++iteratorKeyframe)
	{
		Model::Keyframe *pKeyframe;
		pKeyframe = *iteratorKeyframe;

		// get the translation out of the transformation matrix
		Point3 p;
		p = pKeyframe->tmRelative.GetTrans();

		// convert transformation matrix rotation to a Cal3D quaternion
		Point3 euler;
		QuatToEuler(Quat(pKeyframe->tmRelative), euler);

		Quat q;
		Helper::ConvertEulerToQuaternion(euler, q);

		// write keyframe time
		float sec;
		sec = Helper::TicksToSeconds(pKeyframe->time);
		file.write((char *)&sec, 4);

		// write bone translation
		file.write((char *)&p.x, 4);
		file.write((char *)&p.y, 4);
		file.write((char *)&p.z, 4);

		// write bone rotation
		file.write((char *)&q.x, 4);
		file.write((char *)&q.y, 4);
		file.write((char *)&q.z, 4);
		file.write((char *)&q.w, 4);
	}

	return true;
}

//----------------------------------------------------------------------------//
// Get all values out of the export dialog box                                //
//----------------------------------------------------------------------------//

void AnimationExport::GetDialogValues(HWND hWnd)
{
	// get frame displacement value
	m_displacement = GetDlgItemInt(hWnd, IDC_DISPLACEMENT, NULL, FALSE);

	// get the bones/tracks to export
	HWND hTreeCtrl;
	hTreeCtrl = GetDlgItem(hWnd, IDC_BONE_TREE);
	if(hTreeCtrl != 0)
	{
		std::vector<Model::Bone *>& vectorBone = theModel.getVectorBone();
		int boneId;
		for(boneId = 0; boneId < vectorBone.size(); boneId++)
		{
			// get the bone
			Model::Bone *pBone;
			pBone = vectorBone[boneId];
			
			// get the tree control item
			TVITEM tvItem;
			tvItem.mask = TVIF_HANDLE | TVIF_STATE;
			tvItem.hItem = pBone->hTreeItem;
			tvItem.stateMask = TVIS_STATEIMAGEMASK;

			TreeView_GetItem(hTreeCtrl, &tvItem);

			// set the selected state in the bone
			if((tvItem.state >> 12) >= 2) pBone->bSelected = true;
			else pBone->bSelected = false;
		}
	}
}

//----------------------------------------------------------------------------//
// Progress callback function                                                 //
//----------------------------------------------------------------------------//

DWORD WINAPI AnimationExport::ProgressFunction(LPVOID arg)
{
	return 0;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *AnimationExport::AuthorName()
{
	return _T("Bruno 'Beosil' Heidelberger");
}

const TCHAR *AnimationExport::CopyrightMessage()
{
	return _T("Copyright (C) 2001 Bruno 'Beosil' Heidelberger");
}

int AnimationExport::DoExport(const TCHAR *name, ExpInterface *ei, Interface *i, BOOL suppressPrompts, DWORD options)
{
	m_strFilename = name;
	m_pExportInterface = ei;
	m_pInterface = i;

	m_pInterface->ProgressStart(_T("Exporting Cal3D Animation File..."), TRUE, ProgressFunction, 0);
	if(!theModel.create(m_pInterface)) return 0;

	// show dialog box
	if(DialogBoxParam(theAnimationExportDesc.HInstance(), MAKEINTRESOURCE(IDD_ANIMATION_EXPORT), m_pInterface->GetMAXHWnd(), DialogCallback, (LPARAM)this) == IDOK)
	{
		// export the animation
		if(!ExportAnimation()) return 0;
	}

	m_pInterface->ProgressEnd();

	return 1;
}

const TCHAR *AnimationExport::Ext(int i)
{
	switch(i)
	{
	case 0:
		return _T("caf");
	default:
		return _T("");
	}
}

int AnimationExport::ExtCount()
{
	return 1;
}

const TCHAR *AnimationExport::LongDesc()
{
	return _T("Cal3D Animation File");
}

const TCHAR *AnimationExport::OtherMessage1()
{
	return _T("");
}

const TCHAR *AnimationExport::OtherMessage2()
{
	return _T("");
}

const TCHAR *AnimationExport::ShortDesc()
{
	return _T("Cal3D Animation File");
}

void AnimationExport::ShowAbout(HWND hWnd)
{
}

unsigned int AnimationExport::Version()
{
	return 10;
}

//----------------------------------------------------------------------------//

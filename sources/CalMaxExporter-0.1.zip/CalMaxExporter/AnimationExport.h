//----------------------------------------------------------------------------//
// AnimationExport.h                                                          //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef ANIMATION_EXPORT_H
#define ANIMATION_EXPORT_H

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class AnimationExport : public SceneExport
{
// misc
protected:
	static const char *PLUGIN_CAPTION;
	static BOOL CALLBACK DialogCallback(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
	static DWORD WINAPI ProgressFunction(LPVOID arg);

// member variables
protected:
	ExpInterface *m_pExportInterface;
	Interface *m_pInterface;
	const char *m_strFilename;
	unsigned int m_displacement;

// constructors/destructor
public:
	AnimationExport();
	virtual ~AnimationExport();

// member functions
protected:
	void BuildBoneTreeControl(HWND hTreeCtrl);
	void BuildBoneTreeControl(HWND hTreeCtrl, int boneId, HTREEITEM hParentItem);
	bool ExportAnimation();
	bool ExportTrack(std::ofstream& file, int boneId);
	void GetDialogValues(HWND hWnd);

// interface functions	
public:
	const TCHAR *AuthorName();
	const TCHAR *CopyrightMessage();
	int DoExport(const TCHAR *name, ExpInterface *ei, Interface *i, BOOL suppressPrompts = FALSE, DWORD options = 0);
	const TCHAR *Ext(int n);
	int ExtCount();
	const TCHAR *LongDesc();
	const TCHAR *OtherMessage1();
	const TCHAR *OtherMessage2();
	const TCHAR *ShortDesc();
	void ShowAbout(HWND hWnd);
	unsigned int Version();
};

#endif

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Helper.cpp                                                                 //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "Helper.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

const char Helper::SKELETON_FILE_MAGIC[4]  = { 'C', 'S', 'F', '#' };
const char Helper::ANIMATION_FILE_MAGIC[4] = { 'C', 'A', 'F', '#' };
const char Helper::MESH_FILE_MAGIC[4]      = { 'C', 'M', 'F', '#' };

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

Helper::Helper()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

Helper::~Helper()
{
}

//----------------------------------------------------------------------------//
// Convert euler angles to a quaternion                                       //
//----------------------------------------------------------------------------//

void Helper::ConvertEulerToQuaternion(Point3& euler, Quat& quaternion)
{
	// half angles
	float tempx, tempy, tempz;
	tempx = euler[0] * 0.5f;
	tempy = euler[1] * 0.5f;
	tempz = euler[2] * 0.5f;

	// calculate intermediate results
  	float cosx, cosy, cosz, sinx, siny, sinz, cosc, coss, sinc, sins;
	cosx = cos(tempx);
	cosy = cos(tempy);
	cosz = cos(tempz);
	sinx = sin(tempx);
	siny = sin(tempy);
	sinz = sin(tempz);
	cosc = cosx * cosz;
	coss = cosx * sinz;
	sinc = sinx * cosz;
	sins = sinx * sinz;

	// build quaternion
	quaternion[0] = (cosy * sinc) - (siny * coss);
	quaternion[1] = (cosy * sins) + (siny * cosc);
	quaternion[2] = (cosy * coss) - (siny * sinc);
	quaternion[3] = (cosy * cosc) + (siny * sins);

}

//----------------------------------------------------------------------------//
// Fix the coorrdinate system of MAX to the Cal3D style                       //
//----------------------------------------------------------------------------//

void Helper::FixCoordSystem(Matrix3& tm)
{
/*
	Point3 row;
	row = tm.GetRow(1);
	tm.SetRow(1, tm.GetRow(2));
	tm.SetRow(2, row);

	Point4 column;
	column = tm.GetColumn(1);
	tm.SetColumn(1, tm.GetColumn(2));
	tm.SetColumn(2, column);

	tm.SetRow(0, -(tm.GetRow(0)));
	tm.SetColumn(0, -(tm.GetColumn(0)));
*/
}

//----------------------------------------------------------------------------//
// Fix the normal of MAX to the Cal3D style                                   //
//----------------------------------------------------------------------------//

void Helper::FixNormal(Point3& p)
{
/* rigell
	float temp;
	temp = p.y;
	p.y = -p.z;
	p.z = temp;
*/
}

//----------------------------------------------------------------------------//
// Get the transformation matrix of a bone node                               //
//----------------------------------------------------------------------------//

Matrix3 Helper::GetBoneTM(INode *pNode, TimeValue t)
{
	// get node transformation
	Matrix3 tm;
	tm = pNode->GetNodeTM(t);

	// make transformation uniform
	tm.NoScale();

	return tm;
}

//----------------------------------------------------------------------------//
// Check if the given node is a biped bone                                    //
//----------------------------------------------------------------------------//

bool Helper::IsBipedBone(INode *pNode)
{
	// check for invalid and root nodes
	if((pNode == 0) || pNode->IsRootNode()) return false;

	// check for biped nodes
	Control *pControl;
	pControl = pNode->GetTMController();
	if((pControl->ClassID() == BIPSLAVE_CONTROL_CLASS_ID) || (pControl->ClassID() == BIPBODY_CONTROL_CLASS_ID)) return true;

	return false;
}

//----------------------------------------------------------------------------//
// Check if the given node is a bone                                          //
//----------------------------------------------------------------------------//

bool Helper::IsBone(INode *pNode)
{
	// check for invalid and root nodes
	if((pNode == 0) || pNode->IsRootNode()) return false;

	// check for bone and dummy nodes
	ObjectState os;
	os = pNode->EvalWorldState(0);
	if(os.obj->ClassID() == Class_ID(BONE_CLASS_ID, 0)) return true;
	if(os.obj->ClassID() == Class_ID(DUMMY_CLASS_ID, 0)) return false;

	// check for biped nodes
	Control *pControl;
	pControl = pNode->GetTMController();
	if((pControl->ClassID() == BIPSLAVE_CONTROL_CLASS_ID) || (pControl->ClassID() == BIPBODY_CONTROL_CLASS_ID)) return true;

	return false;
}

//----------------------------------------------------------------------------//
// Check if the given node is a mesh                                          //
//----------------------------------------------------------------------------//

bool Helper::IsMesh(INode *pNode)
{
	// check for invalid and root nodes
	if((pNode == 0) || pNode->IsRootNode()) return false;

	// check for mesh
	ObjectState os;
	os = pNode->EvalWorldState(0);
	if(os.obj->SuperClassID() == GEOMOBJECT_CLASS_ID) return true;

	return false;
}

//----------------------------------------------------------------------------//
// Convert seconds to ticks                                                   //
//----------------------------------------------------------------------------//

TimeValue Helper::SecondsToTicks(float sec)
{
	return (TimeValue)(sec * (float)TIME_TICKSPERSEC);
}

//----------------------------------------------------------------------------//
// Set/Unset biped uniform scale                                              //
//----------------------------------------------------------------------------//

void Helper::SetBipedUniform(INode *pNode, BOOL bUniform)
{
	if(IsBipedBone(pNode))
	{
		// get the TM controller of the node
		Control *pControl;
		pControl = pNode->GetTMController();

		// get the biped export interface
		IBipedExport *pBipedExport;
		pBipedExport = (IBipedExport *)pControl->GetInterface(I_BIPINTERFACE);

		// remove/add uniform scale
		pBipedExport->RemoveNonUniformScale(bUniform);

		// notify all dependents
		Control *pMasterControl;
		pMasterControl = (Control *)pControl->GetInterface(I_MASTER);
		pMasterControl->NotifyDependents(FOREVER, PART_TM, REFMSG_CHANGE);
		pControl->ReleaseInterface(I_MASTER, pMasterControl);

		// release the biped export interface
		pControl->ReleaseInterface(I_BIPINTERFACE, pBipedExport);
	}
}

//----------------------------------------------------------------------------//
// Convert ticks to seconds                                                   //
//----------------------------------------------------------------------------//

float Helper::TicksToSeconds(TimeValue ticks)
{
	return (float)ticks / (float)TIME_TICKSPERSEC;
}

//----------------------------------------------------------------------------//

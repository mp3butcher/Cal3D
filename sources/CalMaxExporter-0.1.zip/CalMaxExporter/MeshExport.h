//----------------------------------------------------------------------------//
// MeshExport.h                                                               //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef MESH_EXPORT_H
#define MESH_EXPORT_H

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class MeshExport : public SceneExport
{
// misc
protected:
	static const char *PLUGIN_CAPTION;
	static DWORD WINAPI ProgressFunction(LPVOID arg);

// member variables
protected:
	ExpInterface *m_pExportInterface;
	Interface *m_pInterface;
	const char *m_strFilename;
	std::vector<INode *> m_vectorBone;
	int m_boneInfluenceCount;
	int m_materialCount;

// constructors/destructor
public:
	MeshExport();
	virtual ~MeshExport();

// member functions
protected:
	bool ExportBoneInfluence(std::ofstream& file, INode *pNode, Modifier *pModifier, int vertexId, Point3& vertex, float *pNormals);
	bool ExportMaterial(std::ofstream& file, INode *pNode, int materialId);
	bool ExportMesh();
	Modifier *FindPhysiqueModifier(INode *pNode);
	Point3 GetVertexNormal(Mesh *pMesh, int faceId, int vertexId);

// interface functions	
public:
	const TCHAR *AuthorName();
	const TCHAR *CopyrightMessage();
	int DoExport(const TCHAR *name, ExpInterface *ei, Interface *i, BOOL suppressPrompts = FALSE, DWORD options = 0);
	const TCHAR *Ext(int n);
	int ExtCount();
	const TCHAR *LongDesc();
	const TCHAR *OtherMessage1();
	const TCHAR *OtherMessage2();
	const TCHAR *ShortDesc();
	void ShowAbout(HWND hWnd);
	unsigned int Version();
};

#endif

//----------------------------------------------------------------------------//

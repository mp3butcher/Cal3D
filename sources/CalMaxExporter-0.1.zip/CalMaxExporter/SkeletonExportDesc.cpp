//----------------------------------------------------------------------------//
// SkeletonExportDesc.cpp                                                     //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "SkeletonExportDesc.h"
#include "SkeletonExport.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

SkeletonExportDesc theSkeletonExportDesc;

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

SkeletonExportDesc::SkeletonExportDesc()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

SkeletonExportDesc::~SkeletonExportDesc()
{
}

//----------------------------------------------------------------------------//
// Set the DLL instance handle of this plugin                                 //
//----------------------------------------------------------------------------//

void SkeletonExportDesc::SetInstance(HINSTANCE hInstance)
{
	m_hInstance = hInstance;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *SkeletonExportDesc::Category()
{
	return _T("Game Utilities");
}

Class_ID SkeletonExportDesc::ClassID()
{
	return SKELETON_EXPORT_ID;
}

const TCHAR *SkeletonExportDesc::ClassName()
{
	return _T("Cal3D Skeleton Export");
}

void *SkeletonExportDesc::Create(BOOL loading)
{
	return new SkeletonExport();
}

HINSTANCE SkeletonExportDesc::HInstance()
{
	return m_hInstance;
}

const TCHAR *SkeletonExportDesc::InternalName()
{
	return _T("Cal3D_Skeleton_Export");
} 

int SkeletonExportDesc::IsPublic()
{
	return 1;
}

SClass_ID SkeletonExportDesc::SuperClassID()
{
	return SCENE_EXPORT_CLASS_ID;
}

//----------------------------------------------------------------------------//

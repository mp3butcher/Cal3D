//----------------------------------------------------------------------------//
// MeshExport.cpp                                                             //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "MeshExport.h"
#include "Helper.h"
#include "NullView.h"
#include "Model.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

const char *MeshExport::PLUGIN_CAPTION = "Cal3D Mesh Exporter";

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

MeshExport::MeshExport()
{
	m_pExportInterface = 0;
	m_pInterface = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

MeshExport::~MeshExport()
{
}

//----------------------------------------------------------------------------//
// Export the bone influences for a given vertex                              //
//----------------------------------------------------------------------------//

bool MeshExport::ExportBoneInfluence(std::ofstream& file, INode *pNode, Modifier *pModifier, int vertexId, Point3& vertex, float *pNormals)
{
	// create a physique export interface
	IPhysiqueExport *pPhysiqueExport;
	pPhysiqueExport = (IPhysiqueExport *)pModifier->GetInterface(I_PHYINTERFACE);
	if(pPhysiqueExport == 0) return false;

	// create a context export interface
	IPhyContextExport *pContextExport;
	pContextExport = (IPhyContextExport *)pPhysiqueExport->GetContextInterface(pNode);
	if(pContextExport == 0)
	{
		pModifier->ReleaseInterface(I_PHYINTERFACE, pPhysiqueExport);
		return false;
	}

	// set flags in the context export interface
	pContextExport->ConvertToRigid(TRUE);
	pContextExport->AllowBlending(TRUE);

	// get the vertex export interface
	IPhyVertexExport *pVertexExport = (IPhyVertexExport *)pContextExport->GetVertexInterface(vertexId);
	if(pVertexExport == 0)
	{
		pPhysiqueExport->ReleaseContextInterface(pContextExport);
		pModifier->ReleaseInterface(I_PHYINTERFACE, pPhysiqueExport);
		return false;
	}

	// get the vertex type
	int vertexType;
	vertexType = pVertexExport->GetVertexType();

	// handle specific vertex type
	if(vertexType == RIGID_TYPE)
	{
		IPhyRigidVertex *pTypeVertex;
		pTypeVertex = (IPhyRigidVertex *)pVertexExport;

		// write number of influences, this is 1 for rigid vertex types
		int influenceCount;
		influenceCount = 1;
		file.write((char *)&influenceCount, 4);
		m_boneInfluenceCount++;

		// get the influencing bone
		INode *pBoneNode;
		pBoneNode = pTypeVertex->GetNode();

		// get the directory index of the bone
		int boneId;
		boneId = theModel.getBoneId(pBoneNode);
		if(boneId == -1)
		{
			pPhysiqueExport->ReleaseContextInterface(pContextExport);
			pModifier->ReleaseInterface(I_PHYINTERFACE, pPhysiqueExport);
			return false;
		}

		// get the bone of out model structure
		Model::Bone *pBone;
		pBone = theModel.getBone(boneId);

		// we have only one bone (rigid), so the weight is 100%
		float boneWeight;
		boneWeight = 1.0f;

		// get relative vertex position
		Point3 p;
		p = vertex * Inverse(pBone->tm);
		
/*
Point3 pp = pTypeVertex->GetOffsetVector();
FILE *hFile = fopen("C:\\xxx.txt", "ab");
fprintf(hFile, "%.6f %.6f %.6f == %.6f %.6f %.6f\r\n", p.x, p.y, p.z, pp.x, pp.y, pp.z);
fclose(hFile);
*/
		// get vertex normal
		Point3 normal;
		normal.x = pNormals[vertexId * 3];
		normal.y = pNormals[vertexId * 3 + 1];
		normal.z = pNormals[vertexId * 3 + 2];

		// transform vertex normal to relative rotation
		Matrix3 tmRotation;
		tmRotation = pBone->tm;
		tmRotation.NoTrans();
		tmRotation.NoScale();

		normal = normal * Inverse(tmRotation);
		normal = normal.Normalize();

		// write influence data
		file.write((char *)&boneId, 4);
		file.write((char *)&boneWeight, 4);
		file.write((char *)&p.x, 4);
		file.write((char *)&p.y, 4);
		file.write((char *)&p.z, 4);
		file.write((char *)&normal.x, 4);
		file.write((char *)&normal.y, 4);
		file.write((char *)&normal.z, 4);
	}
	else if(vertexType == RIGID_BLENDED_TYPE)
	{
		IPhyBlendedRigidVertex *pTypeVertex;
		pTypeVertex = (IPhyBlendedRigidVertex *)pVertexExport;

		std::vector<Model::Bone *>& vectorBone = theModel.getVectorBone();

		// clear all bone vertex weights
		int boneId;
		for(boneId = 0; boneId < vectorBone.size(); boneId++)
		{
			vectorBone[boneId]->vertexWeight = 0.0f;
		}

		// loop through all influencing bones
		int nodeId;
		for(nodeId = 0; nodeId < pTypeVertex->GetNumberNodes(); nodeId++)
		{
			INode *pBoneNode;
			pBoneNode = pTypeVertex->GetNode(nodeId);

			// get the directory index of the bone
			boneId = theModel.getBoneId(pBoneNode);
			if(boneId == -1)
			{
				pPhysiqueExport->ReleaseContextInterface(pContextExport);
				pModifier->ReleaseInterface(I_PHYINTERFACE, pPhysiqueExport);
				return false;
			}

			// we have more then one bone (blended), so we have to accumulate all influence weights
			vectorBone[boneId]->vertexWeight += pTypeVertex->GetWeight(nodeId);
/*
Model::Bone *pBone = theModel.getBone(boneId);
Point3 p = vertex * Inverse(pBone->tm);
Point3 pp = pTypeVertex->GetOffsetVector(nodeId);
FILE *hFile = fopen("C:\\xxx.txt", "ab");
fprintf(hFile, "%d: %d %.6f -> %.6f %.6f %.6f == %.6f %.6f %.6f\r\n", nodeId, boneId, pTypeVertex->GetWeight(nodeId), p.x, p.y, p.z, pp.x, pp.y, pp.z);
fclose(hFile);
*/
		}

		// calculate number of influences and scale all weights sothey sum up to 1.0
		int influenceCount;
		float weight;
		for(boneId = 0, influenceCount = 0, weight = 0.0f; boneId < vectorBone.size(); boneId++)
		{
			if(vectorBone[boneId]->vertexWeight > 0.0f)
			{
				influenceCount++;
			}

			weight += vectorBone[boneId]->vertexWeight;
		}

		// normalize vector weights
		for(boneId = 0; boneId < vectorBone.size(); boneId++)
		{
			vectorBone[boneId]->vertexWeight /= weight;
		}

		// write number of influences
		file.write((char *)&influenceCount, 4);
		m_boneInfluenceCount += influenceCount;

		// export all bone influences
		for(boneId = 0; boneId < vectorBone.size(); boneId++)
		{
			// only export bones with influence weight > 0.0
			if(vectorBone[boneId]->vertexWeight <= 0.0f) continue;

			// get the bone of out model structure
			Model::Bone *pBone;
			pBone = theModel.getBone(boneId);

			// get relative vertex position
			Point3 p;
			p = vertex * Inverse(pBone->tm);

			// get vertex normal
			Point3 normal;
			normal.x = pNormals[vertexId * 3];
			normal.y = pNormals[vertexId * 3 + 1];
			normal.z = pNormals[vertexId * 3 + 2];

			// transform vertex normal to relative rotation
			Matrix3 tmRotation;
			tmRotation = pBone->tm;
			tmRotation.NoTrans();
			tmRotation.NoScale();

			normal = normal * Inverse(tmRotation);
			normal = normal.Normalize();

			// write influence data
			file.write((char *)&boneId, 4);
			file.write((char *)&vectorBone[boneId]->vertexWeight, 4);
			file.write((char *)&p.x, 4);
			file.write((char *)&p.y, 4);
			file.write((char *)&p.z, 4);
			file.write((char *)&normal.x, 4);
			file.write((char *)&normal.y, 4);
			file.write((char *)&normal.z, 4);
		}
	}

	// release all interfaces
	pPhysiqueExport->ReleaseContextInterface(pContextExport);
	pModifier->ReleaseInterface(I_PHYINTERFACE, pPhysiqueExport);

	return true;
}

//----------------------------------------------------------------------------//
// Export the material with a given id                                        //
//----------------------------------------------------------------------------//

bool MeshExport::ExportMaterial(std::ofstream& file, INode *pNode, int materialId)
{
	// get material vector
	std::vector<Model::Material *>& vectorMaterial = theModel.getVectorMaterial();

	// check if id is valid
	if(materialId >= vectorMaterial.size()) return false;

	// get material
	Model::Material *pMaterial;
	pMaterial = vectorMaterial[materialId];

	// only export materials which are used
	if(pMaterial->listMaterialFace.empty()) return true;

	// write material data
	unsigned char color[4];
	color[3] = 255;

	color[0] = (unsigned char)(pMaterial->ambientColor.r * 255.0f);
	color[1] = (unsigned char)(pMaterial->ambientColor.g * 255.0f);
	color[2] = (unsigned char)(pMaterial->ambientColor.b * 255.0f);
	file.write((char *)&color, 4);

	color[0] = (unsigned char)(pMaterial->diffuseColor.r * 255.0f);
	color[1] = (unsigned char)(pMaterial->diffuseColor.g * 255.0f);
	color[2] = (unsigned char)(pMaterial->diffuseColor.b * 255.0f);
	file.write((char *)&color, 4);

	color[0] = (unsigned char)(pMaterial->specularColor.r * 255.0f);
	color[1] = (unsigned char)(pMaterial->specularColor.g * 255.0f);
	color[2] = (unsigned char)(pMaterial->specularColor.b * 255.0f);
	file.write((char *)&color, 4);

	file.write((char *)&pMaterial->shininess, 4);

	// write map data
	int mapCount;
	mapCount = pMaterial->listMaterialMap.size();
	file.write((char *)&mapCount, 4);

	// export all material maps
	std::list<Model::MaterialMap *>::iterator iteratorMaterialMap;
	for(iteratorMaterialMap = pMaterial->listMaterialMap.begin(); iteratorMaterialMap != pMaterial->listMaterialMap.end(); ++iteratorMaterialMap)
	{
		Model::MaterialMap *pMaterialMap;
		pMaterialMap = *iteratorMaterialMap;

		// write material map data
		// todo: map id numbering???
		std::string strId;
		strId = pMaterialMap->strName.substr(pMaterialMap->strName.find_last_of(" "));

		int id;
		id = atoi(strId.c_str());

		file.write((char *)&id, 4);
	}

	// write face data
	int faceCount;
	faceCount = pMaterial->listMaterialFace.size();
	file.write((char *)&faceCount, 4);

	// check for negative scale -> invert face vertex ordering
	Matrix3 tm = pNode->GetObjTMAfterWSM(0);
	BOOL negScale = (DotProd(CrossProd(tm.GetRow(0), tm.GetRow(1)), tm.GetRow(2)) < 0.0) ? TRUE : FALSE;
	int vx1, vx2, vx3;
	if (negScale) {
		vx1 = 2;
		vx2 = 1;
		vx3 = 0;
	}
	else {
		vx1 = 0;
		vx2 = 1;
		vx3 = 2;
	}

	// export all faces
	std::list<Model::MaterialFace *>::iterator iteratorMaterialFace;
	for(iteratorMaterialFace = pMaterial->listMaterialFace.begin(); iteratorMaterialFace != pMaterial->listMaterialFace.end(); ++iteratorMaterialFace)
	{
		Model::MaterialFace *pMaterialFace;
		pMaterialFace = *iteratorMaterialFace;

		// write face data
		file.write((char *)&pMaterialFace->v[vx1], 4);
		file.write((char *)&pMaterialFace->v[vx2], 4);
		file.write((char *)&pMaterialFace->v[vx3], 4);
	}

	// write vertex data
	int vertexCount;
	vertexCount = pMaterial->listMaterialVertex.size();
	file.write((char *)&vertexCount, 4);

	int colorCount;
	colorCount = pMaterial->colorCount;
	file.write((char *)&colorCount, 4);

	// export all vertices
	std::list<Model::MaterialVertex *>::iterator iteratorMaterialVertex;
	for(iteratorMaterialVertex = pMaterial->listMaterialVertex.begin(); iteratorMaterialVertex != pMaterial->listMaterialVertex.end(); ++iteratorMaterialVertex)
	{
		Model::MaterialVertex *pMaterialVertex;
		pMaterialVertex = *iteratorMaterialVertex;

		// write vertex data
		file.write((char *)&pMaterialVertex->vertexId, 4);

		if(colorCount > 0)
		{
			file.write((char *)&pMaterialVertex->red, 1);
			file.write((char *)&pMaterialVertex->green, 1);
			file.write((char *)&pMaterialVertex->blue, 1);
			file.write((char *)&pMaterialVertex->alpha, 1);
		}

		std::list<Model::TextureCoordinate>::iterator iteratorTextureCoordinate;
		for(iteratorTextureCoordinate = pMaterialVertex->listTextureCoordinate.begin(); iteratorTextureCoordinate != pMaterialVertex->listTextureCoordinate.end(); ++iteratorTextureCoordinate)
		{
			file.write((char *)&(*iteratorTextureCoordinate).u, 4);
			file.write((char *)&(*iteratorTextureCoordinate).v, 4);
		}
	}

	m_materialCount++;

	return true;
}

//----------------------------------------------------------------------------//
// Export the mesh                                                            //
//----------------------------------------------------------------------------//

bool MeshExport::ExportMesh()
{
	// build the current animation state
	if(!theModel.buildCurrentState()) return false;

	// get selected node
	INode *pNode;
	pNode = m_pInterface->GetSelNode(0);

	if((m_pInterface->GetSelNodeCount() == 0) || (pNode == 0) || !Helper::IsMesh(pNode))
	{
		::MessageBox(NULL, "You must select a mesh to export.", PLUGIN_CAPTION, MB_OK | MB_ICONWARNING);
		return false;
	}

	// get the physique modifier
	Modifier *pModifier;
	pModifier = FindPhysiqueModifier(pNode);
	if(pModifier == 0)
	{
		::MessageBox(NULL, "There is no physique modifier!", PLUGIN_CAPTION, MB_OK | MB_ICONWARNING);
		return false;
	}

	// get the current time for export
	TimeValue time;
	time = m_pInterface->GetTime();

	// get the mesh
	BOOL bDelete;
	bDelete = FALSE;

	ObjectState os;
	os = pNode->EvalWorldState(time);

	Mesh *pMesh;
	pMesh = ((TriObject *)os.obj)->GetRenderMesh(time, pNode, theNullView, bDelete);

	// build all the materials
	if(!theModel.buildMaterials(pNode, pMesh))
	{
		if(bDelete) pMesh->DeleteThis();
		return false;
	}

	// create the mesh file
	std::ofstream file;
	file.open(m_strFilename, std::ios::out | std::ios::trunc | std::ios::binary);
	if(!file)
	{
        ::MessageBox (NULL, "Unable to create mesh-file!", PLUGIN_CAPTION, MB_OK | MB_ICONWARNING);
		return false;
	}

	// write magic identifier
	file.write(&Helper::MESH_FILE_MAGIC[0], 4);

	// get mesh transformation matrix
	Matrix3 tm;
	tm = pNode->GetObjectTM(time);
	Matrix3 tmRotation;
	tmRotation = tm;
	tmRotation.NoTrans();
	tmRotation.NoScale();

	// get material vector
	std::vector<Model::Material *>& vectorMaterial = theModel.getVectorMaterial();

	// write number vertices, bone influences, colors, texture coordinates and materials
	int vertexCount;
	vertexCount = pMesh->getNumVerts();
	m_boneInfluenceCount = 0; // will be written at the end!
	m_materialCount = 0; // will be written at the end!

	file.write((char *)&vertexCount, 4);
	file.write((char *)&m_boneInfluenceCount, 4);
	file.write((char *)&m_materialCount, 4);

	// make sure normals are built
	pMesh->checkNormals(TRUE);

	float *pNormals;
	pNormals = new float[vertexCount * 3];

	// build all normals
	int faceId;
	for(faceId = 0; faceId < pMesh->getNumFaces(); faceId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(25 + 15 * (faceId + 1) / pMesh->getNumFaces());


		// build vertex normals
		int vertexId;
		for(vertexId = 0; vertexId < 3; vertexId++)
		{
			int vertex;
			vertex = pMesh->faces[faceId].v[vertexId];

			Point3 normal;
			normal = GetVertexNormal(pMesh, faceId, vertex).Normalize();
			normal = normal * Inverse(tmRotation);
			normal = normal.Normalize();
			pNormals[vertex * 3] = normal.x;
			pNormals[vertex * 3 + 1] = normal.y;
			pNormals[vertex * 3 + 2] = normal.z;
		}
	}

	// export all vertices
	int vertexId;
	for(vertexId = 0; vertexId < vertexCount; vertexId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(40 + 15 * (vertexId + 1) / vertexCount);

		// export all bone influences
		Point3 vertex;
		vertex = pMesh->getVert(vertexId) * tm;

		if(!ExportBoneInfluence(file, pNode, pModifier, vertexId, vertex, pNormals))
		{
			delete [] pNormals;
			file.close();
			if(bDelete) pMesh->DeleteThis();
			return false;
		}
	}

	// free normal array
	delete [] pNormals;
/*
	// export all colors
	int colorId;
	for(colorId = 0; colorId < colorCount; colorId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(55 + 15 * (colorId + 1) / colorCount);

		VertColor color;
		color = pMesh->vertCol[colorId];
		unsigned char alpha = 255;

		file.write((char *)&color.x, 1);
		file.write((char *)&color.y, 1);
		file.write((char *)&color.z, 1);
		file.write((char *)&alpha, 1);
	}

	// export all texture coordinates
	int textureCoordinateId;
	for(textureCoordinateId = 0; textureCoordinateId < textureCoordinateCount; textureCoordinateId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(70 + 15 * (textureCoordinateId + 1) / textureCoordinateCount);

		UVVert uv;
		uv = pMesh->getTVert(textureCoordinateId);

		file.write((char *)&uv.x, 4);
		file.write((char *)&uv.y, 4);
	}
*/
	// export all materials
	int materialId;
	for(materialId = 0; materialId < vectorMaterial.size(); materialId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(85 + 15 * (materialId + 1) / vectorMaterial.size());

		// export material
		if(!ExportMaterial(file, pNode, materialId))
		{
			file.close();
			if(bDelete) pMesh->DeleteThis();
			return false;
		}
	}

	// write the bone influence and material count
	file.seekp(8);
	file.write((char *)&m_boneInfluenceCount, 4);
	file.write((char *)&m_materialCount, 4);

	// close the skeleton file
	file.close();

	// delete mesh instance if needed
	if(bDelete) pMesh->DeleteThis();

	return true;
}

//----------------------------------------------------------------------------//
// Find the physique modifier for a given node                                //
//----------------------------------------------------------------------------//

Modifier *MeshExport::FindPhysiqueModifier(INode *pNode)
{
	// get the object reference of the node
	Object *pObject;
	pObject = pNode->GetObjectRef();
	if(pObject == 0) return 0;

	// loop through all derived objects
	while(pObject->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		IDerivedObject *pDerivedObject;
		pDerivedObject = static_cast<IDerivedObject *>(pObject);

		// loop through all modifiers
		int stackId;
		for(stackId = 0; stackId < pDerivedObject->NumModifiers(); stackId++)
		{
			Modifier *pModifier;
			pModifier = pDerivedObject->GetModifier(stackId);

			// check if we found the physique modifier
			if(pModifier->ClassID() == Class_ID(PHYSIQUE_CLASS_ID_A, PHYSIQUE_CLASS_ID_B)) return pModifier;
		}

		// continue with next derived object
		pObject = pDerivedObject->GetObjRef();
	}

	return 0;
}

//----------------------------------------------------------------------------//
// Get the normal of a given vertex of a given face                           //
//----------------------------------------------------------------------------//

Point3 MeshExport::GetVertexNormal(Mesh *pMesh, int faceId, int vertexId)
{
	// get the "rendered" vertex
	RVertex *pRVertex;
	pRVertex = pMesh->getRVertPtr(vertexId);

	// get the face
	Face *pFace;
	pFace = &pMesh->faces[faceId];

	// get smoothing group of the face
	DWORD smGroup;
	smGroup = pFace->smGroup;

	// get number of normals
	int numNormals;
	numNormals = pRVertex->rFlags & NORCT_MASK;

	// check if normal is specified
	if(pRVertex->rFlags & SPECIFIED_NORMAL)
	{
		return pRVertex->rn.getNormal();
	}
	// check for a smoothing group then
	else if((numNormals > 0) && (smGroup != 0))
	{
		// If there is only one vertex is found in the rn member.
		if(numNormals == 1)
		{
			return pRVertex->rn.getNormal();
		}
		else
		{
			int normalId;
			for(normalId = 0; normalId < numNormals; normalId++)
			{
				if(pRVertex->ern[normalId].getSmGroup() & smGroup)
				{
					return pRVertex->ern[normalId].getNormal();
				}
			}
		}
	}

	// if all fails, return the face normal
	return pMesh->getFaceNormal(faceId);
}

//----------------------------------------------------------------------------//
// Progress callback function                                                 //
//----------------------------------------------------------------------------//

DWORD WINAPI MeshExport::ProgressFunction(LPVOID arg)
{
	return 0;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *MeshExport::AuthorName()
{
	return _T("Bruno 'Beosil' Heidelberger");
}

const TCHAR *MeshExport::CopyrightMessage()
{
	return _T("Copyright (C) 2001 Bruno 'Beosil' Heidelberger");
}

int MeshExport::DoExport(const TCHAR *name, ExpInterface *ei, Interface *i, BOOL suppressPrompts, DWORD options)
{
	m_strFilename = name;
	m_pExportInterface = ei;
	m_pInterface = i;

	// todo: show option dialog box
	// todo: export only selected nodes if options flag is set

	// export the mesh
	m_pInterface->ProgressStart(_T("Exporting Cal3D Mesh File..."), TRUE, ProgressFunction, 0);
	if(!theModel.create(m_pInterface)) return 0;
	if(!ExportMesh()) return 0;
	m_pInterface->ProgressEnd();

	return 1;
}

const TCHAR *MeshExport::Ext(int i)
{
	switch(i)
	{
	case 0:
		return _T("cmf");
	default:
		return _T("");
	}
}

int MeshExport::ExtCount()
{
	return 1;
}

const TCHAR *MeshExport::LongDesc()
{
	return _T("Cal3D Mesh File");
}

const TCHAR *MeshExport::OtherMessage1()
{
	return _T("");
}

const TCHAR *MeshExport::OtherMessage2()
{
	return _T("");
}

const TCHAR *MeshExport::ShortDesc()
{
	return _T("Cal3D Mesh File");
}

void MeshExport::ShowAbout(HWND hWnd)
{
}

unsigned int MeshExport::Version()
{
	return 10;
}

//----------------------------------------------------------------------------//

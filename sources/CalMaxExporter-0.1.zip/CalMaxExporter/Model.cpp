//----------------------------------------------------------------------------//
// Model.cpp                                                                  //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "Model.h"
#include "Helper.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

Model theModel;

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

Model::Model()
{
	m_pInterface = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

Model::~Model()
{
	// clear model
	clear();
}

//----------------------------------------------------------------------------//
// Add a material                                                             //
//----------------------------------------------------------------------------//

void Model::addMaterial(Mtl *pMtl)
{
	if(pMtl != 0)
	{
		// test if we have a standard material
		if(pMtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0))
		{
			StdMat *pStdMat = (StdMat *)pMtl;

			Material *pMaterial;
			pMaterial = new Material;

			pMaterial->strName = pStdMat->GetName();

			pMaterial->ambientColor = pStdMat->GetAmbient(0);
			pMaterial->diffuseColor = pStdMat->GetDiffuse(0);
			pMaterial->specularColor = pStdMat->GetSpecular(0);
			pMaterial->shininess = pStdMat->GetShininess(0);

			int mapId;
			for(mapId = 0; mapId < pMtl->NumSubTexmaps(); mapId++)
			{
				Texmap *pTexMap;
				pTexMap = pMtl->GetSubTexmap(mapId);

				if((pTexMap != 0) && (pStdMat->MapEnabled(mapId)))
				{
					MaterialMap *pMaterialMap;
					pMaterialMap = new MaterialMap;

					pMaterialMap->strName = pTexMap->GetName();
					pMaterialMap->channel = pTexMap->GetMapChannel();

					StdUVGen *pStdUVGen;
					pStdUVGen = (StdUVGen *)pTexMap->GetTheUVGen();

					if(pStdUVGen != 0)
					{
						pStdUVGen->GetUVTransform(pMaterialMap->uvMatrix);
					}
					else
					{
						pMaterialMap->uvMatrix.IdentityMatrix();
					}

					pMaterial->listMaterialMap.push_back(pMaterialMap);
				}
			}

			m_vectorMaterial.push_back(pMaterial);
		}
	}

	// add all submaterials
	int subId;
	for(subId = 0; subId < pMtl->NumSubMtls(); subId++)
	{
		addMaterial(pMtl->GetSubMtl(subId));
	}
}

//----------------------------------------------------------------------------//
// Build the initial skeleton state                                           //
//----------------------------------------------------------------------------//

bool Model::buildCurrentState()
{
	if(m_pInterface == 0) return false;

	// get current time
	TimeValue time;
	time = m_pInterface->GetTime();

	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		// adjust progress bar
		m_pInterface->ProgressUpdate(25 * (boneId + 1) / m_vectorBone.size());

		Bone *pBone;
		pBone = m_vectorBone[boneId];

		// make biped bone uniform scale
		if(Helper::IsBipedBone(pBone->pNode))
		{
			Helper::SetBipedUniform(pBone->pNode, TRUE);
		}

		// get transformation matrix of bone
		pBone->tm = Helper::GetBoneTM(pBone->pNode, time);

		// convert it to a relative transformation
		if(pBone->parentId != -1)
		{
			Matrix3 tmParent;
			tmParent = m_vectorBone[pBone->parentId]->tm;
			pBone->tmRelative = pBone->tm * Inverse(tmParent);
		}
		else
		{
			pBone->tmRelative = pBone->tm;
		}

		// convert biped bone uniform scale back
		if(Helper::IsBipedBone(pBone->pNode))
		{
			Helper::SetBipedUniform(pBone->pNode, FALSE);
		}
	}

	return true;
}

//----------------------------------------------------------------------------//
// Build all the keyframes of the model                                       //
//----------------------------------------------------------------------------//

bool Model::buildKeyframes(TimeValue start, TimeValue end, TimeValue step, TimeValue displacement)
{
	// clear current keyframes and prepare biped bones
	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		// delete all keyframes for the current bone
		clearKeyframes(boneId);
	}

	// make biped bone uniform scale
	setUniform(true);

	// loop through all keyframes
	TimeValue tick;
	for(tick = start; tick < end + step; tick += step)
	{
		m_pInterface->ProgressUpdate(25 + 50 * (tick - start + step) / (end - start + step));

		// adjust with displacement
		TimeValue time;
		time = tick + displacement;
		time = ((time - start) % (end - start + step)) + start;

		// loop through all bones
		int boneId;
		for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
		{
			Bone *pBone;
			pBone = m_vectorBone[boneId];

			// allocate a new keyframe
			Keyframe *pKeyframe;
			pKeyframe = new Keyframe;

			// set time of the keyframe (->tick!)
			pKeyframe->time = tick - start;

			// get transformation matrix of bone
			pKeyframe->tm = Helper::GetBoneTM(pBone->pNode, time);

			// convert it to a relative transformation
			Matrix3 tmRelative;
			if(pBone->parentId != -1)
			{
				Matrix3 tmParent;
				tmParent = m_vectorBone[pBone->parentId]->listKeyframe.back()->tm;;
				pKeyframe->tmRelative = pKeyframe->tm * Inverse(tmParent);
			}
			else
			{
				pKeyframe->tmRelative = pKeyframe->tm;
			}

			// insert keyframe into keyframe list
			pBone->listKeyframe.push_back(pKeyframe);
		}
	}

	// reset biped bones
	setUniform(false);

	return true;
}

//----------------------------------------------------------------------------//
// Build all the materials of the model                                       //
//----------------------------------------------------------------------------//

bool Model::buildMaterials(INode *pNode, Mesh *pMesh)
{
	// build all used materials
	addMaterial(pNode->GetMtl());

	// visit all faces
	int faceId;
	for(faceId = 0; faceId < pMesh->getNumFaces(); faceId++)
	{
		// update progress bar
		m_pInterface->ProgressUpdate(25 + 50 * (faceId + 1) / pMesh->getNumFaces());

		// get face
		Face *pFace;
		pFace = &pMesh->faces[faceId];

		// get material of the face
		int matId;
		matId = pFace->getMatID();

		Material *pMaterial;
		pMaterial = m_vectorMaterial[matId];
		if((matId < 0) || (matId >= m_vectorMaterial.size())) return false;

		if(pMesh->numCVerts > 0)
		{
			pMaterial->colorCount = 1;
		}
		else
		{
			pMaterial->colorCount = 0;
		}

		MaterialFace *pMaterialFace;
		pMaterialFace = new MaterialFace;

		MaterialVertex materialVertex;

		int vertexId;
		for(vertexId = 0; vertexId < 3; vertexId++)
		{
			materialVertex.listTextureCoordinate.clear();

			std::list<MaterialMap *>::iterator iteratorMaterialMap;
			for(iteratorMaterialMap = pMaterial->listMaterialMap.begin(); iteratorMaterialMap != pMaterial->listMaterialMap.end(); ++iteratorMaterialMap)
			{
				int channel;
				channel = (*iteratorMaterialMap)->channel;

				TextureCoordinate uvw;

				if(pMesh->mapSupport(channel))
				{
					TVFace *pTVFace;
					pTVFace = pMesh->mapFaces(channel);
					UVVert *pUVVert;
					pUVVert = pMesh->mapVerts(channel);

					UVVert uvVert;
					uvVert = pUVVert[pTVFace[faceId].t[vertexId]] * (*iteratorMaterialMap)->uvMatrix;

					uvw.u = uvVert.x;
					uvw.v = uvVert.y;
				}
				else if(pMesh->numTVerts > 0)
				{
					UVVert uvVert;
					uvVert = pMesh->tVerts[pMesh->tvFace[faceId].t[vertexId]] * (*iteratorMaterialMap)->uvMatrix;

					uvw.u = uvVert.x;
					uvw.v = uvVert.y;
				}
				else
				{
					uvw.u = 0.0f;
					uvw.v = 0.0f;
				}

				materialVertex.listTextureCoordinate.push_back(uvw);
			}

			if(pMesh->numCVerts > 0)
			{
				materialVertex.red = (unsigned char)(pMesh->vertCol[pMesh->vcFace[faceId].t[vertexId]].x * 255.0f);
				materialVertex.green = (unsigned char)(pMesh->vertCol[pMesh->vcFace[faceId].t[vertexId]].y * 255.0f);
				materialVertex.blue = (unsigned char)(pMesh->vertCol[pMesh->vcFace[faceId].t[vertexId]].z * 255.0f);
				materialVertex.alpha = 255;
			}
			else
			{
				materialVertex.red = 255;
				materialVertex.green = 255;
				materialVertex.blue = 255;
				materialVertex.alpha = 255;
			}

			pMaterialFace->v[vertexId] = -1;

			int id;
			std::list<MaterialVertex *>::iterator iteratorMaterialVertex;
			for(id = 0, iteratorMaterialVertex = pMaterial->listMaterialVertex.begin(); iteratorMaterialVertex != pMaterial->listMaterialVertex.end(); id++, ++iteratorMaterialVertex)
			{
				MaterialVertex *pMaterialVertex;
				pMaterialVertex = *iteratorMaterialVertex;

				if((pMaterialVertex->vertexId == pFace->v[vertexId])
					&& (pMaterialVertex->red == materialVertex.red)
					&& (pMaterialVertex->green == materialVertex.green)
					&& (pMaterialVertex->blue == materialVertex.blue)
					&& (pMaterialVertex->alpha == materialVertex.alpha))
				{
					std::list<TextureCoordinate>::iterator i1, i2;
					for(i1 = pMaterialVertex->listTextureCoordinate.begin(), i2 = materialVertex.listTextureCoordinate.begin();
						(i1 != pMaterialVertex->listTextureCoordinate.end()) && (i2 != materialVertex.listTextureCoordinate.end());
						++i1, ++i2)
					{
						if(((*i1).u != (*i2).u) || ((*i1).v != (*i2).v)) break;
					}

					if((i1 == pMaterialVertex->listTextureCoordinate.end()) && (i2 == materialVertex.listTextureCoordinate.end()))
					{
						pMaterialFace->v[vertexId] = id;
						break;
					}
				}
			}

			if(pMaterialFace->v[vertexId] == -1)
			{
				MaterialVertex *pMaterialVertex;
				pMaterialVertex = new MaterialVertex;

				pMaterialVertex->vertexId = pFace->v[vertexId];
				pMaterialVertex->listTextureCoordinate = materialVertex.listTextureCoordinate;
				pMaterialVertex->red = materialVertex.red;
				pMaterialVertex->green = materialVertex.green;
				pMaterialVertex->blue = materialVertex.blue;
				pMaterialVertex->alpha = materialVertex.alpha;

				pMaterial->listMaterialVertex.push_back(pMaterialVertex);

				pMaterialFace->v[vertexId] = id;
			}
		}

		pMaterial->listMaterialFace.push_back(pMaterialFace);
	}

	return true;
}

//----------------------------------------------------------------------------//
// Clear the model                                                            //
//----------------------------------------------------------------------------//

void Model::clear()
{
	// delete all materials
	int materialId;
	for(materialId = 0; materialId < m_vectorMaterial.size(); materialId++)
	{
		Material *pMaterial;
		pMaterial = m_vectorMaterial[materialId];

		// delete all material vertices
		while(!pMaterial->listMaterialVertex.empty())
		{
			MaterialVertex *pMaterialVertex;
			pMaterialVertex = pMaterial->listMaterialVertex.front();
			pMaterial->listMaterialVertex.pop_front();
			delete pMaterialVertex;
		}

		// delete all material faces
		while(!pMaterial->listMaterialFace.empty())
		{
			MaterialFace *pMaterialFace;
			pMaterialFace = pMaterial->listMaterialFace.front();
			pMaterial->listMaterialFace.pop_front();
			delete pMaterialFace;
		}

		// delete all material maps
		while(!pMaterial->listMaterialMap.empty())
		{
			MaterialMap *pMaterialMap;
			pMaterialMap = pMaterial->listMaterialMap.front();
			pMaterial->listMaterialMap.pop_front();
			delete pMaterialMap;
		}

		delete pMaterial;
	}

	m_vectorMaterial.clear();


	// delete all bones
	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		// delete all keyframes of the bone
		clearKeyframes(boneId);

		delete m_vectorBone[boneId];
	}

	m_vectorBone.clear();

	// clear the root bone id list
	m_listRootBoneId.clear();
}

//----------------------------------------------------------------------------//
// Clear all keyframes of the model for a given bone                          //
//----------------------------------------------------------------------------//

void Model::clearKeyframes(int boneId)
{
	// get bone from the given bone id
	Bone *pBone;
	pBone = getBone(boneId);
	if(pBone == 0) return;

	// delete all keyframes of the bone
	while(pBone->listKeyframe.size() > 0)
	{
		Keyframe *pKeyframe;
		pKeyframe = pBone->listKeyframe.front();
		pBone->listKeyframe.pop_front();
		delete pKeyframe;
	}
}

//----------------------------------------------------------------------------//
// Create the model                                                           //
//----------------------------------------------------------------------------//

bool Model::create(Interface *pInterface)
{
	m_pInterface = pInterface;

	// clear the current model
	clear();

	// build the bone hierarchy / skeleton
	std::stack<INode *> stackBone;
	std::stack<int> stackParentId;

	stackBone.push(m_pInterface->GetRootNode());

	while(!stackBone.empty())
	{
		// handle next node
		INode *pNode;
		pNode = stackBone.top();
		stackBone.pop();

		// test for delimiter
		if(pNode == 0)
		{
			stackParentId.pop();
			continue;
		}

		// check if this node is a bone
		if(Helper::IsBone(pNode))
		{
			// allocate new bone instance
			Bone *pBone;
			pBone = new Bone;

			// fill in bone data
			pBone->id = m_vectorBone.size();
			pBone->pNode = pNode;
			pBone->strName = pNode->GetName();
			pBone->bSelected = true;

			// link to parent bone
			if(stackParentId.empty())
			{
				pBone->parentId = -1;

				// insert bone into root bone list
				m_listRootBoneId.push_back(pBone->id);
			}
			else
			{
				int parentId;
				parentId = stackParentId.top();

				// insert bone into parent children list
				pBone->parentId = parentId;
				m_vectorBone[parentId]->listChildrenId.push_back(pBone->id);
			}

			// insert bone into bone vector
			m_vectorBone.push_back(pBone);

			// current bone id is parent id of the children
			stackParentId.push(pBone->id);

			// push a delimiter on the stack
			stackBone.push(0);
		}


		// push all children nodes on the stack
		int childId;
		for(childId = 0; childId < pNode->NumberOfChildren(); childId++)
		{
			stackBone.push(pNode->GetChildNode(childId));
		}
	}

	return true;
}

//----------------------------------------------------------------------------//
// Get the bone for a given bone id                                           //
//----------------------------------------------------------------------------//

Model::Bone *Model::getBone(int boneId)
{
	if((boneId < 0) || (boneId >= m_vectorBone.size())) return 0;

	return m_vectorBone[boneId];
}

//----------------------------------------------------------------------------//
// Get the bone id of a given node                                            //
//----------------------------------------------------------------------------//

int Model::getBoneId(INode *pNode)
{
	// loop through all bone nodes
	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		// check if we have found the bone
		if(m_vectorBone[boneId]->pNode == pNode) return boneId; 
	}

	return -1;
}

//----------------------------------------------------------------------------//
// Get the number of bones in this model                                      //
//----------------------------------------------------------------------------//

int Model::getBoneCount()
{
	return m_vectorBone.size();
}

//----------------------------------------------------------------------------//
// Get the root bone id list                                                  //
//----------------------------------------------------------------------------//

std::list<int>& Model::getListRootBoneId()
{
	return m_listRootBoneId;
}

//----------------------------------------------------------------------------//
// Get the number of selected bones in this model                             //
//----------------------------------------------------------------------------//

int Model::getSelectedBoneCount()
{
	int boneCount;
	boneCount = 0;

	// loop through all bone nodes
	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		// check if we have found a selected bone
		if(m_vectorBone[boneId]->bSelected) boneCount++;; 
	}

	return boneCount;
}

//----------------------------------------------------------------------------//
// Get the bone vector                                                        //
//----------------------------------------------------------------------------//

std::vector<Model::Bone *>& Model::getVectorBone()
{
	return m_vectorBone;
}

//----------------------------------------------------------------------------//
// Get the material vector                                                    //
//----------------------------------------------------------------------------//

std::vector<Model::Material *>& Model::getVectorMaterial()
{
	return m_vectorMaterial;
}

//----------------------------------------------------------------------------//
// Set/unset model to uniform scale                                           //
//----------------------------------------------------------------------------//

void Model::setUniform(bool bUniform)
{
	// set/unset all biped bones to uniform scaling
	int boneId;
	for(boneId = 0; boneId < m_vectorBone.size(); boneId++)
	{
		if(Helper::IsBipedBone(m_vectorBone[boneId]->pNode))
		{
			Helper::SetBipedUniform(m_vectorBone[boneId]->pNode, bUniform ? TRUE : FALSE);
		}
	}
}

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// MeshExportDesc.cpp                                                         //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "StdAfx.h"
#include "MeshExportDesc.h"
#include "MeshExport.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

MeshExportDesc theMeshExportDesc;

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

MeshExportDesc::MeshExportDesc()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

MeshExportDesc::~MeshExportDesc()
{
}

//----------------------------------------------------------------------------//
// Set the DLL instance handle of this plugin                                 //
//----------------------------------------------------------------------------//

void MeshExportDesc::SetInstance(HINSTANCE hInstance)
{
	m_hInstance = hInstance;
}

//----------------------------------------------------------------------------//
// Following methods have to be implemented to make it a valid plugin         //
//----------------------------------------------------------------------------//

const TCHAR *MeshExportDesc::Category()
{
	return _T("Game Utilities");
}

Class_ID MeshExportDesc::ClassID()
{
	return MESH_EXPORT_ID;
}

const TCHAR *MeshExportDesc::ClassName()
{
	return _T("Cal3D Mesh Export");
}

void *MeshExportDesc::Create(BOOL loading)
{
	return new MeshExport();
}

HINSTANCE MeshExportDesc::HInstance()
{
	return m_hInstance;
}

const TCHAR *MeshExportDesc::InternalName()
{
	return _T("Cal3D_Mesh_Export");
} 

int MeshExportDesc::IsPublic()
{
	return 1;
}

SClass_ID MeshExportDesc::SuperClassID()
{
	return SCENE_EXPORT_CLASS_ID;
}

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// vector.h                                                                   //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_VECTOR_H
#define CAL_VECTOR_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalQuaternion;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalVector
{
// member variables
public:
  float m_x;
  float m_y;
  float m_z;

// constructors/destructor
public:
  CalVector();
	CalVector(float x, float y, float z);
	virtual ~CalVector();

// member functions	
public:
  float& operator[](unsigned int index);
  const float& operator[](unsigned int index) const;
  void add(const CalVector& v);
  void blend(float factor, const CalVector& v);
  void transform(const CalQuaternion& q);
};

#endif

//----------------------------------------------------------------------------//

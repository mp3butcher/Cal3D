//----------------------------------------------------------------------------//
// corematerial.cpp                                                           //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "corematerial.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreMaterial::CalCoreMaterial()
{
  m_userData = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreMaterial::~CalCoreMaterial()
{
}

//----------------------------------------------------------------------------//
// Create a core material                                                     //
//----------------------------------------------------------------------------//

bool CalCoreMaterial::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core material                                                 //
//----------------------------------------------------------------------------//

void CalCoreMaterial::destroy()
{
}

//----------------------------------------------------------------------------//
// Get the ambient color                                                      //
//----------------------------------------------------------------------------//

CalCoreMaterial::Color& CalCoreMaterial::getAmbientColor()
{
  return m_ambientColor;
}

//----------------------------------------------------------------------------//
// Get the diffuse color                                                      //
//----------------------------------------------------------------------------//

CalCoreMaterial::Color& CalCoreMaterial::getDiffuseColor()
{
  return m_diffuseColor;
}

//----------------------------------------------------------------------------//
// Get the number of maps                                                     //
//----------------------------------------------------------------------------//

int CalCoreMaterial::getMapCount()
{
  return m_vectorMap.size();
}

//----------------------------------------------------------------------------//
// Get the (texture) filename of the given map                                //
//----------------------------------------------------------------------------//

std::string CalCoreMaterial::getMapFilename(int mapId)
{
  // check if the map id is valid
  if((mapId < 0) || (mapId >= (int)m_vectorMap.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return "";
  }

  return m_vectorMap[mapId].strFilename;
}

//----------------------------------------------------------------------------//
// Get the user data of this core material                                    //
//----------------------------------------------------------------------------//

Cal::UserData CalCoreMaterial::getMapUserData(int mapId)
{
  // check if the map id is valid
  if((mapId < 0) || (mapId >= (int)m_vectorMap.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorMap[mapId].userData;
}

//----------------------------------------------------------------------------//
// Get the shininess factor                                                   //
//----------------------------------------------------------------------------//

float CalCoreMaterial::getShininess()
{
  return m_shininess;
}

//----------------------------------------------------------------------------//
// Get the specular color                                                     //
//----------------------------------------------------------------------------//

CalCoreMaterial::Color& CalCoreMaterial::getSpecularColor()
{
  return m_specularColor;
}

//----------------------------------------------------------------------------//
// Get the user data of this core material                                    //
//----------------------------------------------------------------------------//

Cal::UserData CalCoreMaterial::getUserData()
{
  return m_userData;
}

//----------------------------------------------------------------------------//
// Get the map vector of this core material                                   //
//----------------------------------------------------------------------------//

std::vector<CalCoreMaterial::Map>& CalCoreMaterial::getVectorMap()
{
  return m_vectorMap;
}

//----------------------------------------------------------------------------//
// Reserve memory for all the material data                                   //
//----------------------------------------------------------------------------//

bool CalCoreMaterial::reserve(int mapCount)
{
  // reserve the space needed in all the vectors
  m_vectorMap.reserve(mapCount);
  m_vectorMap.resize(mapCount);

  return true;
}

//----------------------------------------------------------------------------//
// Set the user data of this core material                                    //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setUserData(int mapId, Cal::UserData userData)
{
  // check if the map id is valid
  if((mapId < 0) || (mapId >= (int)m_vectorMap.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return;
  }

  m_vectorMap[mapId].userData = userData;
}

//----------------------------------------------------------------------------//
// Set the ambient color of the core material                                 //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setAmbientColor(const CalCoreMaterial::Color& ambientColor)
{
  m_ambientColor = ambientColor;
}

//----------------------------------------------------------------------------//
// Set the diffuse color of the core material                                 //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setDiffuseColor(const CalCoreMaterial::Color& diffuseColor)
{
  m_diffuseColor = diffuseColor;
}

//----------------------------------------------------------------------------//
// Set a specific map in the core material instance                           //
//----------------------------------------------------------------------------//

bool CalCoreMaterial::setMap(int id, const Map& map)
{
  if((id < 0) || (id >= (int)m_vectorMap.size())) return false;

  m_vectorMap[id] = map;

  return true;
}

//----------------------------------------------------------------------------//
// Set the user data in a given map of this core material                     //
//----------------------------------------------------------------------------//

bool CalCoreMaterial::setMapUserData(int mapId, Cal::UserData userData)
{
  if((mapId < 0) || (mapId >= (int)m_vectorMap.size())) return false;

  m_vectorMap[mapId].userData = userData;

  return true;
}

//----------------------------------------------------------------------------//
// Set the shininess factor of the core material                              //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setShininess(float shininess)
{
  m_shininess = shininess;
}

//----------------------------------------------------------------------------//
// Set the specular color of the core material                                //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setSpecularColor(const CalCoreMaterial::Color& specularColor)
{
  m_specularColor = specularColor;
}

//----------------------------------------------------------------------------//
// Set the user data of this core material                                    //
//----------------------------------------------------------------------------//

void CalCoreMaterial::setUserData(Cal::UserData userData)
{
  m_userData = userData;
}

//----------------------------------------------------------------------------//

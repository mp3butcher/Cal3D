//----------------------------------------------------------------------------//
// submesh.h                                                                  //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_SUBMESH_H
#define CAL_SUBMESH_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalCoreSubmesh;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalSubmesh
{
// misc
public:
  typedef struct
  {
    int vertexId[3];
  } Face;

// member variables
protected:
  CalCoreSubmesh *m_pCoreSubmesh;
  std::vector<Face> m_vectorFace;
  int m_vertexCount;
  int m_faceCount;
  int m_coreMaterialId;

// constructors/destructor
public:
  CalSubmesh();
	virtual ~CalSubmesh();

// member functions	
public:
  bool create(CalCoreSubmesh *pCoreSubmesh);
  void destroy();
  CalCoreSubmesh *getCoreSubmesh();
  int getCoreMaterialId();
  int getFaceCount();
  int getFaces(int *pFaceBuffer);
  int getVertexCount();
  void setCoreMaterialId(int coreMaterialId);
  void setLodLevel(float lodLevel);
};

#endif

//----------------------------------------------------------------------------//

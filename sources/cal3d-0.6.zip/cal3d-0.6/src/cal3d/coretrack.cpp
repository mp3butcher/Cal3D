//----------------------------------------------------------------------------//
// coretrack.cpp                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coretrack.h"
#include "error.h"
#include "corekeyframe.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreTrack::CalCoreTrack()
{
  m_coreBoneId = -1;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreTrack::~CalCoreTrack()
{
  assert(m_mapCoreKeyframe.empty());
}

//----------------------------------------------------------------------------//
// Add a core keyframe instance to this core track                            //
//----------------------------------------------------------------------------//

bool CalCoreTrack::addCoreKeyframe(CalCoreKeyframe *pCoreKeyframe)
{
  m_mapCoreKeyframe.insert(std::make_pair(pCoreKeyframe->getTime(), pCoreKeyframe));

  return true;
}

//----------------------------------------------------------------------------//
// Create a core track                                                        //
//----------------------------------------------------------------------------//

bool CalCoreTrack::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core track                                                    //
//----------------------------------------------------------------------------//

void CalCoreTrack::destroy()
{
  // destroy all core keyframes
  std::map<float, CalCoreKeyframe *>::iterator iteratorCoreKeyframe;

  for(iteratorCoreKeyframe = m_mapCoreKeyframe.begin(); iteratorCoreKeyframe != m_mapCoreKeyframe.end(); ++iteratorCoreKeyframe)
  {
    CalCoreKeyframe *pCoreKeyframe;
    pCoreKeyframe = iteratorCoreKeyframe->second;

    pCoreKeyframe->destroy();
    delete pCoreKeyframe;
  }

  m_mapCoreKeyframe.clear();

  m_coreBoneId = -1;
}

//----------------------------------------------------------------------------//
// Get the core bone id of this core track instance                           //
//----------------------------------------------------------------------------//

int CalCoreTrack::getCoreBoneId()
{
  return m_coreBoneId;
}

//----------------------------------------------------------------------------//
// Get the map of the core keyframes                                          //
//----------------------------------------------------------------------------//

std::map<float, CalCoreKeyframe *>& CalCoreTrack::getMapCoreKeyframe()
{
  return m_mapCoreKeyframe;
}

//----------------------------------------------------------------------------//
// Get the state of the core track at a given time                            //
//----------------------------------------------------------------------------//

bool CalCoreTrack::getState(float time, float duration, CalVector& translation, CalQuaternion& rotation)
{
  std::map<float, CalCoreKeyframe *>::iterator iteratorCoreKeyframeBefore;
  std::map<float, CalCoreKeyframe *>::iterator iteratorCoreKeyframeAfter;

  // get the one core keyframe before and the one after the requested time
  bool bWrap;
  iteratorCoreKeyframeAfter = m_mapCoreKeyframe.upper_bound(time);

  // check if we have a wrap-around
  if(iteratorCoreKeyframeAfter == m_mapCoreKeyframe.end())
  {
    iteratorCoreKeyframeBefore = iteratorCoreKeyframeAfter;
    --iteratorCoreKeyframeBefore;
    iteratorCoreKeyframeAfter = m_mapCoreKeyframe.begin();

    bWrap = true;
  }
  else
  {
    if(iteratorCoreKeyframeAfter == m_mapCoreKeyframe.begin())
    {
      iteratorCoreKeyframeBefore = m_mapCoreKeyframe.end();
    }
    else
    {
      iteratorCoreKeyframeBefore = iteratorCoreKeyframeAfter;
    }

    --iteratorCoreKeyframeBefore;

    bWrap = false;
  }

  // get the two keyframes
  CalCoreKeyframe *pCoreKeyframeBefore;
  pCoreKeyframeBefore = iteratorCoreKeyframeBefore->second;
  CalCoreKeyframe *pCoreKeyframeAfter;
  pCoreKeyframeAfter = iteratorCoreKeyframeAfter->second;

  // calculate the blending factor between the two keyframe states
  float blendFactor;
  if(bWrap)
  {
    blendFactor = (time - pCoreKeyframeBefore->getTime()) / (duration - pCoreKeyframeBefore->getTime());
  }
  else
  {
    blendFactor = (time - pCoreKeyframeBefore->getTime()) / (pCoreKeyframeAfter->getTime() - pCoreKeyframeBefore->getTime());
  }

  // blend between the two keyframes
  translation = pCoreKeyframeBefore->getTranslation();
  translation.blend(blendFactor, pCoreKeyframeAfter->getTranslation());

  rotation = pCoreKeyframeBefore->getRotation();
  rotation.blend(blendFactor, pCoreKeyframeAfter->getRotation());

  return true;
}

//----------------------------------------------------------------------------//
// Set the core bone id of this core track instance                           //
//----------------------------------------------------------------------------//

bool CalCoreTrack::setCoreBoneId(int coreBoneId)
{
  if(coreBoneId < 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_coreBoneId = coreBoneId;

  return true;
}

//----------------------------------------------------------------------------//

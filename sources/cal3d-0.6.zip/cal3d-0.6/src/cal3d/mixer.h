//----------------------------------------------------------------------------//
// mixer.h                                                                    //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_MIXER_H
#define CAL_MIXER_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalModel;
class CalAnimation;
class CalAnimationAction;
class CalAnimationCycle;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalMixer
{
// member variables
public:
  CalModel *m_pModel;
  std::vector<CalAnimation *> m_vectorAnimation;
  std::list<CalAnimationAction *> m_listAnimationAction;
  std::list<CalAnimationCycle *> m_listAnimationCycle;
  float m_animationTime;
  float m_animationDuration;

// constructors/destructor
public:
  CalMixer();
	virtual ~CalMixer();

// member functions	
public:
  bool blendCycle(int id, float weight, float delay);
  bool clearCycle(int id, float delay);
  bool create(CalModel *pModel);
  void destroy();
  bool executeAction(int id, float delayIn, float delayOut);
  void updateAnimation(float deltaTime);
  void updateSkeleton();
};

#endif

//----------------------------------------------------------------------------//

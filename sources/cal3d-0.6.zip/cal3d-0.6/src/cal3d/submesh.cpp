//----------------------------------------------------------------------------//
// submesh.cpp                                                                //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "submesh.h"
#include "error.h"
#include "coresubmesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalSubmesh::CalSubmesh()
{
  m_pCoreSubmesh = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalSubmesh::~CalSubmesh()
{
}

//----------------------------------------------------------------------------//
// Create a submesh from a given core submesh                                 //
//----------------------------------------------------------------------------//

bool CalSubmesh::create(CalCoreSubmesh *pCoreSubmesh)
{
  if(pCoreSubmesh == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreSubmesh = pCoreSubmesh;

  // reserve memory for the face vector
  m_vectorFace.reserve(m_pCoreSubmesh->getFaceCount());
  m_vectorFace.resize(m_pCoreSubmesh->getFaceCount());

  // set the initial lod level
  setLodLevel(1.0f);

  m_coreMaterialId = -1;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this submesh                                                       //
//----------------------------------------------------------------------------//

void CalSubmesh::destroy()
{
  m_pCoreSubmesh = 0;
}

//----------------------------------------------------------------------------//
// Get the core mesh of this mesh                                             //
//----------------------------------------------------------------------------//

CalCoreSubmesh *CalSubmesh::getCoreSubmesh()
{
  return m_pCoreSubmesh;
}

//----------------------------------------------------------------------------//
// Get the core material id of the submesh                                    //
//----------------------------------------------------------------------------//

int CalSubmesh::getCoreMaterialId()
{
  return m_coreMaterialId;
}

//----------------------------------------------------------------------------//
// Get the number of faces                                                    //
//----------------------------------------------------------------------------//

int CalSubmesh::getFaceCount()
{
  return m_faceCount;
}

//----------------------------------------------------------------------------//
// Get the faces of the submesh                                               //
//----------------------------------------------------------------------------//

int CalSubmesh::getFaces(int *pFaceBuffer)
{
  // copy the face vector to the face buffer
  memcpy(pFaceBuffer, &m_vectorFace[0], m_faceCount * sizeof(Face));

  return m_faceCount;
}

//----------------------------------------------------------------------------//
// Get the number of vertices                                                 //
//----------------------------------------------------------------------------//

int CalSubmesh::getVertexCount()
{
  return m_vertexCount;
}

//----------------------------------------------------------------------------//
// Set the core material id of the submesh                                    //
//----------------------------------------------------------------------------//

void CalSubmesh::setCoreMaterialId(int coreMaterialId)
{
  m_coreMaterialId = coreMaterialId;
}

//----------------------------------------------------------------------------//
// Set the lod level of this submesh                                          //
//----------------------------------------------------------------------------//

void CalSubmesh::setLodLevel(float lodLevel)
{
  // clamp the lod level to [0.0, 1.0]
  if(lodLevel < 0.0f) lodLevel = 0.0f;
  if(lodLevel > 1.0f) lodLevel = 1.0f;

  // get the lod count of the core submesh
  int lodCount;
  lodCount = m_pCoreSubmesh->getLodCount();

  // calculate the target lod count
  lodCount = (int)((1.0f - lodLevel) * lodCount);

  // calculate the new number of vertices
  m_vertexCount = m_pCoreSubmesh->getVertexCount() - lodCount;

  // get face vector of the core submesh
  std::vector<CalCoreSubmesh::Face>& vectorFace = m_pCoreSubmesh->getVectorFace();

  // get face vector of the core submesh
  std::vector<CalCoreSubmesh::Vertex>& vectorVertex = m_pCoreSubmesh->getVectorVertex();

  // calculate the new number of faces
  m_faceCount = vectorFace.size();

  int vertexId;
  for(vertexId = vectorVertex.size() - 1; vertexId >= m_vertexCount; vertexId--)
  {
    m_faceCount -= vectorVertex[vertexId].faceCollapseCount;
  }

  // fill the face vector with the collapsed vertex ids
  int faceId;
  for(faceId = 0; faceId < m_faceCount; faceId++)
  {
    int vertexId;
    for(vertexId = 0; vertexId < 3; vertexId++)
    {
      // get the vertex id
      int collapsedVertexId;
      collapsedVertexId = vectorFace[faceId].vertexId[vertexId];

      // collapse the vertex id until it fits into the current lod level
      while(collapsedVertexId >= m_vertexCount) collapsedVertexId = vectorVertex[collapsedVertexId].collapseId;

      // store the collapse vertex id in the submesh face vector
      m_vectorFace[faceId].vertexId[vertexId] = collapsedVertexId;
    }
  }
}

//----------------------------------------------------------------------------//

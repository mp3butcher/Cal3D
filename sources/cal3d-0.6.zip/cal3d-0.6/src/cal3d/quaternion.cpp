//----------------------------------------------------------------------------//
// quaternion.cpp                                                             //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "quaternion.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalQuaternion::CalQuaternion() : m_x(0.0f), m_y(0.0f), m_z(0.0f), m_w(0.0f)
{
}

CalQuaternion::CalQuaternion(float x, float y, float z, float w) : m_x(x), m_y(y), m_z(z), m_w(w)
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalQuaternion::~CalQuaternion()
{
}

//----------------------------------------------------------------------------//
// [] operator                                                                //
//----------------------------------------------------------------------------//

float& CalQuaternion::operator[](unsigned int index)
{
  return (&m_x)[index];
}

//----------------------------------------------------------------------------//
// const [] operator                                                          //
//----------------------------------------------------------------------------//

const float& CalQuaternion::operator[](unsigned int index) const
{
  return (&m_x)[index];
}

//----------------------------------------------------------------------------//
// Interpolate between two quaternions                                        //
//----------------------------------------------------------------------------//

void CalQuaternion::blend(float factor, const CalQuaternion& q)
{
  float norm;
  norm = m_x * q.m_x + m_y * q.m_y + m_z * q.m_z + m_w * q.m_w;

  bool bFlip;
  bFlip = false;

  if(norm < 0.0f)
  {
    norm = -norm;
    bFlip = true;
  }

  float inv_factor;
  if(1.0f - norm < 0.000001f)
  {
    inv_factor = 1.0f - factor;
  }
  else
  {
    float theta;
    theta = acos(norm);

    float s;
    s = 1.0f / sin(theta);

    inv_factor = sin((1.0f - factor) * theta) * s;
    factor = sin(factor * theta) * s;
  }

  if(bFlip)
  {
    factor = -factor;
  }

  m_x = inv_factor * m_x + factor * q.m_x;
  m_y = inv_factor * m_y + factor * q.m_y;
  m_z = inv_factor * m_z + factor * q.m_z;
  m_w = inv_factor * m_w + factor * q.m_w;
}

//----------------------------------------------------------------------------//
// Multiply with a given quaternion                                           //
//----------------------------------------------------------------------------//

void CalQuaternion::product(const CalQuaternion& q)
{
  float x, y, z, w;
  x = m_x;
  y = m_y;
  z = m_z;
  w = m_w;

  m_x = w * q.m_x + x * q.m_w + y * q.m_z - z * q.m_y;
  m_y = w * q.m_y - x * q.m_z + y * q.m_w + z * q.m_x;
  m_z = w * q.m_z + x * q.m_y - y * q.m_x + z * q.m_w;
  m_w = w * q.m_w - x * q.m_x - y * q.m_y - z * q.m_z;
}

//----------------------------------------------------------------------------//
// Multiply with given attributes                                             //
//----------------------------------------------------------------------------//

void CalQuaternion::product(float tx, float ty, float tz)
{
  float x, y, z, w;
  x = m_x;
  y = m_y;
  z = m_z;
  w = m_w;

  m_x = w * tx          + y * tz - z * ty;
  m_y = w * ty - x * tz          + z * tx;
  m_z = w * tz + x * ty - y * tx;
  m_w =        - x * tx - y * ty - z * tz;
}

//----------------------------------------------------------------------------//
// Multiply with given attributes                                             //
//----------------------------------------------------------------------------//

void CalQuaternion::product(float tx, float ty, float tz, float tw)
{
  float x, y, z, w;
  x = m_x;
  y = m_y;
  z = m_z;
  w = m_w;

  m_x = w * tx + x * tw + y * tz - z * ty;
  m_y = w * ty - x * tz + y * tw + z * tx;
  m_z = w * tz + x * ty - y * tx + z * tw;
  m_w = w * tw - x * tx - y * ty - z * tz;
}

//----------------------------------------------------------------------------//

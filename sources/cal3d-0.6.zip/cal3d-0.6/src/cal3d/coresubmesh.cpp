//----------------------------------------------------------------------------//
// coresubmesh.cpp                                                            //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coresubmesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreSubmesh::CalCoreSubmesh()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreSubmesh::~CalCoreSubmesh()
{
  assert(m_vectorFace.empty());
  assert(m_vectorVertex.empty());
  assert(m_vectorvectorTextureCoordinate.empty());
}

//----------------------------------------------------------------------------//
// Create a core submesh                                                      //
//----------------------------------------------------------------------------//

bool CalCoreSubmesh::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core submesh                                                  //
//----------------------------------------------------------------------------//

void CalCoreSubmesh::destroy()
{
  // destroy all data
  m_vectorFace.clear();
  m_vectorVertex.clear();
  m_vectorvectorTextureCoordinate.clear();
}

//----------------------------------------------------------------------------//
// Get the core material thread id of this core submesh                       //
//----------------------------------------------------------------------------//

int CalCoreSubmesh::getCoreMaterialThreadId()
{
  return m_coreMaterialThreadId;
}

//----------------------------------------------------------------------------//
// Get the number of faces                                                    //
//----------------------------------------------------------------------------//

int CalCoreSubmesh::getFaceCount()
{
  return m_vectorFace.size();
}

//----------------------------------------------------------------------------//
// Get the number of LOD steps                                                //
//----------------------------------------------------------------------------//

int CalCoreSubmesh::getLodCount()
{
  return m_lodCount;
}

//----------------------------------------------------------------------------//
// Get the face vector                                                        //
//----------------------------------------------------------------------------//

std::vector<CalCoreSubmesh::Face>& CalCoreSubmesh::getVectorFace()
{
  return m_vectorFace;
}

//----------------------------------------------------------------------------//
// Get the texture coordinate vector vector                                   //
//----------------------------------------------------------------------------//

std::vector<std::vector<CalCoreSubmesh::TextureCoordinate> > & CalCoreSubmesh::getVectorVectorTextureCoordinate()
{
  return m_vectorvectorTextureCoordinate;
}

//----------------------------------------------------------------------------//
// Get the vertex vector                                                      //
//----------------------------------------------------------------------------//

std::vector<CalCoreSubmesh::Vertex>& CalCoreSubmesh::getVectorVertex()
{
  return m_vectorVertex;
}

//----------------------------------------------------------------------------//
// Get the number of vertices                                                 //
//----------------------------------------------------------------------------//

int CalCoreSubmesh::getVertexCount()
{
  return m_vectorVertex.size();
}

//----------------------------------------------------------------------------//
// Reserve memory for all the submesh data                                    //
//----------------------------------------------------------------------------//

bool CalCoreSubmesh::reserve(int vertexCount, int textureCoordinateCount, int faceCount)
{
  // reserve the space needed in all the vectors
  m_vectorVertex.reserve(vertexCount);
  m_vectorVertex.resize(vertexCount);

  m_vectorvectorTextureCoordinate.reserve(textureCoordinateCount);
  m_vectorvectorTextureCoordinate.resize(textureCoordinateCount);

  int textureCoordinateId;
  for(textureCoordinateId = 0; textureCoordinateId < textureCoordinateCount; textureCoordinateId++)
  {
    m_vectorvectorTextureCoordinate[textureCoordinateId].reserve(vertexCount);
    m_vectorvectorTextureCoordinate[textureCoordinateId].resize(vertexCount);
  }

  m_vectorFace.reserve(faceCount);
  m_vectorFace.resize(faceCount);

  return true;
}

//----------------------------------------------------------------------------//
// Set the core material id of this core submesh                              //
//----------------------------------------------------------------------------//

void CalCoreSubmesh::setCoreMaterialThreadId(int coreMaterialThreadId)
{
  m_coreMaterialThreadId = coreMaterialThreadId;
}

//----------------------------------------------------------------------------//
// Set a specific face in the core submesh instance                           //
//----------------------------------------------------------------------------//

bool CalCoreSubmesh::setFace(int id, const Face& face)
{
  if((id < 0) || (id >= (int)m_vectorFace.size())) return false;

  m_vectorFace[id] = face;

  return true;
}

//----------------------------------------------------------------------------//
// Set the LOD step count                                                     //
//----------------------------------------------------------------------------//

void CalCoreSubmesh::setLodCount(int lodCount)
{
  m_lodCount = lodCount;
}

//----------------------------------------------------------------------------//
// Set a specific texture coordinate in the core submesh instance             //
//----------------------------------------------------------------------------//

bool CalCoreSubmesh::setTextureCoordinate(int vertexId, int id, const TextureCoordinate& textureCoordinate)
{
  if((id < 0) || (id >= (int)m_vectorvectorTextureCoordinate.size())) return false;
  if((vertexId < 0) || (vertexId >= (int)m_vectorvectorTextureCoordinate[id].size())) return false;

  m_vectorvectorTextureCoordinate[id][vertexId] = textureCoordinate;

  return true;
}

//----------------------------------------------------------------------------//
// Set a specific vertex in the core submesh instance                         //
//----------------------------------------------------------------------------//

bool CalCoreSubmesh::setVertex(int id, const Vertex& vertex)
{
  if((id < 0) || (id >= (int)m_vectorVertex.size())) return false;

  m_vectorVertex[id] = vertex;

  return true;
}

//----------------------------------------------------------------------------//

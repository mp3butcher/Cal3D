//----------------------------------------------------------------------------//
// coremodel.cpp                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coremodel.h"
#include "error.h"
#include "coreskeleton.h"
#include "coreanimation.h"
#include "coremesh.h"
#include "corematerial.h"
#include "loader.h"
#include "saver.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreModel::CalCoreModel()
{
  m_pCoreSkeleton = 0;
  m_userData = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreModel::~CalCoreModel()
{
  assert(m_vectorCoreAnimation.empty());
  assert(m_vectorCoreMesh.empty());
  assert(m_vectorCoreMaterial.empty());
}

//----------------------------------------------------------------------------//
// Add a core animation instance to this core model                           //
//----------------------------------------------------------------------------//

int CalCoreModel::addCoreAnimation(CalCoreAnimation *pCoreAnimation)
{
  // get the id of the core animation
  int animationId;
  animationId = m_vectorCoreAnimation.size();

  m_vectorCoreAnimation.push_back(pCoreAnimation);

  return animationId;
}

//----------------------------------------------------------------------------//
// Add a core material instance to this core model                            //
//----------------------------------------------------------------------------//

int CalCoreModel::addCoreMaterial(CalCoreMaterial *pCoreMaterial)
{
  // get the id of the core material
  int materialId;
  materialId = m_vectorCoreMaterial.size();

  m_vectorCoreMaterial.push_back(pCoreMaterial);

  return materialId;
}

//----------------------------------------------------------------------------//
// Add a core mesh instance to this core model                                //
//----------------------------------------------------------------------------//

int CalCoreModel::addCoreMesh(CalCoreMesh *pCoreMesh)
{
  // get the id of the core mesh
  int meshId;
  meshId = m_vectorCoreMesh.size();

  m_vectorCoreMesh.push_back(pCoreMesh);

  return meshId;
}

//----------------------------------------------------------------------------//
// Create a core model                                                        //
//----------------------------------------------------------------------------//

bool CalCoreModel::create(const std::string& strName)
{
  m_strName = strName;

  return true;
}

//----------------------------------------------------------------------------//
// Create a material thread for a given material thread id                    //
//----------------------------------------------------------------------------//

bool CalCoreModel::createCoreMaterialThread(int coreMaterialThreadId)
{
  // insert an empty core material thread with a given id
  std::map<int, int> mapCoreMaterialThreadId;
  m_mapmapCoreMaterialThread.insert(std::make_pair(coreMaterialThreadId, mapCoreMaterialThreadId));

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core model                                                    //
//----------------------------------------------------------------------------//

void CalCoreModel::destroy()
{
  // destroy all core materials
  std::vector<CalCoreMaterial *>::iterator iteratorCoreMaterial;
  for(iteratorCoreMaterial = m_vectorCoreMaterial.begin(); iteratorCoreMaterial != m_vectorCoreMaterial.end(); ++iteratorCoreMaterial)
  {
    (*iteratorCoreMaterial)->destroy();
    delete (*iteratorCoreMaterial);
  }
  m_vectorCoreMaterial.clear();

  // destroy all core meshes
  std::vector<CalCoreMesh *>::iterator iteratorCoreMesh;
  for(iteratorCoreMesh = m_vectorCoreMesh.begin(); iteratorCoreMesh != m_vectorCoreMesh.end(); ++iteratorCoreMesh)
  {
    (*iteratorCoreMesh)->destroy();
    delete (*iteratorCoreMesh);
  }
  m_vectorCoreMesh.clear();

  // destroy all core animations
  std::vector<CalCoreAnimation *>::iterator iteratorCoreAnimation;
  for(iteratorCoreAnimation = m_vectorCoreAnimation.begin(); iteratorCoreAnimation != m_vectorCoreAnimation.end(); ++iteratorCoreAnimation)
  {
    (*iteratorCoreAnimation)->destroy();
    delete (*iteratorCoreAnimation);
  }
  m_vectorCoreAnimation.clear();

  if(m_pCoreSkeleton != 0)
  {
    m_pCoreSkeleton->destroy();
    delete m_pCoreSkeleton;
    m_pCoreSkeleton = 0;
  }

  m_strName.erase();
}

//----------------------------------------------------------------------------//
// Get the core animations for a given id                                     //
//----------------------------------------------------------------------------//

CalCoreAnimation *CalCoreModel::getCoreAnimation(int id)
{
  if((id < 0) || (id >= (int)m_vectorCoreAnimation.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorCoreAnimation[id];
}

//----------------------------------------------------------------------------//
// Get the number of core animations of this core model                       //
//----------------------------------------------------------------------------//

int CalCoreModel::getCoreAnimationCount()
{
  return m_vectorCoreAnimation.size();
}

//----------------------------------------------------------------------------//
// Get the core material for a given id                                       //
//----------------------------------------------------------------------------//

CalCoreMaterial *CalCoreModel::getCoreMaterial(int id)
{
  if((id < 0) || (id >= (int)m_vectorCoreMaterial.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorCoreMaterial[id];
}

//----------------------------------------------------------------------------//
// Get the number of core materials of this core model                        //
//----------------------------------------------------------------------------//

int CalCoreModel::getCoreMaterialCount()
{
  return m_vectorCoreMaterial.size();
}

//----------------------------------------------------------------------------//
// Get the core mesh for a given id                                           //
//----------------------------------------------------------------------------//

CalCoreMesh *CalCoreModel::getCoreMesh(int id)
{
  if((id < 0) || (id >= (int)m_vectorCoreMesh.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorCoreMesh[id];
}

//----------------------------------------------------------------------------//
// Get the number of core meshes of this core model                           //
//----------------------------------------------------------------------------//

int CalCoreModel::getCoreMeshCount()
{
  return m_vectorCoreMesh.size();
}

//----------------------------------------------------------------------------//
// Get core material id for a given material thread/set id                    //
//----------------------------------------------------------------------------//

int CalCoreModel::getCoreMaterialId(int coreMaterialThreadId, int setId)
{
  // find the core material thread
  std::map<int, std::map<int, int> >::iterator iteratorCoreMaterialThread;
  iteratorCoreMaterialThread = m_mapmapCoreMaterialThread.find(coreMaterialThreadId);
  if(iteratorCoreMaterialThread == m_mapmapCoreMaterialThread.end())
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // get the core material thread
  std::map<int, int>& coreMaterialThread = (*iteratorCoreMaterialThread).second;

  // find the material id for the given set
  std::map<int, int>::iterator iteratorSet;
  iteratorSet = coreMaterialThread.find(setId);
  if(iteratorSet == coreMaterialThread.end())
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  return (*iteratorSet).second;
}

//----------------------------------------------------------------------------//
// Get the core skeleton linked to this core model                            //
//----------------------------------------------------------------------------//

CalCoreSkeleton *CalCoreModel::getCoreSkeleton()
{
  return m_pCoreSkeleton;
}

//----------------------------------------------------------------------------//
// Get the user data of this core model                                       //
//----------------------------------------------------------------------------//

Cal::UserData CalCoreModel::getUserData()
{
  return m_userData;
}

//----------------------------------------------------------------------------//
// Load a core animation for this core model from a given file                //
//----------------------------------------------------------------------------//

int CalCoreModel::loadCoreAnimation(const std::string& strFilename)
{
  // the core skeleton has to be loaded already
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // load a new core animation
  CalLoader loader;
  CalCoreAnimation *pCoreAnimation;
  pCoreAnimation = loader.loadCoreAnimation(strFilename);
  if(pCoreAnimation == 0) return -1;

  // add core animation to this core model
  int animationId;
  animationId = addCoreAnimation(pCoreAnimation);
  if(animationId == -1)
  {
    delete pCoreAnimation;
    return -1;
  }

  return animationId;
}

//----------------------------------------------------------------------------//
// Load a core skeleton for this core model from a given file                 //
//----------------------------------------------------------------------------//

bool CalCoreModel::loadCoreSkeleton(const std::string& strFilename)
{
  // destroy the current core skeleton
  if(m_pCoreSkeleton != 0)
  {
    m_pCoreSkeleton->destroy();
    delete m_pCoreSkeleton;
  }

  // load a new core skeleton
  CalLoader loader;
  m_pCoreSkeleton = loader.loadCoreSkeleton(strFilename);
  if(m_pCoreSkeleton == 0) return false;

  return true;
}

//----------------------------------------------------------------------------//
// Load a core material for this core model from a given file                 //
//----------------------------------------------------------------------------//

int CalCoreModel::loadCoreMaterial(const std::string& strFilename)
{
  // the core skeleton has to be loaded already
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // load a new core material
  CalLoader loader;
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = loader.loadCoreMaterial(strFilename);
  if(pCoreMaterial == 0) return -1;

  // add core material to this core model
  int materialId;
  materialId = addCoreMaterial(pCoreMaterial);
  if(materialId == -1)
  {
    delete pCoreMaterial;
    return -1;
  }

  return materialId;
}

//----------------------------------------------------------------------------//
// Load a core mesh for this core model from a given file                     //
//----------------------------------------------------------------------------//

int CalCoreModel::loadCoreMesh(const std::string& strFilename)
{
  // the core skeleton has to be loaded already
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // load a new core mesh
  CalLoader loader;
  CalCoreMesh *pCoreMesh;
  pCoreMesh = loader.loadCoreMesh(strFilename);
  if(pCoreMesh == 0) return -1;

  // add core mesh to this core model
  int meshId;
  meshId = addCoreMesh(pCoreMesh);
  if(meshId == -1)
  {
    delete pCoreMesh;
    return -1;
  }

  return meshId;
}

//----------------------------------------------------------------------------//
// Save a given core animation for this core model to a given file            //
//----------------------------------------------------------------------------//

bool CalCoreModel::saveCoreAnimation(const std::string& strFilename, int id)
{
  // check if the core animation id is valid
  if((id < 0) || (id >= (int)m_vectorCoreAnimation.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // save the core animation
  CalSaver saver;
  if(!saver.saveCoreAnimation(strFilename, m_vectorCoreAnimation[id]))
  {
    return false;
  }

  return true;
}

//----------------------------------------------------------------------------//
// Save a given core material for this core model to a given file             //
//----------------------------------------------------------------------------//

bool CalCoreModel::saveCoreMaterial(const std::string& strFilename, int id)
{
  // check if the core material id is valid
  if((id < 0) || (id >= (int)m_vectorCoreMaterial.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // save the core animation
  CalSaver saver;
  if(!saver.saveCoreMaterial(strFilename, m_vectorCoreMaterial[id]))
  {
    return false;
  }

  return true;
}

//----------------------------------------------------------------------------//
// Save a given core mesh for this core model to a given file                 //
//----------------------------------------------------------------------------//

bool CalCoreModel::saveCoreMesh(const std::string& strFilename, int id)
{
  // check if the core mesh id is valid
  if((id < 0) || (id >= (int)m_vectorCoreMesh.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // save the core animation
  CalSaver saver;
  if(!saver.saveCoreMesh(strFilename, m_vectorCoreMesh[id]))
  {
    return false;
  }

  return true;
}

//----------------------------------------------------------------------------//
// Save the core skeleton for this core model to a given file                 //
//----------------------------------------------------------------------------//

bool CalCoreModel::saveCoreSkeleton(const std::string& strFilename)
{
  // check if we have a core skeleton in this code model
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // save the core skeleton
  CalSaver saver;
  if(!saver.saveCoreSkeleton(strFilename, m_pCoreSkeleton))
  {
    return false;
  }

  return true;
}

//----------------------------------------------------------------------------//
// Set a given material id as a given set id for a given material thread id   //
//----------------------------------------------------------------------------//

bool CalCoreModel::setCoreMaterialId(int coreMaterialThreadId, int setId, int coreMaterialId)
{
  // find the core material thread
  std::map<int, std::map<int, int> >::iterator iteratorCoreMaterialThread;
  iteratorCoreMaterialThread = m_mapmapCoreMaterialThread.find(coreMaterialThreadId);
  if(iteratorCoreMaterialThread == m_mapmapCoreMaterialThread.end())
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // get the core material thread
  std::map<int, int>& coreMaterialThread = (*iteratorCoreMaterialThread).second;

  // set the given set id in the core material thread to the given core material id
  coreMaterialThread.insert(std::make_pair(setId, coreMaterialId));

  return true;
}

//----------------------------------------------------------------------------//
// Set the user data of this core model                                       //
//----------------------------------------------------------------------------//

void CalCoreModel::setUserData(Cal::UserData userData)
{
  m_userData = userData;
}

//----------------------------------------------------------------------------//

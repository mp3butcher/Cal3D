//----------------------------------------------------------------------------//
// coreskeleton.cpp                                                           //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "coreskeleton.h"
#include "corebone.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreSkeleton::CalCoreSkeleton()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreSkeleton::~CalCoreSkeleton()
{
  assert(m_listRootCoreBoneId.empty());
  assert(m_vectorCoreBone.empty());
}

//----------------------------------------------------------------------------//
// Add a root core bone instance to this core model                           //
//----------------------------------------------------------------------------//

bool CalCoreSkeleton::addRootCoreBoneId(int boneId)
{
  m_listRootCoreBoneId.push_back(boneId);

  return true;
}

//----------------------------------------------------------------------------//
// Add a core bone instance to this core model                                //
//----------------------------------------------------------------------------//

int CalCoreSkeleton::addCoreBone(CalCoreBone *pCoreBone)
{
  // get next bone id
  int boneId;
  boneId = m_vectorCoreBone.size();

  m_vectorCoreBone.push_back(pCoreBone);

  return boneId;
}

//----------------------------------------------------------------------------//
// Calculate the state of the core skeleton                                   //
//----------------------------------------------------------------------------//

void CalCoreSkeleton::calculateState()
{
  // calculate all bone states of the skeleton
  std::list<int>::iterator iteratorRootCoreBoneId;
  for(iteratorRootCoreBoneId = m_listRootCoreBoneId.begin(); iteratorRootCoreBoneId != m_listRootCoreBoneId.end(); ++iteratorRootCoreBoneId)
  {
    m_vectorCoreBone[*iteratorRootCoreBoneId]->calculateState();
  }
}

//----------------------------------------------------------------------------//
// Create a core skeleton                                                     //
//----------------------------------------------------------------------------//

bool CalCoreSkeleton::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core skeleton                                                 //
//----------------------------------------------------------------------------//

void CalCoreSkeleton::destroy()
{
  // destroy all core animations
  std::vector<CalCoreBone *>::iterator iteratorCoreBone;
  for(iteratorCoreBone = m_vectorCoreBone.begin(); iteratorCoreBone != m_vectorCoreBone.end(); ++iteratorCoreBone)
  {
    (*iteratorCoreBone)->destroy();
    delete (*iteratorCoreBone);
  }

  m_vectorCoreBone.clear();

  // clear root bone id list
  m_listRootCoreBoneId.clear();
}

//----------------------------------------------------------------------------//
// Get the core bone for a given bone id                                      //
//----------------------------------------------------------------------------//

CalCoreBone *CalCoreSkeleton::getCoreBone(int boneId)
{
  return m_vectorCoreBone[boneId];
}

//----------------------------------------------------------------------------//
// Get the core bone id with a given name                                     //
//----------------------------------------------------------------------------//

int CalCoreSkeleton::getCoreBoneId(const std::string& strBone)
{
  int boneId;
  for(boneId = 0; boneId < (int)m_vectorCoreBone.size(); boneId++)
  {
    if(m_vectorCoreBone[boneId]->getName() == strBone) return boneId;
  }

  return -1;
}

//----------------------------------------------------------------------------//
// Get the list of the root core bones                                        //
//----------------------------------------------------------------------------//

std::list<int>& CalCoreSkeleton::getListRootCoreBoneId()
{
  return m_listRootCoreBoneId;
}

//----------------------------------------------------------------------------//
// Get the vector of the core bones                                           //
//----------------------------------------------------------------------------//

std::vector<CalCoreBone *>& CalCoreSkeleton::getVectorCoreBone()
{
  return m_vectorCoreBone;
}

//----------------------------------------------------------------------------//

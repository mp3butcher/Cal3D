//----------------------------------------------------------------------------//
// animation.cpp                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "animation.h"
#include "error.h"
#include "coreanimation.h"

//----------------------------------------------------------------------------//
// Static member variables initialization                                     //
//----------------------------------------------------------------------------//

const unsigned int CalAnimation::TYPE_NONE = 0;
const unsigned int CalAnimation::TYPE_CYCLE = 1;
const unsigned int CalAnimation::TYPE_POSE = 2;
const unsigned int CalAnimation::TYPE_ACTION = 3;

const unsigned int CalAnimation::STATE_NONE = 0;
const unsigned int CalAnimation::STATE_SYNC = 1;
const unsigned int CalAnimation::STATE_ASYNC = 2;
const unsigned int CalAnimation::STATE_IN = 3;
const unsigned int CalAnimation::STATE_STEADY = 4;
const unsigned int CalAnimation::STATE_OUT = 5;

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalAnimation::CalAnimation()
{
  m_pCoreAnimation = 0;
  m_type = TYPE_NONE;
  m_state = STATE_NONE;
  m_time = 0.0f;
  m_timeFactor = 1.0f;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalAnimation::~CalAnimation()
{
}

//----------------------------------------------------------------------------//
// Destroy this animation                                                     //
//----------------------------------------------------------------------------//

void CalAnimation::destroy()
{
  m_pCoreAnimation = 0;
}

//----------------------------------------------------------------------------//
// Get the core animation of this animation instance                          //
//----------------------------------------------------------------------------//

CalCoreAnimation *CalAnimation::getCoreAnimation()
{
  return m_pCoreAnimation;
}

//----------------------------------------------------------------------------//
// Get the state of this animation instance                                   //
//----------------------------------------------------------------------------//

unsigned int CalAnimation::getState()
{
  return m_state;
}

//----------------------------------------------------------------------------//
// Get the time of this animation instance                                    //
//----------------------------------------------------------------------------//

float CalAnimation::getTime()
{
  return m_time;
}

//----------------------------------------------------------------------------//
// Get the type of this animation instance                                    //
//----------------------------------------------------------------------------//

unsigned int CalAnimation::getType()
{
  return m_type;
}

//----------------------------------------------------------------------------//

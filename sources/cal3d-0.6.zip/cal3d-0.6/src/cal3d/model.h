//----------------------------------------------------------------------------//
// model.h                                                                    //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_MODEL_H
#define CAL_MODEL_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalCoreModel;
class CalSkeleton;
class CalMixer;
class CalRenderer;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalModel
{
// member variables
protected:
  CalCoreModel *m_pCoreModel;
  CalSkeleton *m_pSkeleton;
  CalMixer *m_pMixer;
  CalRenderer *m_pRenderer;
  Cal::UserData m_userData;

// constructors/destructor
public: 
	CalModel();
	virtual ~CalModel();
	
// member functions
public:
  bool create(CalCoreModel *pCoreModel);
  void destroy();
  CalCoreModel *getCoreModel();
  CalMixer *getMixer();
  CalRenderer *getRenderer();
  CalSkeleton *getSkeleton();
  Cal::UserData getUserData();
  void setMaterialSet(int setId);
  void setUserData(Cal::UserData userData);
  void update(float deltaTime);
};

#endif

//----------------------------------------------------------------------------//

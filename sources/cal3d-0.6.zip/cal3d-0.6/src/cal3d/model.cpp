//----------------------------------------------------------------------------//
// model.cpp                                                                  //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "model.h"
#include "skeleton.h"
#include "bone.h"
#include "mixer.h"
#include "renderer.h"
#include "coremodel.h"
#include "coreskeleton.h"
#include "coremesh.h"
#include "coresubmesh.h"
#include "mesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalModel::CalModel()
{
  m_pCoreModel = 0;
  m_pSkeleton = 0;
  m_pMixer = 0;
  m_pRenderer = 0;
  m_userData = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalModel::~CalModel()
{
}

//----------------------------------------------------------------------------//
// Create a model instance of a given type                                    //
//----------------------------------------------------------------------------//

bool CalModel::create(CalCoreModel *pCoreModel)
{
  if(pCoreModel == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreModel = pCoreModel;

  // allocate a new skeleton instance
  CalSkeleton *pSkeleton;
  pSkeleton = new CalSkeleton();
  if(pSkeleton == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return false;
  }

  // create the skeleton from the core skeleton
  if(!pSkeleton->create(pCoreModel->getCoreSkeleton()))
  {
    delete pSkeleton;
    return false;
  }

  m_pSkeleton = pSkeleton;

  // allocate a new mixer instance
  CalMixer *pMixer;
  pMixer = new CalMixer();
  if(pMixer == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    return false;
  }

  // create the mixer from this model
  if(!pMixer->create(this))
  {
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    delete pMixer;
    return false;
  }

  m_pMixer = pMixer;

  // allocate a new renderer instance
  CalRenderer *pRenderer;
  pRenderer = new CalRenderer();
  if(pRenderer == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    m_pMixer->destroy();
    delete m_pMixer;
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    return false;
  }

  // create the renderer from this model
  if(!pRenderer->create(this))
  {
    m_pMixer->destroy();
    delete m_pMixer;
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    delete pRenderer;
    return false;
  }

  m_pRenderer = pRenderer;

  // initialize the user data
  m_userData = 0;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this model instance                                                //
//----------------------------------------------------------------------------//

void CalModel::destroy()
{
  // destroy the renderer instance
  if(m_pRenderer != 0)
  {
    m_pRenderer->destroy();
    delete m_pRenderer;
    m_pRenderer = 0;
  }

  // destroy the mixer instance
  if(m_pMixer != 0)
  {
    m_pMixer->destroy();
    delete m_pMixer;
    m_pMixer = 0;
  }

  // destroy the skeleton instance
  if(m_pSkeleton != 0)
  {
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    m_pSkeleton = 0;
  }

  m_pCoreModel = 0;
}

//----------------------------------------------------------------------------//
// Get the core model instance of this model                                  //
//----------------------------------------------------------------------------//

CalCoreModel *CalModel::getCoreModel()
{
  return m_pCoreModel;
}

//----------------------------------------------------------------------------//
// Get the mixer instance of this model                                       //
//----------------------------------------------------------------------------//

CalMixer *CalModel::getMixer()
{
  return m_pMixer;
}

//----------------------------------------------------------------------------//
// Get the renderer instance of this model                                    //
//----------------------------------------------------------------------------//

CalRenderer *CalModel::getRenderer()
{
  return m_pRenderer;
}

//----------------------------------------------------------------------------//
// Get the skeleton instance of this model                                    //
//----------------------------------------------------------------------------//

CalSkeleton *CalModel::getSkeleton()
{
  return m_pSkeleton;
}

//----------------------------------------------------------------------------//
// Get the user data of this model                                            //
//----------------------------------------------------------------------------//

Cal::UserData CalModel::getUserData()
{
  return m_userData;
}

//----------------------------------------------------------------------------//
// Set the material set id of the mesh                                        //
//----------------------------------------------------------------------------//

void CalModel::setMaterialSet(int setId)
{
  // get the mesh vector from the renderer
  std::vector<CalMesh *>& vectorMesh = m_pRenderer->getVectorMesh();

  // set material set in all meshes
  int meshId;
  for(meshId = 0; meshId < (int)vectorMesh.size(); meshId++)
  {
    vectorMesh[meshId]->setMaterialSet(setId);
  }
}

//----------------------------------------------------------------------------//
// Set the user data of this model                                            //
//----------------------------------------------------------------------------//

void CalModel::setUserData(Cal::UserData userData)
{
  m_userData = userData;
}

//----------------------------------------------------------------------------//
// Update this model with a given delta time                                  //
//----------------------------------------------------------------------------//

void CalModel::update(float deltaTime)
{
  m_pMixer->updateAnimation(deltaTime);
  m_pMixer->updateSkeleton();
}

//----------------------------------------------------------------------------//

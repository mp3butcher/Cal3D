//----------------------------------------------------------------------------//
// corebone.cpp                                                               //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "corebone.h"
#include "coreskeleton.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreBone::CalCoreBone()
{
  m_pCoreSkeleton = 0;
  m_parentId = -1;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreBone::~CalCoreBone()
{
  assert(m_listChildId.empty());
}

//----------------------------------------------------------------------------//
// Add a child to this core bone                                              //
//----------------------------------------------------------------------------//

bool CalCoreBone::addChildId(int childId)
{
  m_listChildId.push_back(childId);

  return true;
}

//----------------------------------------------------------------------------//
// Calculate the state of the core bone                                       //
//----------------------------------------------------------------------------//

void CalCoreBone::calculateState()
{
  if(m_parentId == -1)
  {
    // no parent, this means absolute state == relative state
    m_translationAbsolute = m_translation;
    m_rotationAbsolute = m_rotation;
  }
  else
  {
    // get the parent bone
    CalCoreBone *pParent;
    pParent = m_pCoreSkeleton->getCoreBone(m_parentId);

    // transform relative state with the absolute state of the parent
    m_translationAbsolute = m_translation;
    m_translationAbsolute.transform(pParent->getRotationAbsolute());
    m_translationAbsolute.add(pParent->getTranslationAbsolute());

    m_rotationAbsolute = pParent->getRotationAbsolute();
    m_rotationAbsolute.product(m_rotation);
  }

  // calculate all child bones
  std::list<int>::iterator iteratorChildId;
  for(iteratorChildId = m_listChildId.begin(); iteratorChildId != m_listChildId.end(); ++iteratorChildId)
  {
    m_pCoreSkeleton->getCoreBone(*iteratorChildId)->calculateState();
  }
}

//----------------------------------------------------------------------------//
// Create a core bone                                                         //
//----------------------------------------------------------------------------//

bool CalCoreBone::create(const std::string& strName)
{
  m_strName = strName;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core bone                                                     //
//----------------------------------------------------------------------------//

void CalCoreBone::destroy()
{
  // clear children id list
  m_listChildId.clear();

  m_parentId = -1;
  m_strName.erase();
}

//----------------------------------------------------------------------------//
// Get the list of the children                                               //
//----------------------------------------------------------------------------//

std::list<int>& CalCoreBone::getListChildId()
{
  return m_listChildId;
}

//----------------------------------------------------------------------------//
// Get the name of this core bone instance                                    //
//----------------------------------------------------------------------------//

const std::string& CalCoreBone::getName()
{
  return m_strName;
}

//----------------------------------------------------------------------------//
// Get the parent bone id                                                     //
//----------------------------------------------------------------------------//

int CalCoreBone::getParentId()
{
  return m_parentId;
}

//----------------------------------------------------------------------------//
// Get the rotation of this core bone                                         //
//----------------------------------------------------------------------------//

const CalQuaternion& CalCoreBone::getRotation()
{
  return m_rotation;
}

//----------------------------------------------------------------------------//
// Get the absolute rotation of this core bone                                //
//----------------------------------------------------------------------------//

const CalQuaternion& CalCoreBone::getRotationAbsolute()
{
  return m_rotationAbsolute;
}

//----------------------------------------------------------------------------//
// Get the translation of this core bone                                      //
//----------------------------------------------------------------------------//

const CalVector& CalCoreBone::getTranslation()
{
  return m_translation;
}

//----------------------------------------------------------------------------//
// Get the absolute translation of this core bone                             //
//----------------------------------------------------------------------------//

const CalVector& CalCoreBone::getTranslationAbsolute()
{
  return m_translationAbsolute;
}

//----------------------------------------------------------------------------//
// Get the user data of this core bone                                        //
//----------------------------------------------------------------------------//

Cal::UserData CalCoreBone::getUserData()
{
  return m_userData;
}

//----------------------------------------------------------------------------//
// Set the core skeleton of this core bone                                    //
//----------------------------------------------------------------------------//

void CalCoreBone::setCoreSkeleton(CalCoreSkeleton *pCoreSkeleton)
{
  m_pCoreSkeleton = pCoreSkeleton;
}

//----------------------------------------------------------------------------//
// Set the parent core bone of this core bone                                 //
//----------------------------------------------------------------------------//

void CalCoreBone::setParentId(int parentId)
{
  m_parentId = parentId;
}

//----------------------------------------------------------------------------//
// Set the rotation quaternion of this core bone                              //
//----------------------------------------------------------------------------//

void CalCoreBone::setRotation(const CalQuaternion& rotation)
{
  m_rotation = rotation;
}

//----------------------------------------------------------------------------//
// Set the translation vector of this core bone                               //
//----------------------------------------------------------------------------//

void CalCoreBone::setTranslation(const CalVector& translation)
{
  m_translation = translation;
}

//----------------------------------------------------------------------------//
// Set the user data of this core bone                                        //
//----------------------------------------------------------------------------//

void CalCoreBone::setUserData(Cal::UserData userData)
{
  m_userData = userData;
}

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// renderer.cpp                                                               //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "renderer.h"
#include "coremodel.h"
#include "model.h"
#include "coremesh.h"
#include "mesh.h"
#include "submesh.h"
#include "skeleton.h"
#include "bone.h"
#include "corematerial.h"
#include "coresubmesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalRenderer::CalRenderer()
{
  m_pSelectedSubmesh = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalRenderer::~CalRenderer()
{
  assert(m_vectorMesh.empty());
}

//----------------------------------------------------------------------------//
// Attach a new mesh with a given id to this renderer                         //
//----------------------------------------------------------------------------//

bool CalRenderer::attachMesh(int coreMeshId)
{
  // get the core model
  CalCoreModel *pCoreModel;
  pCoreModel = m_pModel->getCoreModel();

  // check if the id is valid
  if((coreMeshId < 0) ||(coreMeshId >= pCoreModel->getCoreMeshCount()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // get the core mesh
  CalCoreMesh *pCoreMesh;
  pCoreMesh = pCoreModel->getCoreMesh(coreMeshId);

  // check if the mesh is already attached
  int meshId;
  for(meshId = 0; meshId < (int)m_vectorMesh.size(); meshId++)
  {
    // check if we found the matching mesh
    if(m_vectorMesh[meshId]->getCoreMesh() == pCoreMesh)
    {
      // mesh is already active -> do nothing
      return true;
    }
  }

  // allocate a new mesh instance
  CalMesh *pMesh;
  pMesh = new CalMesh();
  if(pMesh == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return false;
  }

  // create the new mesh instance
  if(!pMesh->create(pCoreMesh))
  {
    delete pMesh;
    return false;
  }

  // set model in the mesh instance
  pMesh->setModel(m_pModel);

  // insert the new mesh into the active list
  m_vectorMesh.push_back(pMesh);

  return true;
}

//----------------------------------------------------------------------------//
// Initialize the rendering of the model                                      //
//----------------------------------------------------------------------------//

bool CalRenderer::beginRendering()
{
  // check if there are any meshes attached to the model
  if(m_vectorMesh.size() == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // select the default submesh
  m_pSelectedSubmesh = m_vectorMesh[0]->getSubmesh(0);
  if(m_pSelectedSubmesh == 0) return false;

  return true;
}

//----------------------------------------------------------------------------//
// Create a renderer instance from a given core model                         //
//----------------------------------------------------------------------------//

bool CalRenderer::create(CalModel *pModel)
{
  if(pModel == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pModel = pModel;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this renderer instance                                             //
//----------------------------------------------------------------------------//

void CalRenderer::destroy()
{
  // destroy all active meshes
  int meshId;
  for(meshId = 0; meshId < (int)m_vectorMesh.size(); meshId++)
  {
    m_vectorMesh[meshId]->destroy();
    delete m_vectorMesh[meshId];
  }
  m_vectorMesh.clear();

  m_pModel = 0;
}

//----------------------------------------------------------------------------//
// Detach an active mesh with a given id from this renderer                   //
//----------------------------------------------------------------------------//

bool CalRenderer::detachMesh(int coreMeshId)
{
  // get the core model
  CalCoreModel *pCoreModel;
  pCoreModel = m_pModel->getCoreModel();

  // check if the id is valid
  if((coreMeshId < 0) ||(coreMeshId >= pCoreModel->getCoreMeshCount()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // get the core mesh
  CalCoreMesh *pCoreMesh;
  pCoreMesh = pCoreModel->getCoreMesh(coreMeshId);

  // find the mesh for the given id
  std::vector<CalMesh *>::iterator iteratorMesh;
  for(iteratorMesh = m_vectorMesh.begin(); iteratorMesh != m_vectorMesh.end(); ++iteratorMesh)
  {
    // get the mesh
    CalMesh *pMesh;
    pMesh = *iteratorMesh;

    // check if we found the matching mesh
    if(pMesh->getCoreMesh() == pCoreMesh)
    {
      // destroy the mesh
      pMesh->destroy();
      delete pMesh;

      // erase the mesh out of the active mesh list
      m_vectorMesh.erase(iteratorMesh);

      return true;
    }
  }

  return false;
}

//----------------------------------------------------------------------------//
// End the rendering of the model                                             //
//----------------------------------------------------------------------------//

void CalRenderer::endRendering()
{
  // clear selected submesh
  m_pSelectedSubmesh = 0;
}

//----------------------------------------------------------------------------//
// Get the ambient color of the selected mesh/submesh                         //
//----------------------------------------------------------------------------//

void CalRenderer::getAmbientColor(unsigned char *pColorBuffer)
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0)
  {
    // write default values to the color buffer
    pColorBuffer[0] = 0;
    pColorBuffer[1] = 0;
    pColorBuffer[2] = 0;
    pColorBuffer[3] = 0;

    return;
  }

  // get the ambient color of the material
  CalCoreMaterial::Color& color = pCoreMaterial->getAmbientColor();

  // write it to the color buffer
  pColorBuffer[0] = color.red;
  pColorBuffer[1] = color.green;
  pColorBuffer[2] = color.blue;
  pColorBuffer[3] = color.alpha;
}

//----------------------------------------------------------------------------//
// Get the diffuse color of the selected mesh/submesh                         //
//----------------------------------------------------------------------------//

void CalRenderer::getDiffuseColor(unsigned char *pColorBuffer)
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0)
  {
    // write default values to the color buffer
    pColorBuffer[0] = 192;
    pColorBuffer[1] = 192;
    pColorBuffer[2] = 192;
    pColorBuffer[3] = 192;

    return;
  }

  // get the diffuse color of the material
  CalCoreMaterial::Color& color = pCoreMaterial->getDiffuseColor();

  // write it to the color buffer
  pColorBuffer[0] = color.red;
  pColorBuffer[1] = color.green;
  pColorBuffer[2] = color.blue;
  pColorBuffer[3] = color.alpha;
}

//----------------------------------------------------------------------------//
// Get the number of faces of the selected mesh/submesh                       //
//----------------------------------------------------------------------------//

int CalRenderer::getFaceCount()
{
  return m_pSelectedSubmesh->getFaceCount();
}

//----------------------------------------------------------------------------//
// Get the faces of the selected mesh/submesh                                 //
//----------------------------------------------------------------------------//

int CalRenderer::getFaces(int *pFaceBuffer)
{
  return m_pSelectedSubmesh->getFaces(pFaceBuffer);
}

//----------------------------------------------------------------------------//
// Get the number of maps in the selected mesh/submesh                        //
//----------------------------------------------------------------------------//

int CalRenderer::getMapCount()
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0) return 0;

  return pCoreMaterial->getMapCount();
}

//----------------------------------------------------------------------------//
// Get the user data stored in the given map of the selected mesh/submesh     //
//----------------------------------------------------------------------------//

Cal::UserData CalRenderer::getMapUserData(int mapId)
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0) return 0;

  // get the map vector
  std::vector<CalCoreMaterial::Map>& vectorMap = pCoreMaterial->getVectorMap();

  // check if the map id is valid
  if((mapId < 0) || (mapId >= (int)vectorMap.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return vectorMap[mapId].userData;
}

//----------------------------------------------------------------------------//
// Get the number of meshes                                                   //
//----------------------------------------------------------------------------//

int CalRenderer::getMeshCount()
{
  return m_vectorMesh.size();
}

//----------------------------------------------------------------------------//
// Get the transformed normals of the selected mesh/submesh                   //
//----------------------------------------------------------------------------//

int CalRenderer::getNormals(float *pNormalBuffer)
{
  // get bone vector of the skeleton
  std::vector<CalBone *>& vectorBone = m_pModel->getSkeleton()->getVectorBone();

  // get vertex vector of the submesh
  std::vector<CalCoreSubmesh::Vertex>& vectorVertex = m_pSelectedSubmesh->getCoreSubmesh()->getVectorVertex();

  // get the number of vertices
  int vertexCount;
  vertexCount = m_pSelectedSubmesh->getVertexCount();

  // calculate normal for all submesh vertices
  int vertexId;
  for(vertexId = 0; vertexId < vertexCount; vertexId++)
  {
    // get the vertex
    CalCoreSubmesh::Vertex& vertex = vectorVertex[vertexId];

    // initialize normal
    float nx, ny, nz;
    nx = 0.0f;
    ny = 0.0f;
    nz = 0.0f;

    // blend together all vertex influences
    int influenceId;
    for(influenceId = 0; influenceId < (int)vertex.vectorInfluence.size(); influenceId++)
    {
      // get the influence
      CalCoreSubmesh::Influence& influence = vertex.vectorInfluence[influenceId];

      // get the bone of the influence vertex
      CalBone *pBone;
      pBone = vectorBone[influence.boneId];

      // transform normal with current state of the bone
      CalVector v(influence.nx, influence.ny, influence.nz);
      v.transform(pBone->getRotationAbsolute());

      nx += influence.weight * v.m_x;
      ny += influence.weight * v.m_y;
      nz += influence.weight * v.m_z;
    }

    // re-normalize normal
    float scale;
    scale = 1.0f / sqrt(nx * nx + ny * ny + nz * nz);

    // save normal position
    pNormalBuffer[0] = nx * scale;
    pNormalBuffer[1] = ny * scale;
    pNormalBuffer[2] = nz * scale;

    // next vertex position in buffer
    pNormalBuffer += 3;
  }

  return vertexCount;
}

//----------------------------------------------------------------------------//
// Get the shininess factor of the selected core submesh                      //
//----------------------------------------------------------------------------//

float CalRenderer::getShininess()
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0) return 50.0f;

  return pCoreMaterial->getShininess();
}

//----------------------------------------------------------------------------//
// Get the specular color of the selected mesh/submesh                        //
//----------------------------------------------------------------------------//

void CalRenderer::getSpecularColor(unsigned char *pColorBuffer)
{
  // get the core material
  CalCoreMaterial *pCoreMaterial;
  pCoreMaterial = m_pModel->getCoreModel()->getCoreMaterial(m_pSelectedSubmesh->getCoreMaterialId());
  if(pCoreMaterial == 0)
  {
    // write default values to the color buffer
    pColorBuffer[0] = 255;
    pColorBuffer[1] = 255;
    pColorBuffer[2] = 255;
    pColorBuffer[3] = 0;

    return;
  }

  // get the specular color of the material
  CalCoreMaterial::Color& color = pCoreMaterial->getSpecularColor();

  // write it to the color buffer
  pColorBuffer[0] = color.red;
  pColorBuffer[1] = color.green;
  pColorBuffer[2] = color.blue;
  pColorBuffer[3] = color.alpha;
}

//----------------------------------------------------------------------------//
// Get the number of submeshes in a given mesh                                //
//----------------------------------------------------------------------------//

int CalRenderer::getSubmeshCount(int meshId)
{
  // check if the mesh id is valid
  if((meshId < 0) || (meshId >= (int)m_vectorMesh.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorMesh[meshId]->getSubmeshCount();
}

//----------------------------------------------------------------------------//
// Get the texture coordinates of a given map id of the selected mesh/submesh //
//----------------------------------------------------------------------------//

int CalRenderer::getTextureCoordinates(int mapId, float *pTextureCoordinateBuffer)
{
  // get the texture coordinate vector vector
  std::vector<std::vector<CalCoreSubmesh::TextureCoordinate> >& vectorvectorTextureCoordinate = m_pSelectedSubmesh->getCoreSubmesh()->getVectorVectorTextureCoordinate();

  // check if the map id is valid
  if((mapId < 0) || (mapId >= (int)vectorvectorTextureCoordinate.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // get the number of texture coordinates to return
  int textureCoordinateCount;
  textureCoordinateCount = m_pSelectedSubmesh->getVertexCount();

  // copy the texture coordinate vector to the face buffer
  memcpy(pTextureCoordinateBuffer, &vectorvectorTextureCoordinate[mapId][0], textureCoordinateCount * sizeof(CalCoreSubmesh::TextureCoordinate));

  return textureCoordinateCount;
}

//----------------------------------------------------------------------------//
// Get the mesh vector                                                        //
//----------------------------------------------------------------------------//

std::vector<CalMesh *>& CalRenderer::getVectorMesh()
{
  return m_vectorMesh;
}

//----------------------------------------------------------------------------//
// Get the number of vertices in a given mesh/meshid                          //
//----------------------------------------------------------------------------//

int CalRenderer::getVertexCount()
{
  return m_pSelectedSubmesh->getVertexCount();
}

//----------------------------------------------------------------------------//
// Get the transformed vertices of the selected mesh/submesh                  //
//----------------------------------------------------------------------------//

int CalRenderer::getVertices(float *pVertexBuffer)
{
  // get bone vector of the skeleton
  std::vector<CalBone *>& vectorBone = m_pModel->getSkeleton()->getVectorBone();

  // get vertex vector of the submesh
  std::vector<CalCoreSubmesh::Vertex>& vectorVertex = m_pSelectedSubmesh->getCoreSubmesh()->getVectorVertex();

  // get the number of vertices
  int vertexCount;
  vertexCount = m_pSelectedSubmesh->getVertexCount();

  // calculate all submesh vertices
  int vertexId;
  for(vertexId = 0; vertexId < vertexCount; vertexId++)
  {
    // get the vertex
    CalCoreSubmesh::Vertex& vertex = vectorVertex[vertexId];

    // initialize vertex
    float x, y, z;
    x = 0.0f;
    y = 0.0f;
    z = 0.0f;

    // blend together all vertex influences
    int influenceId;
    for(influenceId = 0; influenceId < (int)vertex.vectorInfluence.size(); influenceId++)
    {
      // get the influence
      CalCoreSubmesh::Influence& influence = vertex.vectorInfluence[influenceId];

      // get the bone of the influence vertex
      CalBone *pBone;
      pBone = vectorBone[influence.boneId];

      // transform vertex with current state of the bone
      CalVector v(influence.x, influence.y, influence.z);
      v.transform(pBone->getRotationAbsolute());
      v.add(pBone->getTranslationAbsolute());

      x += influence.weight * v.m_x;
      y += influence.weight * v.m_y;
      z += influence.weight * v.m_z;
    }

    // save vertex position
    pVertexBuffer[0] = x;
    pVertexBuffer[1] = y;
    pVertexBuffer[2] = z;

    // next vertex position in buffer
    pVertexBuffer += 3;
  }

  return vertexCount;
}

//----------------------------------------------------------------------------//
// Select the current mess/submesh for data queries                           //
//----------------------------------------------------------------------------//

bool CalRenderer::selectMeshSubmesh(int meshId, int submeshId)
{
  // check if the mesh id is valid
  if((meshId < 0) || (meshId >= (int)m_vectorMesh.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  // get the core submesh
  m_pSelectedSubmesh = m_vectorMesh[meshId]->getSubmesh(submeshId);
  if(m_pSelectedSubmesh == 0) return false;

  return true;
}

//----------------------------------------------------------------------------//
// Set the lod level of all meshes                                            //
//----------------------------------------------------------------------------//

void CalRenderer::setLodLevel(float lodLevel)
{
  // set the lod level in all meshes
  std::vector<CalMesh *>::iterator iteratorMesh;
  for(iteratorMesh = m_vectorMesh.begin(); iteratorMesh != m_vectorMesh.end(); ++iteratorMesh)
  {
    // set the lod lvele in the mesh
    (*iteratorMesh)->setLodLevel(lodLevel);
  }
}

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// calskeleton.h                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_CALSKELETON_H
#define CAL_CALSKELETON_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalCoreSkeleton;
class CalBone;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalSkeleton
{
// member variables
protected:
  CalCoreSkeleton *m_pCoreSkeleton;
  std::vector<CalBone *> m_vectorBone;

// constructors/destructor
public:
	CalSkeleton();
	virtual ~CalSkeleton();
	
// member functions
public:
  void calculateState();
  void clearState();
  bool create(CalCoreSkeleton *pCoreSkeleton);
  void destroy();
  CalBone *getBone(int boneId);
  std::vector<CalBone *>& getVectorBone();
  void lockState();

  int getBonePoints(float *pPoints); // DEBUG-CODE
  int getBonePointsStatic(float *pPoints); // DEBUG-CODE
  int getBoneLines(float *pLines); // DEBUG-CODE
  int getBoneLinesStatic(float *pLines); // DEBUG-CODE
};

#endif

//----------------------------------------------------------------------------//

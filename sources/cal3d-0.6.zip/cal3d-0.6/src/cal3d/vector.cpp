//----------------------------------------------------------------------------//
// vector.cpp                                                                 //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "vector.h"
#include "quaternion.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalVector::CalVector() : m_x(0.0f), m_y(0.0f), m_z(0.0f)
{
}

CalVector::CalVector(float x, float y, float z) : m_x(x), m_y(y), m_z(z)
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalVector::~CalVector()
{
}

//----------------------------------------------------------------------------//
// [] operator                                                                //
//----------------------------------------------------------------------------//

float& CalVector::operator[](unsigned int index)
{
  return (&m_x)[index];
}

//----------------------------------------------------------------------------//
// const [] operator                                                          //
//----------------------------------------------------------------------------//

const float& CalVector::operator[](unsigned int index) const
{
  return (&m_x)[index];
}

//----------------------------------------------------------------------------//
// Add the given vector                                                       //
//----------------------------------------------------------------------------//

void CalVector::add(const CalVector& v)
{
  m_x += v.m_x;
  m_y += v.m_y;
  m_z += v.m_z;
}

//----------------------------------------------------------------------------//
// Interpolate to a given vector                                              //
//----------------------------------------------------------------------------//

void CalVector::blend(float factor, const CalVector& v)
{
  m_x += factor * (v.m_x - m_x);
  m_y += factor * (v.m_y - m_y);
  m_z += factor * (v.m_z - m_z);
}

//----------------------------------------------------------------------------//
// Transform the vector through a given quaternion                            //
//----------------------------------------------------------------------------//

void CalVector::transform(const CalQuaternion& q)
{
  CalQuaternion temp(-q.m_x, -q.m_y, -q.m_z, q.m_w);
  temp.product(m_x, m_y, m_z);
  temp.product(q);

  m_x = temp.m_x;
  m_y = temp.m_y;
  m_z = temp.m_z;
}

//----------------------------------------------------------------------------//

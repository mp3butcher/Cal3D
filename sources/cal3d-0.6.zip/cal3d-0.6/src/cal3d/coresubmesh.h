//----------------------------------------------------------------------------//
// coresubmesh.h                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_CORESUBMESH_H
#define CAL_CORESUBMESH_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalCoreSubmesh
{
// misc
public:
  typedef struct
  {
    float u, v;
  } TextureCoordinate;

  typedef struct
  {
    int boneId;
    float weight;
    float x, y, z;
    float nx, ny, nz;
  } Influence;

  typedef struct
  {
    std::vector<Influence> vectorInfluence;
    int collapseId;
    int faceCollapseCount;
  } Vertex;

  typedef struct
  {
    int vertexId[3];
  } Face;

// member variables
protected:
  std::vector<Vertex> m_vectorVertex;
  std::vector<std::vector<TextureCoordinate> > m_vectorvectorTextureCoordinate;
  std::vector<Face> m_vectorFace;
  int m_coreMaterialThreadId;
  int m_lodCount;

// constructors/destructor
public:
  CalCoreSubmesh();
	virtual ~CalCoreSubmesh();

// member functions	
public:
  bool create();
  void destroy();
  int getCoreMaterialThreadId();
  int getFaceCount();
  int getLodCount();
  std::vector<Face>& getVectorFace();
  std::vector<std::vector<TextureCoordinate> >& getVectorVectorTextureCoordinate();
  std::vector<Vertex>& getVectorVertex();
  int getVertexCount();
  bool reserve(int vertexCount, int textureCoordinateCount, int faceCount);
  void setCoreMaterialThreadId(int coreMaterialThreadId);
  bool setFace(int id, const Face& face);
  void setLodCount(int lodCount);
  bool setTextureCoordinate(int vertexId, int id, const TextureCoordinate& textureCoordinate);
  bool setVertex(int id, const Vertex& vertex);
};

#endif

//----------------------------------------------------------------------------//

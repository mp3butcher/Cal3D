o-----------------------------------------------------------------------------o
|                                                                             |
|                         c a l 3 d - max exporter                            |
|                                                                             |
|                                Version 0.6                                  |
|                              (5. Aug. 2001)                                 |
|                                                                             |
|               Copyright (C) 2001 Bruno 'Beosil' Heidelberger                |
|                                                                             |
o-----------------------------------------------------------------------------o

o-----------------------------------------------------------------------------o
| Table of Contents                                                           |
o-----------------------------------------------------------------------------o

  1 License
  2 What is 'cal3d_max_exporter'?
  3 Website
  4 Author


o-----------------------------------------------------------------------------o
| 1 License                                                                   |
o-----------------------------------------------------------------------------o

  This program is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by the Free
  Software Foundation; either version 2 of the License, or (at your option)
  any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation Inc., 59
  Temple Place, Suite 330, Boston, MA 02111-1307 USA


o-----------------------------------------------------------------------------o
| 2 What is 'cal3d_max_exporter'?                                             |
o-----------------------------------------------------------------------------o

  Cal3d max exporter is an exporter plugin for 3d studio max that exports
  skeletal based character models and their animations into cal3d files.


o-----------------------------------------------------------------------------o
| 3 Website                                                                   |
o-----------------------------------------------------------------------------o

  The official website of cal3d can be found at: http://cal3d.sourceforge.net


o-----------------------------------------------------------------------------o
| 4 Author                                                                    |
o-----------------------------------------------------------------------------o

  This project was originally started by Bruno 'Beosil' Heidelberger. You can
  find a list of all people contributing to cal3d in the AUTHORS file.


o-----------------------------------------------------------------------------o

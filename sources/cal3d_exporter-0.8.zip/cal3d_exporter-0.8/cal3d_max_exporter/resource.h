//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cal3d_max_exporter.rc
//
#define IDS_SKELETON_EXPORT_DESCRIPTION 1
#define IDS_NULL                        2
#define IDS_ANIMATION_EXPORT_DESCRIPTION 3
#define IDS_ANIMATION_EXPORT_DESCRIPTION_2 4
#define IDS_ANIMATION_EXPORT_DESCRIPTION_3 5
#define IDS_MESH_EXPORT_DESCRIPTION     6
#define IDS_MESH_EXPORT_DESCRIPTION2    7
#define IDS_MESH_EXPORT_DESCRIPTION3    8
#define IDS_MATERIAL_EXPORT_DESCRIPTION 9
#define IDS_MATERIAL_EXPORT_DESCRIPTION2 10
#define IDS_MESH_EXPORT_DESCRIPTION4    11
#define IDD_SKELETON_HIERARCHY_PAGE     107
#define IDC_HIERARCHY                   3002
#define IDI_TYPE_BONE                   3002
#define IDC_URL                         3003
#define IDB_CAL3D_LOGO                  3003
#define IDI_TYPE_DUMMY                  3003
#define IDD_ABOUT                       3004
#define IDI_TYPE_OTHER                  3004
#define IDD_SKELETON_FILE_PAGE          3005
#define IDD_ANIMATION_TIME_PAGE         3006
#define IDD_BONE_ASSIGNMENT_PAGE        3007
#define IDD_LOD_PAGE                    3008
#define IDD_MATERIAL_SELECTION_PAGE     3009
#define IDD_MATERIAL_MAPS_PAGE          3010
#define IDD_SPRINGSYSTEM_PAGE           3011
#define IDC_LRU                         4001
#define IDB_CAL3D_BAR                   4002
#define IDC_BROWSE                      4003
#define IDC_STEP                        4006
#define IDC_DESCRIPTION                 4007
#define IDC_START_FRAME                 4008
#define IDC_END_FRAME                   4009
#define IDC_WEIGHT_THRESHOLD            4009
#define IDC_DISPLACEMENT                4010
#define IDC_MAX_BONE_COUNT              4010
#define IDC_FPS                         4011
#define IDC_MATERIAL                    4012
#define IDC_MAPS                        4013
#define IDC_ENABLE_LOD                  4014
#define IDC_ENABLE_SPRINGSYSTEM         4015
#define IDD_MATERIAL_MAP                5001
#define IDC_MAP_FILENAME                5006
#define IDC_MAP_NAME                    5007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        4004
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         4016
#define _APS_NEXT_SYMED_VALUE           4000
#endif
#endif

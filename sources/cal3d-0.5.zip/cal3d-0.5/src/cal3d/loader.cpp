//----------------------------------------------------------------------------//
// loader.cpp                                                                 //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "loader.h"
#include "error.h"
#include "vector.h"
#include "quaternion.h"
#include "coremodel.h"
#include "coreskeleton.h"
#include "corebone.h"
#include "coreanimation.h"
#include "coretrack.h"
#include "corekeyframe.h"
#include "coremesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalLoader::CalLoader()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalLoader::~CalLoader()
{
}

//----------------------------------------------------------------------------//
// Load a core animation from a file                                          //
//----------------------------------------------------------------------------//

CalCoreAnimation *CalLoader::loadCoreAnimation(const std::string& strFilename)
{
  // open the file
  std::ifstream file;
  file.open(strFilename.c_str(), std::ios::in | std::ios::binary);
  if(!file)
  {
    CalError::setLastError(CalError::FILE_NOT_FOUND, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // check if this is a valid file
  unsigned int magic;
  file.read((char *)&magic, sizeof(magic));
  if(!file || (memcmp(&magic, Cal::ANIMATION_FILE_MAGIC, 4) != 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core animation instance
  CalCoreAnimation *pCoreAnimation;
  pCoreAnimation = new CalCoreAnimation();
  if(pCoreAnimation == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core animation instance
  if(!pCoreAnimation->create())
  {
    delete pCoreAnimation;
    return 0;
  }

  // get the duration of the core animation
  float duration;
  file.read((char *)&duration, 4);
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    pCoreAnimation->destroy();
    delete pCoreAnimation;
    return 0;
  }

  // check for a valid duration
  if(duration <= 0.0f)
  {
    CalError::setLastError(CalError::INVALID_ANIMATION_DURATION, __FILE__, __LINE__, strFilename);
    pCoreAnimation->destroy();
    delete pCoreAnimation;
    return 0;
  }

  // set the duration in the core animation instance
  pCoreAnimation->setDuration(duration);

  // read the number of tracks
  int trackCount;
  file.read((char *)&trackCount, 4);
  if(!file || (trackCount <= 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // load all core bones
  int trackId;
  for(trackId = 0; trackId < trackCount; trackId++)
  {
    // load the core track
    CalCoreTrack *pCoreTrack;
    pCoreTrack = loadCoreTrack(file, strFilename, duration);
    if(pCoreTrack == 0)
    {
      pCoreAnimation->destroy();
      delete pCoreAnimation;
      return 0;
    }

    // add the core track to the core animation instance
    pCoreAnimation->addCoreTrack(pCoreTrack);
  }

  // explicitly close the file
  file.close();

  return pCoreAnimation;
}

//----------------------------------------------------------------------------//
// Load all bones for a given parent bone                                     //
//----------------------------------------------------------------------------//

CalCoreBone *CalLoader::loadCoreBones(std::ifstream& file, const std::string& strFilename)
{
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // get the name length of the bone
  int len;
  file.read((char *)&len, 4);
  if(len < 1)
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // read the name of the bone
  char *strBuffer;
  strBuffer = new char[len];
  file.read(strBuffer, len);
  std::string strName;
  strName = strBuffer;
  delete [] strBuffer;

  // get the translation of the bone
  float tx, ty, tz;
  file.read((char *)&tx, 4);
  file.read((char *)&ty, 4);
  file.read((char *)&tz, 4);

  // get the rotation of the bone
  float rx, ry, rz, rw;
  file.read((char *)&rx, 4);
  file.read((char *)&ry, 4);
  file.read((char *)&rz, 4);
  file.read((char *)&rw, 4);

  // get the parent bone id
  int parentId;
  file.read((char *)&parentId, 4);

  // check if an error happend
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core bone instance
  CalCoreBone *pCoreBone;
  pCoreBone = new CalCoreBone();
  if(pCoreBone == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core bone instance
  if(!pCoreBone->create(strName))
  {
    delete pCoreBone;
    return 0;
  }

  // set the parent of the bone
  pCoreBone->setParentId(parentId);

  // set all attributes of the bone
  pCoreBone->setTranslation(CalVector(tx, ty, tz));
  pCoreBone->setRotation(CalQuaternion(rx, ry, rz, rw));

  // read the number of children
  int childCount;
  file.read((char *)&childCount, 4);
  if(!file || (childCount < 0))
  {
    pCoreBone->destroy();
    delete pCoreBone;
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // load all children ids
  for(; childCount > 0; childCount--)
  {
    int childId;
    file.read((char *)&childId, 4);
    if(!file || (childId < 0))
    {
      pCoreBone->destroy();
      delete pCoreBone;
      CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
      return 0;
    }

    pCoreBone->addChildId(childId);
  }

  return pCoreBone;
}

//----------------------------------------------------------------------------//
// Load a core keyframe track                                                 //
//----------------------------------------------------------------------------//

CalCoreKeyframe *CalLoader::loadCoreKeyframe(std::ifstream& file, const std::string& strFilename)
{
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // get the time of the keyframe
  float time;
  file.read((char *)&time, 4);

  // get the translation of the bone
  float tx, ty, tz;
  file.read((char *)&tx, 4);
  file.read((char *)&ty, 4);
  file.read((char *)&tz, 4);

  // get the rotation of the bone
  float rx, ry, rz, rw;
  file.read((char *)&rx, 4);
  file.read((char *)&ry, 4);
  file.read((char *)&rz, 4);
  file.read((char *)&rw, 4);

  // check if an error happend
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core keyframe instance
  CalCoreKeyframe *pCoreKeyframe;
  pCoreKeyframe = new CalCoreKeyframe();
  if(pCoreKeyframe == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core keyframe instance
  if(!pCoreKeyframe->create())
  {
    delete pCoreKeyframe;
    return 0;
  }

  // set all attributes of the keyframe
  pCoreKeyframe->setTime(time);
  pCoreKeyframe->setTranslation(CalVector(tx, ty, tz));
  pCoreKeyframe->setRotation(CalQuaternion(rx, ry, rz, rw));

  return pCoreKeyframe;
}

//----------------------------------------------------------------------------//
// Load a core mesh from a file                                               //
//----------------------------------------------------------------------------//

CalCoreMesh *CalLoader::loadCoreMesh(const std::string& strFilename)
{
  // open the file
  std::ifstream file;
  file.open(strFilename.c_str(), std::ios::in | std::ios::binary);
  if(!file)
  {
    CalError::setLastError(CalError::FILE_NOT_FOUND, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // check if this is a valid file
  unsigned int magic;
  file.read((char *)&magic, sizeof(magic));
  if(!file || (memcmp(&magic, Cal::MESH_FILE_MAGIC, 4) != 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core mesh instance
  CalCoreMesh *pCoreMesh;
  pCoreMesh = new CalCoreMesh();
  if(pCoreMesh == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core mesh instance
  if(!pCoreMesh->create())
  {
    delete pCoreMesh;
    return 0;
  }

  // get the number of influences, vertex influences, colors, texture coordinates and submeshes
  int influenceCount;
  file.read((char *)&influenceCount, 4);
  int boneInfluenceCount;
  file.read((char *)&boneInfluenceCount, 4);
  int subMeshCount;
  file.read((char *)&subMeshCount, 4);

  // check if an error happend
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    pCoreMesh->destroy();
    delete pCoreMesh;
    return 0;
  }

  // reserve memory for all the mesh data
  if(!pCoreMesh->reserve(influenceCount, boneInfluenceCount, subMeshCount))
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__, strFilename);
    pCoreMesh->destroy();
    delete pCoreMesh;
  }

  // load all influences and boneInfluences
  int boneInfluenceId;
  boneInfluenceId = 0;

  int influenceId;
  for(influenceId = 0; influenceId < influenceCount; influenceId++)
  {
    CalCoreMesh::Influence influence;

    // load the number of vertex influences of the influence
    file.read((char *)&influence.boneInfluenceCount, 4);
    if(!file || (influence.boneInfluenceCount < 0))
    {
      pCoreMesh->destroy();
      delete pCoreMesh;
      CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
      return 0;
    }

    // load all vertex influences of the influence
    int boneInfluenceOffset;
    for(boneInfluenceOffset = 0; boneInfluenceOffset < influence.boneInfluenceCount; boneInfluenceOffset++)
    {
      CalCoreMesh::BoneInfluence boneInfluence;

      // load data of the vertex influence
      file.read((char *)&boneInfluence.boneId, 4);
      file.read((char *)&boneInfluence.weight, 4);
      file.read((char *)&boneInfluence.position.x, 4);
      file.read((char *)&boneInfluence.position.y, 4);
      file.read((char *)&boneInfluence.position.z, 4);
      file.read((char *)&boneInfluence.normal.x, 4);
      file.read((char *)&boneInfluence.normal.y, 4);
      file.read((char *)&boneInfluence.normal.z, 4);

      if(!file)
      {
        pCoreMesh->destroy();
        delete pCoreMesh;
        CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
        return 0;
      }

      // set influence in the core mesh instance
      pCoreMesh->setBoneInfluence(boneInfluenceId + boneInfluenceOffset, boneInfluence);
    }

    // set start vertex influence id in the influence
    if(influence.boneInfluenceCount == 0) influence.boneInfluenceId = -1;
    else influence.boneInfluenceId = boneInfluenceId;

    // set influence in the core mesh instance
    pCoreMesh->setInfluence(influenceId, influence);

    // adjust base vertex influence id
    boneInfluenceId += influence.boneInfluenceCount;
  }

  // load all submeshes
  int subMeshId;
  for(subMeshId = 0; subMeshId < subMeshCount; subMeshId++)
  {
    CalCoreMesh::SubMesh subMesh;

    // load data of the submesh

    // load material data
    file.read((char *)&subMesh.material.ambientColor.red, 1);
    file.read((char *)&subMesh.material.ambientColor.green, 1);
    file.read((char *)&subMesh.material.ambientColor.blue, 1);
    file.read((char *)&subMesh.material.ambientColor.alpha, 1);

    file.read((char *)&subMesh.material.diffuseColor.red, 1);
    file.read((char *)&subMesh.material.diffuseColor.green, 1);
    file.read((char *)&subMesh.material.diffuseColor.blue, 1);
    file.read((char *)&subMesh.material.diffuseColor.alpha, 1);

    file.read((char *)&subMesh.material.specularColor.red, 1);
    file.read((char *)&subMesh.material.specularColor.green, 1);
    file.read((char *)&subMesh.material.specularColor.blue, 1);
    file.read((char *)&subMesh.material.specularColor.alpha, 1);

    file.read((char *)&subMesh.material.shininess, 4);

    // load map data of material
    int mapCount;
    file.read((char *)&mapCount, 4);

    subMesh.material.vectorMap.reserve(mapCount);
    subMesh.material.vectorMap.resize(mapCount);

    int mapId;
    for(mapId = 0; mapId < mapCount; mapId++)
    {
      file.read((char *)&subMesh.material.vectorMap[mapId].id, 4);
    }

    // load face data
    int faceCount;
    file.read((char *)&faceCount, 4);
    subMesh.vectorFace.reserve(faceCount);
    subMesh.vectorFace.resize(faceCount);

    int faceId;
    for(faceId = 0; faceId < faceCount; faceId++)
    {
      file.read((char *)&subMesh.vectorFace[faceId].vertexId[0], 4);
      file.read((char *)&subMesh.vectorFace[faceId].vertexId[1], 4);
      file.read((char *)&subMesh.vectorFace[faceId].vertexId[2], 4);
    }

    // load vertex data
    int vertexCount;
    file.read((char *)&vertexCount, 4);

    int colorCount;
    file.read((char *)&colorCount, 4);

    subMesh.vectorVertexId.reserve(vertexCount);
    subMesh.vectorVertexId.resize(vertexCount);

    if(colorCount > 0)
    {
      subMesh.vectorColor.reserve(vertexCount);
      subMesh.vectorColor.resize(vertexCount);
    }

    if(mapCount > 0)
    {
      subMesh.vectorvectorTextureCoordinate.reserve(mapCount);
      subMesh.vectorvectorTextureCoordinate.resize(mapCount);

      for(mapId = 0; mapId < mapCount; mapId++)
      {
        subMesh.vectorvectorTextureCoordinate[mapId].reserve(vertexCount);
        subMesh.vectorvectorTextureCoordinate[mapId].resize(vertexCount);
      }
    }

    int vertexId;
    for(vertexId = 0; vertexId < vertexCount; vertexId++)
    {
      file.read((char *)&subMesh.vectorVertexId[vertexId], 4);

      if(colorCount > 0)
      {
        file.read((char *)&subMesh.vectorColor[vertexId].red, 1);
        file.read((char *)&subMesh.vectorColor[vertexId].green, 1);
        file.read((char *)&subMesh.vectorColor[vertexId].blue, 1);
        file.read((char *)&subMesh.vectorColor[vertexId].alpha, 1);
      }

      for(mapId = 0; mapId < mapCount; mapId++)
      {
        file.read((char *)&subMesh.vectorvectorTextureCoordinate[mapId][vertexId].u, 4);
        file.read((char *)&subMesh.vectorvectorTextureCoordinate[mapId][vertexId].v, 4);
      }
    }

    // check if an error happend
    if(!file)
    {
      CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
      pCoreMesh->destroy();
      delete pCoreMesh;
      return 0;
    }

    // set submesh in the core mesh instance
    pCoreMesh->setSubMesh(subMeshId, subMesh);
  }

  // explicitly close the file
  file.close();

  return pCoreMesh;
}

//----------------------------------------------------------------------------//
// Load a core skeleton from a file                                           //
//----------------------------------------------------------------------------//

CalCoreSkeleton *CalLoader::loadCoreSkeleton(const std::string& strFilename)
{
  // open the file
  std::ifstream file;
  file.open(strFilename.c_str(), std::ios::in | std::ios::binary);
  if(!file)
  {
    CalError::setLastError(CalError::FILE_NOT_FOUND, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // check if this is a valid file
  unsigned int magic;
  file.read((char *)&magic, sizeof(magic));
  if(!file || (memcmp(&magic, Cal::SKELETON_FILE_MAGIC, 4) != 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // read the number of bones
  int boneCount;
  file.read((char *)&boneCount, 4);
  if(!file || (boneCount <= 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core skeleton instance
  CalCoreSkeleton *pCoreSkeleton;
  pCoreSkeleton = new CalCoreSkeleton();
  if(pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core skeleton instance
  if(!pCoreSkeleton->create())
  {
    delete pCoreSkeleton;
    return 0;
  }

  // load all core bones
  int boneId;
  for(boneId = 0; boneId < boneCount; boneId++)
  {
    // load the core bone
    CalCoreBone *pCoreBone;
    pCoreBone = loadCoreBones(file, strFilename);
    if(pCoreBone == 0)
    {
      pCoreSkeleton->destroy();
      delete pCoreSkeleton;
      return 0;
    }

    // set the core skeleton of the core bone instance
    pCoreBone->setCoreSkeleton(pCoreSkeleton);

    // add the core bone to the core skeleton instance
    pCoreSkeleton->addCoreBone(pCoreBone);

    // if necessary, add the core bone to the core skeleton root bone list
    if(pCoreBone->getParentId() == -1)
    {
      pCoreSkeleton->addRootCoreBoneId(boneId);
    }
  }

  // explicitly close the file
  file.close();

  // calculate state of the core skeleton
  pCoreSkeleton->calculateState();

  return pCoreSkeleton;
}

//----------------------------------------------------------------------------//
// Load a core track                                                          //
//----------------------------------------------------------------------------//

CalCoreTrack *CalLoader::loadCoreTrack(std::ifstream& file, const std::string& strFilename, float duration)
{
  if(!file)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // read the bone id
  int coreBoneId;
  file.read((char *)&coreBoneId, 4);
  if(!file || (coreBoneId < 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // allocate a new core track instance
  CalCoreTrack *pCoreTrack;
  pCoreTrack = new CalCoreTrack();
  if(pCoreTrack == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return 0;
  }

  // create the core track instance
  if(!pCoreTrack->create())
  {
    delete pCoreTrack;
    return 0;
  }

  // link the core track to the appropriate core bone instance
  pCoreTrack->setCoreBoneId(coreBoneId);

  // read the number of keyframes
  int keyframeCount;
  file.read((char *)&keyframeCount, 4);
  if(!file || (keyframeCount <= 0))
  {
    CalError::setLastError(CalError::INVALID_FILE_FORMAT, __FILE__, __LINE__, strFilename);
    return 0;
  }

  // load all core keyframes
  int keyframeId;
  for(keyframeId = 0; keyframeId < keyframeCount; keyframeId++)
  {
    // load the core keyframe
    CalCoreKeyframe *pCoreKeyframe;
    pCoreKeyframe = loadCoreKeyframe(file, strFilename);
    if(pCoreKeyframe == 0)
    {
      pCoreTrack->destroy();
      delete pCoreTrack;
      return 0;
    }

    // add the core keyframe to the core track instance
    pCoreTrack->addCoreKeyframe(pCoreKeyframe);
  }

  return pCoreTrack;
}

//----------------------------------------------------------------------------//

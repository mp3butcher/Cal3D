//----------------------------------------------------------------------------//
// corekeyframe.cpp                                                           //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "corekeyframe.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreKeyframe::CalCoreKeyframe()
{
  m_time = 0.0f;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreKeyframe::~CalCoreKeyframe()
{
}

//----------------------------------------------------------------------------//
// Create a core keyframe                                                     //
//----------------------------------------------------------------------------//

bool CalCoreKeyframe::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core keyframe                                                 //
//----------------------------------------------------------------------------//

void CalCoreKeyframe::destroy()
{
}

//----------------------------------------------------------------------------//
// Get the rotation of this core keyframe                                     //
//----------------------------------------------------------------------------//

const CalQuaternion& CalCoreKeyframe::getRotation()
{
  return m_rotation;
}

//----------------------------------------------------------------------------//
// Get the time of this core keyframe                                         //
//----------------------------------------------------------------------------//

float CalCoreKeyframe::getTime()
{
  return m_time;
}

//----------------------------------------------------------------------------//
// Get the translation of this core keyframe                                  //
//----------------------------------------------------------------------------//

const CalVector& CalCoreKeyframe::getTranslation()
{
  return m_translation;
}

//----------------------------------------------------------------------------//
// Set the rotation quaternion of this core keyframe                          //
//----------------------------------------------------------------------------//

void CalCoreKeyframe::setRotation(const CalQuaternion& rotation)
{
  m_rotation = rotation;
}

//----------------------------------------------------------------------------//
// Set the time of this core keyframe                                         //
//----------------------------------------------------------------------------//

void CalCoreKeyframe::setTime(float time)
{
  m_time = time;
}

//----------------------------------------------------------------------------//
// Set the translation vector of this core keyframe                           //
//----------------------------------------------------------------------------//

void CalCoreKeyframe::setTranslation(const CalVector& translation)
{
  m_translation = translation;
}

//----------------------------------------------------------------------------//

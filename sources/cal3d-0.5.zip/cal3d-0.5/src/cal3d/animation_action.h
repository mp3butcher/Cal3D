//----------------------------------------------------------------------------//
// animation_action.h                                                         //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_ANIMATION_ACTION_H
#define CAL_ANIMATION_ACTION_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"
#include "animation.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalCoreAnimation;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalAnimationAction : public CalAnimation
{
// member variables
protected:
  float m_weight;
  float m_delayIn;
  float m_delayOut;
  float m_delayTarget;

// constructors/destructor
public:
  CalAnimationAction();
	virtual ~CalAnimationAction();

// member functions	
public:
  bool create(CalCoreAnimation *pCoreAnimation);
  void destroy();
  bool execute(float delayIn, float delayOut);
  float getWeight();
  bool update(float deltaTime);
};

#endif

//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// cal3d.h                                                                    //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_CAL3D_H
#define CAL_CAL3D_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "animation.h"
#include "animation_action.h"
#include "animation_cycle.h"
#include "bone.h"
#include "coreanimation.h"
#include "corebone.h"
#include "corekeyframe.h"
#include "coremesh.h"
#include "coremodel.h"
#include "coreskeleton.h"
#include "coretrack.h"
#include "error.h"
#include "loader.h"
#include "mixer.h"
#include "model.h"
#include "quaternion.h"
#include "skeleton.h"
#include "vector.h"

#endif

//----------------------------------------------------------------------------//

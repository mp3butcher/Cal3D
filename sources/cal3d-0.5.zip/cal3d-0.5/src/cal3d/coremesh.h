//----------------------------------------------------------------------------//
// coremesh.h                                                                 //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_COREMESH_H
#define CAL_COREMESH_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalCoreMesh
{
// misc
public:
  typedef struct
  {
    float x, y, z;
  } Vertex;

  typedef struct
  {
    unsigned char red, green, blue, alpha;
  } Color;

  typedef struct
  {
    float u, v;
  } TextureCoordinate;

  typedef struct
  {
    int boneInfluenceId;
    int boneInfluenceCount;
  } Influence;

  typedef struct
  {
    int boneId;
    float weight;
    Vertex position;
    Vertex normal;
  } BoneInfluence;

  typedef struct
  {
    int vertexId[3];
  } Face;

  typedef struct
  {
    int id;
  } Map;

  typedef struct
  {
    Color ambientColor;
    Color diffuseColor;
    Color specularColor;
    float shininess;
    std::vector<Map> vectorMap;
  } Material;

  typedef struct
  {
    Material material;
    std::vector<Face> vectorFace;
    std::vector<int> vectorVertexId;
    std::vector<std::vector<TextureCoordinate> > vectorvectorTextureCoordinate;
    std::vector<Color> vectorColor;
  } SubMesh;

// member variables
protected:
  std::vector<BoneInfluence> m_vectorBoneInfluence;
  std::vector<Influence> m_vectorInfluence;
  std::vector<SubMesh> m_vectorSubMesh;

// constructors/destructor
public:
  CalCoreMesh();
	virtual ~CalCoreMesh();

// member functions	
public:
  bool create();
  void destroy();
  std::vector<Influence>& getVectorInfluence();
  std::vector<SubMesh>& getVectorSubMesh();
  std::vector<BoneInfluence>& getVectorBoneInfluence();
  bool reserve(int influenceCount, int boneInfluenceCount, int subMeshCount);
  bool setBoneInfluence(int id, const BoneInfluence& boneInfluence);
  bool setInfluence(int id, const Influence& influence);
  bool setSubMesh(int id, const SubMesh& subMesh);
};

#endif

//----------------------------------------------------------------------------//

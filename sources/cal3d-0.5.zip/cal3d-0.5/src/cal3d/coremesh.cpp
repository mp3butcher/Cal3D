//----------------------------------------------------------------------------//
// coremesh.cpp                                                               //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coremesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreMesh::CalCoreMesh()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreMesh::~CalCoreMesh()
{
  assert(m_vectorInfluence.empty());
  assert(m_vectorBoneInfluence.empty());
  assert(m_vectorSubMesh.empty());
}

//----------------------------------------------------------------------------//
// Create a core mesh                                                         //
//----------------------------------------------------------------------------//

bool CalCoreMesh::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core mesh                                                     //
//----------------------------------------------------------------------------//

void CalCoreMesh::destroy()
{
  // destroy all data
  m_vectorInfluence.clear();
  m_vectorBoneInfluence.clear();
  m_vectorSubMesh.clear();
}

//----------------------------------------------------------------------------//
// Get the bone influence vector                                              //
//----------------------------------------------------------------------------//

std::vector<CalCoreMesh::BoneInfluence>& CalCoreMesh::getVectorBoneInfluence()
{
  return m_vectorBoneInfluence;
}

//----------------------------------------------------------------------------//
// Get the influence vector                                                   //
//----------------------------------------------------------------------------//

std::vector<CalCoreMesh::Influence>& CalCoreMesh::getVectorInfluence()
{
  return m_vectorInfluence;
}

//----------------------------------------------------------------------------//
// Get the submesh vector                                                     //
//----------------------------------------------------------------------------//

std::vector<CalCoreMesh::SubMesh>& CalCoreMesh::getVectorSubMesh()
{
  return m_vectorSubMesh;
}

//----------------------------------------------------------------------------//
// Reserve memory for all the mesh data                                       //
//----------------------------------------------------------------------------//

bool CalCoreMesh::reserve(int influenceCount, int boneInfluenceCount, int subMeshCount)
{
  // reserve the space needed in all the vectors
  m_vectorInfluence.reserve(influenceCount);
  m_vectorInfluence.resize(influenceCount);

  m_vectorBoneInfluence.reserve(boneInfluenceCount);
  m_vectorBoneInfluence.resize(boneInfluenceCount);

  m_vectorSubMesh.reserve(subMeshCount);
  m_vectorSubMesh.resize(subMeshCount);

  return true;
}

//----------------------------------------------------------------------------//
// Set a specific bone influence in the core mesh instance                    //
//----------------------------------------------------------------------------//

bool CalCoreMesh::setBoneInfluence(int id, const BoneInfluence& boneInfluence)
{
  if((id < 0) || (id >= (int)m_vectorBoneInfluence.size())) return false;

  m_vectorBoneInfluence[id] = boneInfluence;

  return true;
}

//----------------------------------------------------------------------------//
// Set a specific influence in the core mesh instance                         //
//----------------------------------------------------------------------------//

bool CalCoreMesh::setInfluence(int id, const Influence& influence)
{
  if((id < 0) || (id >= (int)m_vectorInfluence.size())) return false;

  m_vectorInfluence[id] = influence;

  return true;
}

//----------------------------------------------------------------------------//
// Set a specific submesh id in the core mesh instance                        //
//----------------------------------------------------------------------------//

bool CalCoreMesh::setSubMesh(int id, const SubMesh& subMesh)
{
  if((id < 0) || (id >= (int)m_vectorSubMesh.size())) return false;

  m_vectorSubMesh[id] = subMesh;

  return true;
}

//----------------------------------------------------------------------------//

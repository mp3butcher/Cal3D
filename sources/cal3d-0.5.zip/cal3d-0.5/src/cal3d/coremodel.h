//----------------------------------------------------------------------------//
// coremodel.h                                                                //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_COREMODEL_H
#define CAL_COREMODEL_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Forward declarations                                                       //
//----------------------------------------------------------------------------//

class CalCoreSkeleton;
class CalCoreAnimation;
class CalCoreMesh;

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalCoreModel
{
// member variables
protected:
  std::string m_strName;
  CalCoreSkeleton *m_pCoreSkeleton;
  std::vector<CalCoreAnimation *> m_vectorCoreAnimation;
  std::vector<CalCoreMesh *> m_vectorCoreMesh;

// constructors/destructor
public:
	CalCoreModel();
	virtual ~CalCoreModel();
	
// member functions
public:
  int addCoreAnimation(CalCoreAnimation *pCoreAnimation);
  int addCoreMesh(CalCoreMesh *pCoreMesh);
  bool create(const std::string& strName);
  void destroy();
  CalCoreAnimation *getCoreAnimation(int id);
  int getCoreAnimationCount();
  CalCoreMesh *getCoreMesh(int id);
  CalCoreSkeleton *getCoreSkeleton();
  int loadCoreAnimation(const std::string& strFilename);
  int loadCoreMesh(const std::string& strFilename);
  bool loadCoreSkeleton(const std::string& strFilename);
};

#endif

//----------------------------------------------------------------------------//

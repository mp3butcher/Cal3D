//----------------------------------------------------------------------------//
// coreanimation.cpp                                                          //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coreanimation.h"
#include "coretrack.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreAnimation::CalCoreAnimation()
{
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreAnimation::~CalCoreAnimation()
{
  assert(m_listCoreTrack.empty());
}

//----------------------------------------------------------------------------//
// Add a core track to this core animation instance                           //
//----------------------------------------------------------------------------//

bool CalCoreAnimation::addCoreTrack(CalCoreTrack *pCoreTrack)
{
  m_listCoreTrack.push_back(pCoreTrack);

  return true;
}

//----------------------------------------------------------------------------//
// Create a core animation                                                    //
//----------------------------------------------------------------------------//

bool CalCoreAnimation::create()
{
  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core animation                                                //
//----------------------------------------------------------------------------//

void CalCoreAnimation::destroy()
{
  // destroy all core tracks
  while(!m_listCoreTrack.empty())
  {
    CalCoreTrack *pCoreTrack;
    pCoreTrack = m_listCoreTrack.front();
    m_listCoreTrack.pop_front();

    pCoreTrack->destroy();
    delete pCoreTrack;
  }
}

//----------------------------------------------------------------------------//
// Get the duration of this core animation instance                           //
//----------------------------------------------------------------------------//

float CalCoreAnimation::getDuration()
{
  return m_duration;
}

//----------------------------------------------------------------------------//
// Get the core track list of this core animation instance                    //
//----------------------------------------------------------------------------//

std::list<CalCoreTrack *>& CalCoreAnimation::getListCoreTrack()
{
  return m_listCoreTrack;
}

//----------------------------------------------------------------------------//
// Set the duration of this core animation instance                           //
//----------------------------------------------------------------------------//

void CalCoreAnimation::setDuration(float duration)
{
  m_duration = duration;
}

//----------------------------------------------------------------------------//

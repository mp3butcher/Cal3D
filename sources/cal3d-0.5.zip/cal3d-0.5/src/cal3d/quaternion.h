//----------------------------------------------------------------------------//
// quaternion.h                                                               //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

#ifndef CAL_QUATERNION_H
#define CAL_QUATERNION_H

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "global.h"

//----------------------------------------------------------------------------//
// Class declaration                                                          //
//----------------------------------------------------------------------------//

class CAL3D_API CalQuaternion
{
// member variables
public:
  float m_x;
  float m_y;
  float m_z;
  float m_w;

// constructors/destructor
public:
  CalQuaternion();
	CalQuaternion(float x, float y, float z, float w);
	virtual ~CalQuaternion();

// member functions	
public:
  void blend(float factor, const CalQuaternion& q);
  void product(const CalQuaternion& q);
  void product(float tx, float ty, float tz, float tw);
  void product(float tx, float ty, float tz);
};

#endif

//----------------------------------------------------------------------------//

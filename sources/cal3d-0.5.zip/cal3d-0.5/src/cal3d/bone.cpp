//----------------------------------------------------------------------------//
// bone.cpp                                                                   //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "bone.h"
#include "corebone.h"
#include "skeleton.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalBone::CalBone()
{
  m_pCoreBone = 0;
  m_pSkeleton = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalBone::~CalBone()
{
}

//----------------------------------------------------------------------------//
// Blend the current bone state with the given state                          //
//----------------------------------------------------------------------------//

void CalBone::blendState(float weight, const CalVector& translation, const CalQuaternion& rotation)
{
  if(m_accumulatedWeightAbsolute == 0.0f)
  {
    // it is the first state, so we can just copy it into the bone state
    m_translationAbsolute = translation;
    m_rotationAbsolute = rotation;

    m_accumulatedWeightAbsolute = weight;
  }
  else
  {
    // it is not the first state, so blend all attributes
    float factor;
    factor = weight / (m_accumulatedWeightAbsolute + weight);

    m_translationAbsolute.blend(factor, translation);
    m_rotationAbsolute.blend(factor, rotation);

    m_accumulatedWeightAbsolute += weight;
  }
}

//----------------------------------------------------------------------------//
// Calculate the state of the bone                                            //
//----------------------------------------------------------------------------//

void CalBone::calculateState()
{
  // get parent bone id
  int parentId;
  parentId = m_pCoreBone->getParentId();

  if(parentId == -1)
  {
    // no parent, this means absolute state == relative state
    m_translationAbsolute = m_translation;
    m_rotationAbsolute = m_rotation;
  }
  else
  {
    // get the parent bone
    CalBone *pParent;
    pParent = m_pSkeleton->getBone(parentId);

    // transform relative state with the absolute state of the parent
    m_translationAbsolute = m_translation;
    m_translationAbsolute.transform(pParent->getRotationAbsolute());
    m_translationAbsolute.add(pParent->getTranslationAbsolute());

    m_rotationAbsolute = pParent->getRotationAbsolute();
    m_rotationAbsolute.product(m_rotation);
  }

  // calculate all child bones
  std::list<int>::iterator iteratorChildId;
  for(iteratorChildId = m_pCoreBone->getListChildId().begin(); iteratorChildId != m_pCoreBone->getListChildId().end(); ++iteratorChildId)
  {
    m_pSkeleton->getBone(*iteratorChildId)->calculateState();
  }
}

//----------------------------------------------------------------------------//
// Clear the state of the bone                                                //
//----------------------------------------------------------------------------//

void CalBone::clearState()
{
  m_accumulatedWeight = 0.0f;
  m_accumulatedWeightAbsolute = 0.0f;
}

//----------------------------------------------------------------------------//
// Create a bone from a given core bone                                       //
//----------------------------------------------------------------------------//

bool CalBone::create(CalCoreBone *pCoreBone)
{
  if(pCoreBone == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreBone = pCoreBone;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this bone                                                          //
//----------------------------------------------------------------------------//

void CalBone::destroy()
{
  m_pCoreBone = 0;
  m_pSkeleton = 0;
}

//----------------------------------------------------------------------------//
// Get the core bone of this bone                                             //
//----------------------------------------------------------------------------//

CalCoreBone *CalBone::getCoreBone()
{
  return m_pCoreBone;
}

//----------------------------------------------------------------------------//
// Get the rotation of this bone                                              //
//----------------------------------------------------------------------------//

const CalQuaternion& CalBone::getRotation()
{
  return m_rotation;
}

//----------------------------------------------------------------------------//
// Get the absolute rotation of this bone                                     //
//----------------------------------------------------------------------------//

const CalQuaternion& CalBone::getRotationAbsolute()
{
  return m_rotationAbsolute;
}

//----------------------------------------------------------------------------//
// Get the translation of this bone                                           //
//----------------------------------------------------------------------------//

const CalVector& CalBone::getTranslation()
{
  return m_translation;
}

//----------------------------------------------------------------------------//
// Get the absolute translation of this bone                                  //
//----------------------------------------------------------------------------//

const CalVector& CalBone::getTranslationAbsolute()
{
  return m_translationAbsolute;
}

//----------------------------------------------------------------------------//
// Lock the state into the accumulated state                                  //
//----------------------------------------------------------------------------//

void CalBone::lockState()
{
  // clamp accumulated weight
  if(m_accumulatedWeightAbsolute > 1.0f - m_accumulatedWeight)
  {
    m_accumulatedWeightAbsolute = 1.0f - m_accumulatedWeight;
  }

  if(m_accumulatedWeightAbsolute > 0.0f)
  {
    if(m_accumulatedWeight == 0.0f)
    {
      // it is the first state, so we can just copy it into the bone state
      m_translation = m_translationAbsolute;
      m_rotation = m_rotationAbsolute;

      m_accumulatedWeight = m_accumulatedWeightAbsolute;
    }
    else
    {
      // it is not the first state, so blend all attributes
      float factor;
      factor = m_accumulatedWeightAbsolute / (m_accumulatedWeight + m_accumulatedWeightAbsolute);

      m_translation.blend(factor, m_translationAbsolute);
      m_rotation.blend(factor, m_rotationAbsolute);

      m_accumulatedWeight += m_accumulatedWeightAbsolute;
    }

    m_accumulatedWeightAbsolute = 0.0f;
  }
}

//----------------------------------------------------------------------------//
// Set the skeleton of this bone                                              //
//----------------------------------------------------------------------------//

void CalBone::setSkeleton(CalSkeleton *pSkeleton)
{
  m_pSkeleton = pSkeleton;
}

//----------------------------------------------------------------------------//

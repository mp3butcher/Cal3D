//----------------------------------------------------------------------------//
// animation_cycle.cpp                                                        //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "animation_cycle.h"
#include "error.h"
#include "coreanimation.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalAnimationCycle::CalAnimationCycle()
{
  m_type = TYPE_CYCLE;
  m_state = STATE_SYNC;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalAnimationCycle::~CalAnimationCycle()
{
}

//----------------------------------------------------------------------------//
// Blend the cycle animation to the given weight in delay time                //
//----------------------------------------------------------------------------//

bool CalAnimationCycle::blend(float weight, float delay)
{
  m_targetWeight = weight;
  m_targetDelay = delay;

  return true;
}

//----------------------------------------------------------------------------//
// Create an animation cycle from a given core animation                      //
//----------------------------------------------------------------------------//

bool CalAnimationCycle::create(CalCoreAnimation *pCoreAnimation)
{
  if(pCoreAnimation == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreAnimation = pCoreAnimation;

  // set default weights and delay
  m_weight = 0.0f;
  m_targetDelay = 0.0f;
  m_targetWeight = 0.0f;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this animation cycle                                               //
//----------------------------------------------------------------------------//

void CalAnimationCycle::destroy()
{
  m_pCoreAnimation = 0;
}

//----------------------------------------------------------------------------//
// Get the weight of this animation cycle                                     //
//----------------------------------------------------------------------------//

float CalAnimationCycle::getWeight()
{
  return m_weight;
}

//----------------------------------------------------------------------------//
// Set the state to async for a given animation time and duration             //
//----------------------------------------------------------------------------//

void CalAnimationCycle::setAsync(float time, float duration)
{
  // check if thie animation cycle is already async
  if(m_state != STATE_ASYNC)
  {
    if(duration == 0.0f)
    {
      m_timeFactor = 1.0f;
      m_time = 0.0f;
    }
    else
    {
      m_timeFactor = m_pCoreAnimation->getDuration() / duration;
      m_time = time * m_timeFactor;
    }

    m_state = STATE_ASYNC;
  }
}

//----------------------------------------------------------------------------//
// Update the animation cycle with a given delta time                         //
//----------------------------------------------------------------------------//

bool CalAnimationCycle::update(float deltaTime)
{
  if(m_targetDelay <= deltaTime)
  {
    // we reached target delay, set to full weight
    m_weight = m_targetWeight;
    m_targetDelay = 0.0f;

    // check if we reached the cycles end
    if(m_weight == 0.0f)
    {
      return false;
    }
  }
  else
  {
    // not reached target delay yet, interpolate between current and target weight
    float factor;
    factor = deltaTime / m_targetDelay;
    m_weight = (1.0f - factor) * m_weight + factor * m_targetWeight;
    m_targetDelay -= deltaTime;
  }

  // update animation cycle time if it is in async state
  if(m_state == STATE_ASYNC)
  {
    m_time += deltaTime * m_timeFactor;
    if(m_time >= m_pCoreAnimation->getDuration())
    {
      m_time = fmod(m_time, m_pCoreAnimation->getDuration());
    }
  }

  return true;
}

//----------------------------------------------------------------------------//

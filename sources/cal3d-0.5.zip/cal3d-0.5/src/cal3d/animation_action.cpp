//----------------------------------------------------------------------------//
// animation_action.cpp                                                       //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "animation_action.h"
#include "error.h"
#include "coreanimation.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalAnimationAction::CalAnimationAction()
{
  m_type = TYPE_ACTION;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalAnimationAction::~CalAnimationAction()
{
}

//----------------------------------------------------------------------------//
// Create an animation action from a given core animation                     //
//----------------------------------------------------------------------------//

bool CalAnimationAction::create(CalCoreAnimation *pCoreAnimation)
{
  if(pCoreAnimation == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreAnimation = pCoreAnimation;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this animation action                                              //
//----------------------------------------------------------------------------//

void CalAnimationAction::destroy()
{
  m_pCoreAnimation = 0;
}

//----------------------------------------------------------------------------//
// Execute the action animation for a given delayIn and delayOut time         //
//----------------------------------------------------------------------------//

bool CalAnimationAction::execute(float delayIn, float delayOut)
{
  m_state = STATE_IN;
  m_weight = 0.0f;
  m_delayIn = delayIn;
  m_delayOut = delayOut;
  m_time = 0.0f;

  return true;
}

//----------------------------------------------------------------------------//
// Get the weight of this animation action                                    //
//----------------------------------------------------------------------------//

float CalAnimationAction::getWeight()
{
  return m_weight;
}

//----------------------------------------------------------------------------//
// Update the animation action with a given delta time                        //
//----------------------------------------------------------------------------//

bool CalAnimationAction::update(float deltaTime)
{
  // update animation action time
  m_time += deltaTime * m_timeFactor;

  // handle IN phase
  if(m_state == STATE_IN)
  {
    // cehck if we are still in the IN phase
    if(m_time < m_delayIn)
    {
      m_weight = m_time / m_delayIn;
    }
    else
    {
      m_state = STATE_STEADY;
      m_weight = 1.0f;
    }
  }

  // hanbdle STEADY
  if(m_state == STATE_STEADY)
  {
    // cehck if we reached OUT phase
    if(m_time >= m_pCoreAnimation->getDuration() - m_delayOut)
    {
      m_state = STATE_OUT;
    }
  }

  // handle OUT phase
  if(m_state == STATE_OUT)
  {
    // cehck if we are still in the OUT phase
    if(m_time < m_pCoreAnimation->getDuration())
    {
      m_weight = (m_pCoreAnimation->getDuration() - m_time) / m_delayOut;
    }
    else
    {
      // we reached the end of the action animation
      m_weight = 0.0f;
      return false;
    }
  }

  return true;
}

//----------------------------------------------------------------------------//

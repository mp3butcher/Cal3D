//----------------------------------------------------------------------------//
// model.cpp                                                                  //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "error.h"
#include "model.h"
#include "skeleton.h"
#include "bone.h"
#include "mixer.h"
#include "coremodel.h"
#include "coreskeleton.h"
#include "coremesh.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalModel::CalModel()
{
  m_pCoreModel = 0;
  m_pSkeleton = 0;
  m_pMixer = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalModel::~CalModel()
{
}

//----------------------------------------------------------------------------//
// Create a model instance of a given type                                    //
//----------------------------------------------------------------------------//

bool CalModel::create(CalCoreModel *pCoreModel)
{
  if(pCoreModel == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return false;
  }

  m_pCoreModel = pCoreModel;

  // allocate a new skeleton instance
  CalSkeleton *pSkeleton;
  pSkeleton = new CalSkeleton();
  if(pSkeleton == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    return false;
  }

  // create the skeleton from the core skeleton
  if(!pSkeleton->create(pCoreModel->getCoreSkeleton()))
  {
    delete pSkeleton;
    return false;
  }

  m_pSkeleton = pSkeleton;

  // allocate a new mixer instance
  CalMixer *pMixer;
  pMixer = new CalMixer();
  if(pMixer == 0)
  {
    CalError::setLastError(CalError::MEMORY_ALLOCATION_FAILED, __FILE__, __LINE__);
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    return false;
  }

  // create the mixer from the core model
  if(!pMixer->create(this))
  {
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    delete pMixer;
    return false;
  }

  m_pMixer = pMixer;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this model instance                                                //
//----------------------------------------------------------------------------//

void CalModel::destroy()
{
  // destroy the mixer instance
  if(m_pMixer != 0)
  {
    m_pMixer->destroy();
    delete m_pMixer;
    m_pMixer = 0;
  }

  // destroy the skeleton instance
  if(m_pSkeleton != 0)
  {
    m_pSkeleton->destroy();
    delete m_pSkeleton;
    m_pSkeleton = 0;
  }

  m_pCoreModel = 0;
}

//----------------------------------------------------------------------------//
// Get the core model instance of this model                                  //
//----------------------------------------------------------------------------//

CalCoreModel *CalModel::getCoreModel()
{
  return m_pCoreModel;
}

//----------------------------------------------------------------------------//
//  Get the calculated normals of the given mesh                              //
//----------------------------------------------------------------------------//

int CalModel::getMeshNormals(int meshId, float *pNormal)
{
  // get core mesh
  CalCoreMesh *pCoreMesh;
  pCoreMesh = m_pCoreModel->getCoreMesh(meshId);
  if(pCoreMesh == 0) return -1;

  // get influence vector of the mesh
  std::vector<CalCoreMesh::Influence>& vectorInfluence = pCoreMesh->getVectorInfluence();

  // get vertex influence vector of the mesh
  std::vector<CalCoreMesh::BoneInfluence>& vectorBoneInfluence = pCoreMesh->getVectorBoneInfluence();

  // get bone vector of the skeleton
  std::vector<CalBone *>& vectorBone = m_pSkeleton->getVectorBone();

  // calculate all mesh normals
  int influenceId;
  for(influenceId = 0; influenceId < (int)vectorInfluence.size(); influenceId++)
  {
    CalCoreMesh::Influence& influence = vectorInfluence[influenceId];

    float nx, ny, nz;
    nx = 0.0f;
    ny = 0.0f;
    nz = 0.0f;

    // blend together all vertex influences
    int boneInfluenceId;
    for(boneInfluenceId = 0; boneInfluenceId < influence.boneInfluenceCount; boneInfluenceId++)
    {
      CalCoreMesh::BoneInfluence& boneInfluence = vectorBoneInfluence[influence.boneInfluenceId + boneInfluenceId];

      // get the bone of the influence
      CalBone *pBone;
      pBone = vectorBone[boneInfluence.boneId];

      // transform normal with current state of the bone
      CalVector v(boneInfluence.normal.x, boneInfluence.normal.y, boneInfluence.normal.z);
      v.transform(pBone->getRotationAbsolute());

      nx += boneInfluence.weight * v.m_x;
      ny += boneInfluence.weight * v.m_y;
      nz += boneInfluence.weight * v.m_z;
    }

    // re-normalize normal
    float scale;
    scale = 1.0f / sqrt(nx * nx + ny * ny + nz * nz);

    // save normal position
    pNormal[0] = nx * scale;
    pNormal[1] = ny * scale;
    pNormal[2] = nz * scale;

    // next vertex position in buffer
    pNormal += 3;
  }

  return (int)vectorInfluence.size();
}

//----------------------------------------------------------------------------//
//  Get the calculated vertices of the given mesh                             //
//----------------------------------------------------------------------------//

int CalModel::getMeshVertices(int meshId, float *pVertex)
{
  // get core mesh
  CalCoreMesh *pCoreMesh;
  pCoreMesh = m_pCoreModel->getCoreMesh(meshId);
  if(pCoreMesh == 0) return -1;

  // get influence vector of the mesh
  std::vector<CalCoreMesh::Influence>& vectorInfluence = pCoreMesh->getVectorInfluence();

  // get vertex influence vector of the mesh
  std::vector<CalCoreMesh::BoneInfluence>& vectorBoneInfluence = pCoreMesh->getVectorBoneInfluence();

  // get bone vector of the skeleton
  std::vector<CalBone *>& vectorBone = m_pSkeleton->getVectorBone();

  // calculate all mesh vertices
  int influenceId;
  for(influenceId = 0; influenceId < (int)vectorInfluence.size(); influenceId++)
  {
    CalCoreMesh::Influence& influence = vectorInfluence[influenceId];

    float x, y, z;
    x = 0.0f;
    y = 0.0f;
    z = 0.0f;

    // blend together all vertex influences
    int boneInfluenceId;
    for(boneInfluenceId = 0; boneInfluenceId < influence.boneInfluenceCount; boneInfluenceId++)
    {
      CalCoreMesh::BoneInfluence& boneInfluence = vectorBoneInfluence[influence.boneInfluenceId + boneInfluenceId];

      // get the bone of the influence vertex
      CalBone *pBone;
      pBone = vectorBone[boneInfluence.boneId];

      // transform vertex with current state of the bone
      CalVector v(boneInfluence.position.x, boneInfluence.position.y, boneInfluence.position.z);
      v.transform(pBone->getRotationAbsolute());
      v.add(pBone->getTranslationAbsolute());

      x += boneInfluence.weight * v.m_x;
      y += boneInfluence.weight * v.m_y;
      z += boneInfluence.weight * v.m_z;
    }

    // save vertex position
    pVertex[0] = x;
    pVertex[1] = y;
    pVertex[2] = z;

    // next vertex position in buffer
    pVertex += 3;
  }

  return (int)vectorInfluence.size();
}

//----------------------------------------------------------------------------//
// Get the mixer instance of this model                                       //
//----------------------------------------------------------------------------//

CalMixer *CalModel::getMixer()
{
  return m_pMixer;
}

//----------------------------------------------------------------------------//
// Get the skeleton instance of this model                                    //
//----------------------------------------------------------------------------//

CalSkeleton *CalModel::getSkeleton()
{
  return m_pSkeleton;
}

//----------------------------------------------------------------------------//
// Update this model with a given delta time                                  //
//----------------------------------------------------------------------------//

void CalModel::update(float deltaTime)
{
  m_pMixer->updateAnimation(deltaTime);
  m_pMixer->updateSkeleton();
}

//----------------------------------------------------------------------------//

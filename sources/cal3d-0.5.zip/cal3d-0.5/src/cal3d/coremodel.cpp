//----------------------------------------------------------------------------//
// coremodel.cpp                                                              //
// Copyright (C) 2001 Bruno 'Beosil' Heidelberger                             //
//----------------------------------------------------------------------------//
// This program is free software; you can redistribute it and/or modify it    //
// under the terms of the GNU General Public License as published by the Free //
// Software Foundation; either version 2 of the License, or (at your option)  //
// any later version.                                                         //
//----------------------------------------------------------------------------//

//----------------------------------------------------------------------------//
// Includes                                                                   //
//----------------------------------------------------------------------------//

#include "coremodel.h"
#include "error.h"
#include "coreskeleton.h"
#include "coreanimation.h"
#include "coremesh.h"
#include "loader.h"

//----------------------------------------------------------------------------//
// Constructors                                                               //
//----------------------------------------------------------------------------//

CalCoreModel::CalCoreModel()
{
  m_pCoreSkeleton = 0;
}

//----------------------------------------------------------------------------//
// Destructor                                                                 //
//----------------------------------------------------------------------------//

CalCoreModel::~CalCoreModel()
{
  assert(m_vectorCoreAnimation.empty());
  assert(m_vectorCoreMesh.empty());
}

//----------------------------------------------------------------------------//
// Add a core animation instance to this core model                           //
//----------------------------------------------------------------------------//

int CalCoreModel::addCoreAnimation(CalCoreAnimation *pCoreAnimation)
{
  // get the id of the core animation
  int animationId;
  animationId = m_vectorCoreAnimation.size();

  m_vectorCoreAnimation.push_back(pCoreAnimation);

  return animationId;
}

//----------------------------------------------------------------------------//
// Add a core mesh instance to this core model                                //
//----------------------------------------------------------------------------//

int CalCoreModel::addCoreMesh(CalCoreMesh *pCoreMesh)
{
  // get the id of the core mesh
  int meshId;
  meshId = m_vectorCoreMesh.size();

  m_vectorCoreMesh.push_back(pCoreMesh);

  return meshId;
}

//----------------------------------------------------------------------------//
// Create a core model                                                        //
//----------------------------------------------------------------------------//

bool CalCoreModel::create(const std::string& strName)
{
  m_strName = strName;

  return true;
}

//----------------------------------------------------------------------------//
// Destroy this core model                                                    //
//----------------------------------------------------------------------------//

void CalCoreModel::destroy()
{
  // destroy all core meshes
  std::vector<CalCoreMesh *>::iterator iteratorCoreMesh;
  for(iteratorCoreMesh = m_vectorCoreMesh.begin(); iteratorCoreMesh != m_vectorCoreMesh.end(); ++iteratorCoreMesh)
  {
    (*iteratorCoreMesh)->destroy();
    delete (*iteratorCoreMesh);
  }

  m_vectorCoreMesh.clear();

  // destroy all core animations
  std::vector<CalCoreAnimation *>::iterator iteratorCoreAnimation;
  for(iteratorCoreAnimation = m_vectorCoreAnimation.begin(); iteratorCoreAnimation != m_vectorCoreAnimation.end(); ++iteratorCoreAnimation)
  {
    (*iteratorCoreAnimation)->destroy();
    delete (*iteratorCoreAnimation);
  }

  m_vectorCoreAnimation.clear();

  if(m_pCoreSkeleton != 0)
  {
    m_pCoreSkeleton->destroy();
    delete m_pCoreSkeleton;
    m_pCoreSkeleton = 0;
  }

  m_strName = "";
}

//----------------------------------------------------------------------------//
// Load a core animation for this core model from a given file                //
//----------------------------------------------------------------------------//

int CalCoreModel::loadCoreAnimation(const std::string& strFilename)
{
  // the core skeleton has to be loaded already
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // load a new core animation
  CalLoader loader;
  CalCoreAnimation *pCoreAnimation;
  pCoreAnimation = loader.loadCoreAnimation(strFilename);
  if(pCoreAnimation == 0) return -1;

  // add core animation to this core model
  int animationId;
  animationId = addCoreAnimation(pCoreAnimation);
  if(animationId == -1)
  {
    delete pCoreAnimation;
    return -1;
  }

  return animationId;
}

//----------------------------------------------------------------------------//
// Load a core skeleton for this core model from a given file                 //
//----------------------------------------------------------------------------//

bool CalCoreModel::loadCoreSkeleton(const std::string& strFilename)
{
  // destroy the current core skeleton
  if(m_pCoreSkeleton != 0)
  {
    m_pCoreSkeleton->destroy();
    delete m_pCoreSkeleton;
  }

  // load a new core skeleton
  CalLoader loader;
  m_pCoreSkeleton = loader.loadCoreSkeleton(strFilename);
  if(m_pCoreSkeleton == 0) return false;

  return true;
}

//----------------------------------------------------------------------------//
// Load a core mesh for this core model from a given file                     //
//----------------------------------------------------------------------------//

int CalCoreModel::loadCoreMesh(const std::string& strFilename)
{
  // the core skeleton has to be loaded already
  if(m_pCoreSkeleton == 0)
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return -1;
  }

  // load a new core mesh
  CalLoader loader;
  CalCoreMesh *pCoreMesh;
  pCoreMesh = loader.loadCoreMesh(strFilename);
  if(pCoreMesh == 0) return -1;

  // add core mesh to this core model
  int meshId;
  meshId = addCoreMesh(pCoreMesh);
  if(meshId == -1)
  {
    delete pCoreMesh;
    return -1;
  }

  return meshId;
}

//----------------------------------------------------------------------------//
// Get the core animations for a given id                                     //
//----------------------------------------------------------------------------//

CalCoreAnimation *CalCoreModel::getCoreAnimation(int id)
{
  if((id < 0) || (id >= (int)m_vectorCoreAnimation.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorCoreAnimation[id];
}

//----------------------------------------------------------------------------//
// Get the number of core animations of this core model                       //
//----------------------------------------------------------------------------//

int CalCoreModel::getCoreAnimationCount()
{
  return m_vectorCoreAnimation.size();
}

//----------------------------------------------------------------------------//
// Get the core mesh for a given id                                           //
//----------------------------------------------------------------------------//

CalCoreMesh *CalCoreModel::getCoreMesh(int id)
{
  if((id < 0) || (id >= (int)m_vectorCoreMesh.size()))
  {
    CalError::setLastError(CalError::INVALID_HANDLE, __FILE__, __LINE__);
    return 0;
  }

  return m_vectorCoreMesh[id];
}

//----------------------------------------------------------------------------//
// Get the core skeleton linked to this core model                            //
//----------------------------------------------------------------------------//

CalCoreSkeleton *CalCoreModel::getCoreSkeleton()
{
  return m_pCoreSkeleton;
}

//----------------------------------------------------------------------------//

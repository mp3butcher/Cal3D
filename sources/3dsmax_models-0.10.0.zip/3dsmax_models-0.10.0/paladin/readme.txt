Model: Female Paladin
Version: 1.0
License: GNU FDL (See license.txt for more info)
WarForge Website: http://www.worldforge.org/website/warforge/

Author: Douglas Walsh
E-Mail: dwwalsh@eclipse.net

Feel free to e-mail me about any questions or concerns.  CAUTION! Looking at all the models may give way to the story plot of the game.